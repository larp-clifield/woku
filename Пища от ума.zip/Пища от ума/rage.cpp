#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/logging/logging.hpp>
#include <utilities/math/move_basis.hpp>
#include <core/scripting/scripting.hpp>
#include <utilities/threadpool/threadpool.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <protection/game_addresses.hpp>
#include <exploits.h>
namespace features::combat {

	constexpr int k_max_hitbox_bones = 28;   // max bone index referenced by a hitbox (record->bones is 128)
	constexpr bool k_enable_shot_logging = true;

	namespace detail {
		// no-spread: простая галочка. Работает — включай, нет — выключай.
		template < class T >
		inline bool ns_active( const T& cfg )
		{
			return cfg.no_spread.value;
		}
		inline double now_seconds( )
		{
			using clock = std::chrono::steady_clock;
			return std::chrono::duration<double>( clock::now( ).time_since_epoch( ) ).count( );
		}

		// Память промахов по цели живёт столько секунд после последнего промаха.
		constexpr double k_miss_memory_ttl = 20.0;

		inline auto tick_add( int t, float f, int dt, float df ) -> std::pair< int, float >
		{
			f += df;
			const auto carry = static_cast< int >( std::floor( f ) );
			f -= static_cast< float >( carry );
			return std::pair{ t + dt + carry, f };
		}
	}

	namespace scoring {
		// Порядок среди хитов, прошедших hitchance (k_pass_hitchance):
		//   смертельный (k_lethal_score) > safe (k_safe_bonus) > голова
		//   (k_head_priority) > приоритет цели (k_priority_scale) > урон.
		// Раньше голова (200000) стояла выше смертельного (100000), и бот бил
		// не смертельно в голову, когда смертельное тело было доступно.
		constexpr float k_lethal_bonus = 1000000.0f;
		constexpr float k_direct_bonus = 5000.0f;
		constexpr float k_center_bonus = 2000.0f;
		constexpr float k_damage_scale = 20.0f;
		constexpr float k_cheap_fov_penalty = 1.0f;
		constexpr float k_pass_hitchance = 1000000.0f;
		constexpr float k_lethal_score = 600000.0f;
		constexpr float k_hc_scale = 10000.0f;
		constexpr float k_damage_hc_scale = 100.0f;
		constexpr float k_damage_base = 5.0f;
		constexpr float k_pen_direct = 250.0f;
		constexpr float k_center_score = 50.0f;
		constexpr float k_head_priority = 200000.0f;
		constexpr float k_body_priority = 100.0f;
		constexpr float k_limb_priority = 2.0f;
		// Из двух смертельных хитов: тело (prefer body if lethal) или голова.
		constexpr float k_lethal_pick_bonus = 5000.0f;
		// Приоритет цели 0..1 умножается на это: выше урона, ниже головы.
		constexpr float k_priority_scale = 40000.0f;
		// Штраф за тик возраста записи после промахов "lag compensation".
		constexpr float k_lag_miss_age_penalty = 5000.0f;
		constexpr float k_fov_score_penalty = 0.1f;
		constexpr float k_record_age_penalty = 15.0f;
		// Was 200: it made the aimbot prefer a guessed pose over real lag records.
		constexpr float k_extrapolated_bonus = 0.0f;
		// Point hits the same hitbox on both jitter sides. Above head priority,
		// below k_lethal_score and k_pass_hitchance.
		constexpr float k_safe_bonus = 250000.0f;
	}

	void rage::on_create_move( systems::input::usercmd* cmd )
	{
		auto& ctx = g_shared.ctx( );
		const auto local = systems::g_local.get( );
		this->update_penetration_crosshair( local );

		if ( !ctx.valid )
		{
			this->m_revolver_cock_ticks = 0;
			return;
		}

		this->m_should_stop = false;
		this->m_firing_this_tick = false;

		// Auto scope: нажатие прицела держится ровно один тик, в следующем
		// явно сообщаем серверу "отпустил". Без отпускания сервер видит кнопку
		// зажатой, и следующее нажатие не считается новым (прицел не включался
		// по 60-70 тиков подряд, бот стоял и ждал).
		if ( this->m_scope_release_pending )
		{
			this->m_scope_release_pending = false;
			if ( !( cmd->buttons.value & cstypes::command_buttons::in_second_attack ) )
			{
				cmd->buttons.value_changed |= cstypes::command_buttons::in_second_attack;
			}
		}

		if ( !settings::g_combat.m_duckpeek.enabled.value )
		{
			this->m_release_duck_for_shot = false;
			this->m_duckpeek_reduck = false;
		}

		if ( this->m_zeus_fired )
		{
			this->m_zeus_fired = false;

			if ( settings::g_combat.m_zeusbot.drop_after && !systems::g_local.is_in_deathmatch( ) )
			{
				memory::call<void>(PATTERN (patterns::engine_client_cmd), addresses::globals::source2engine_to_client, 0, "drop", 0x7ffef001 );
			}

			return;
		}

		const auto is_knife = ctx.weapon_type == cstypes::weapon_type::knife;
		const auto is_taser = ctx.weapon_type == cstypes::weapon_type::taser;

		if ( !is_knife && !is_taser && ( ctx.weapon_type < cstypes::weapon_type::pistol || ctx.weapon_type > cstypes::weapon_type::lmg ) )
		{
			return;
		}

		auto aim_ctx = this->build_context( cmd, local );

		if ( is_knife )
		{
			if ( !g_shared.can_shoot( cmd, local.controller ) )
			{
				return;
			}

			this->run_knife( cmd, aim_ctx, local );
		}
		else if ( is_taser )
		{
			if ( !g_shared.can_shoot( cmd, local.controller ) )
			{
				return;
			}

			this->run_taser( cmd, aim_ctx, local );
		}
		else if ( ctx.item_def_idx == cstypes::item_definition_index::weapon_r8_revolver )
		{
			// Quick shot goes through the ordinary gun path: there is no hammer to
			// hold, so there is no cycle to manage -- fire_gun just sends attack2.
			if ( settings::g_combat.m_autos.revolver_quick.value )
			{
				this->m_revolver_cock_ticks = 0;

				// Primary attack must not reach the revolver in this mode, and it
				// has to be stripped every tick rather than only on the tick we
				// fire.
				//
				// Holding the fire key cocks the hammer, and a cocked revolver goes
				// off when the game decides the cock is done -- on a tick we never
				// solved a seed for, with angles we never corrected. The spread
				// correction is computed, verified and sent, and then a different
				// shot entirely leaves the barrel: exactly the picture in the logs,
				// where the fixed point always succeeds and the bullet still lands
				// anywhere inside the full cone.
				//
				// The stale index matters just as much as the button. process_
				// doubletap clears it for the same reason when it takes a shot over.
				//
				// Only when the button is genuinely held. Announcing the change
				// unconditionally reads as "the trigger was released" on every
				// single command, and releasing the trigger is exactly what fires a
				// cocked revolver -- so the weapon spent every tick starting and
				// abandoning its cycle, jerked in the hands, and never fired at all.
				if ( cmd->buttons.value & cstypes::command_buttons::in_attack )
				{
					cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
					cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
					cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
					cmd->csgo_user_cmd.set_attack1_start_history_index( -1 );
				}

				if ( !g_shared.can_shoot( cmd, local.controller ) )
				{
					return;
				}

				this->run_gun( cmd, aim_ctx, local );
			}
			else
			{
				this->auto_revolver( cmd, aim_ctx, local );
			}
		}
		else
		{
			this->m_revolver_cock_ticks = 0;

			if ( !g_shared.can_shoot( cmd, local.controller ) )
			{
				return;
			}

			this->run_gun( cmd, aim_ctx, local );
		}
	}

	void rage::on_render( xdraw::draw_list& draw_list )
	{
		this->draw_penetration_crosshair( draw_list );

		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( g_shared.ctx( ).item_def_idx, g_shared.ctx( ).weapon_type );
		if ( !config.debug_multipoints.value )
		{
			return;
		}

		std::lock_guard lock( m_debug_mtx );

		for ( const auto& pt : m_debug_points )
		{
			const auto screen = systems::g_view.project( pt.position );
			if ( !systems::g_view.projection_valid( screen ) )
			{
				continue;
			}

			xdraw::color col{};
			switch ( pt.hitbox_index )
			{
			case 0:
				col = { 255, 80,  80  }; break; // head — red
			case 2: case 3:
				col = { 220, 220, 60  }; break; // stomach — yellow
			case 4: case 5: case 6:
				col = { 255, 160, 60  }; break; // chest — orange
			case 7: case 8: case 9: case 10: case 11: case 12:
				col = { 80,  160, 255 }; break; // legs — blue
			case 13: case 14: case 15: case 16: case 17: case 18:
				col = { 180, 80,  255 }; break; // arms — purple
			default:
				col = { 200, 200, 200 }; break;
			}

			const auto alpha  = pt.is_center ? std::uint8_t{ 255 } : std::uint8_t{ 160 };
			const auto radius = pt.is_center ? 3.5f : 2.0f;

			draw_list.circle_filled( screen.x, screen.y, radius, col.alpha( alpha ) );
		}
	}

	rage::aim_context rage::build_context( systems::input::usercmd* cmd, const systems::local::snapshot& local ) const
	{
		auto& ctx = g_shared.ctx( );
		const auto& prestate = systems::g_prediction.pre( );

		aim_context out{};
		out.velocity = prestate.velocity;
		out.spread = g_shared.get_spread( );
		out.predicted_inaccuracy = g_shared.get_inaccuracy( true );

		systems::g_prediction.simulate( cmd, local, [ & ]
			{
				g_shared.sh( ).snapshot( local.pawn, ctx.weapon_services );

				out.velocity = memory::read<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecAbsVelocity"_hash ) );
				out.spread = g_shared.get_spread( );
				out.predicted_inaccuracy = g_shared.get_inaccuracy( true );
			} );

		ctx.spread = out.spread;
		ctx.inaccuracy = out.predicted_inaccuracy;

		out.view_angles = systems::g_input.get_view_angles( );
		out.on_ground = ( prestate.flags & cstypes::entity_flags::on_ground ) != 0;
		out.is_scoped = ctx.is_scoped;
		out.weapon_max_speed = ctx.weapon_max_speed;
		out.accurate_threshold = ctx.weapon_max_speed * 0.34f;

		return out;
	}

	bool rage::process_doubletap( systems::input::usercmd* cmd, const systems::local::snapshot& local, bool charge_dt )
	{
		const auto& shared_ctx = g_shared.ctx( );
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );
		if ( !config.doubletap.value )
		{
			return false;
		}

		const auto base_cmd = cmd->csgo_user_cmd.mutable_base( );
		if ( !base_cmd )
		{
			return false;
		}

		const auto client_tick = base_cmd->client_tick( );
		const auto next_primary = memory::read<int>( shared_ctx.weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextPrimaryAttackTick"_hash ) );
		const auto tick_base = memory::read<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase"_hash ) );

		const auto can_attack = client_tick >= next_primary && tick_base >= g_shared.last_shoot_tick( ) + 2 && !memory::read<bool>( shared_ctx.weapon + SCHEMA( "C_CSWeaponBase", "m_bInReload"_hash ) ) && memory::read<int>( shared_ctx.weapon + SCHEMA( "C_BasePlayerWeapon", "m_iClip1"_hash ) ) > 0;

		const auto should_attack = can_attack && charge_dt;

		if ( should_attack )
		{
			if ( const auto subtick_moves = base_cmd->mutable_subtick_moves( ) )
			{
				const auto old_size = subtick_moves->m_current_size;
				const auto press = systems::g_input.acquire_subtick_step( subtick_moves );
				const auto release = systems::g_input.acquire_subtick_step( subtick_moves );
				if ( press && release )
				{
					press->set_button( cstypes::command_buttons::in_attack );
					press->set_pressed( true );
					press->set_when( 0.0f );
					press->set_analog_forward_delta( 0.0f );
					press->set_analog_left_delta( 0.0f );

					release->set_button( cstypes::command_buttons::in_attack );
					release->set_pressed( false );
					release->set_when( std::nextafter( 1.0f, 0.0f ) );
					release->set_analog_forward_delta( 0.0f );
					release->set_analog_left_delta( 0.0f );

					// The subtick release is the final state. Do not let the
					// base command turn this pulse into a held attack.
					cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
					cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
					cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
					cmd->csgo_user_cmd.set_attack1_start_history_index( -1 );
					return true;
				}

				// Do not leave a partial press in the command if allocation of
				// the matching release failed.
				subtick_moves->m_current_size = old_size;
			}
		}

		cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
		cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
		cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
		cmd->csgo_user_cmd.set_attack1_start_history_index( -1 );
		return false;
	}

	struct friction_result {
		math::vector3 velocity;
		int ticks;
		// Ground covered between now and the tick we reach accurate_threshold.
		// predict_stop used to extrapolate the eye at the full current velocity
		// for the whole stop duration, which overshoots badly: we are shedding
		// speed the entire time. Integrate it here instead of guessing.
		math::vector3 displacement;
	};

	friction_result simulate_friction_stop(
		const math::vector3& initial_velocity,
		float accurate_threshold,
		float weapon_max_speed,
		float max_move_speed,
		bool is_scoped,
		float sv_friction,
		float sv_stopspeed,
		float sv_accelerate,
		float surface_friction,
		int max_ticks = 15)
	{
		auto sim_vel = initial_velocity;
		sim_vel.z = 0.0f;
		int ticks_to_threshold = -1;
		int total_ticks = 0;
		math::vector3 displacement{};
		math::vector3 displacement_at_threshold{};

		for (auto i = 0; i < max_ticks; ++i) {
			const auto sim_speed = sim_vel.length_2d();
			if (sim_speed < 1.0f) {
				sim_vel = {};
				break;
			}

			if (ticks_to_threshold < 0 && sim_speed <= accurate_threshold) {
				ticks_to_threshold = i;
				displacement_at_threshold = displacement;
			}

			const auto entry_velocity = sim_vel;

			const auto control = std::max(sim_speed, sv_stopspeed);
			const auto drop = sv_friction * surface_friction * control * cstypes::tick_interval;
			auto new_speed = std::max(sim_speed - drop, 0.0f);
			auto accel = sv_accelerate;

			if (is_scoped) {
				const auto weapon_ratio = std::min(1.0f, weapon_max_speed / 250.0f);
				const auto scoped_max = std::max(250.0f, max_move_speed) * weapon_ratio * 0.52f;
				if (new_speed > scoped_max - 5.0f) {
					const auto t = 1.0f - std::max(0.0f, new_speed - (scoped_max - 5.0f)) / std::max(0.01f, 5.0f);
					accel *= std::clamp(t, 0.0f, 1.0f);
				}
			}

			const auto accel_speed = std::min(accel * weapon_max_speed * surface_friction * cstypes::tick_interval, new_speed);
			new_speed = std::max(new_speed - accel_speed, 0.0f);

			if (new_speed > 0.0f)
				sim_vel *= (new_speed / sim_speed);
			else
				sim_vel = {};

			// Average the tick's entry and exit velocity: the speed falls across
			// the tick, so neither end alone integrates the arc correctly.
			displacement += (entry_velocity + sim_vel) * 0.5f * cstypes::tick_interval;
			++total_ticks;

			if (new_speed <= 0.0f)
				break;
		}

		if (ticks_to_threshold < 0) {
			ticks_to_threshold = total_ticks;
			displacement_at_threshold = displacement;
		}

		return {sim_vel, ticks_to_threshold, displacement_at_threshold};
	}

	std::optional<rage::stop_prediction> rage::predict_stop( const aim_context& ctx, const math::vector3& current_eye, const systems::local::snapshot& local ) const
	{
		const auto& shared_ctx = g_shared.ctx( );
		const auto& prestate = systems::g_prediction.pre( );
		const auto speed = prestate.networked_velocity.length_2d( );
		const auto will_stop = ctx.on_ground && ( speed > ctx.accurate_threshold || ( ctx.is_scoped && speed > 1.0f ) );

		if ( !will_stop )
		{
			return std::nullopt;
		}

		const auto sv_friction = CONVAR("sv_friction")->get<float>( );
		const auto sv_stopspeed = CONVAR("sv_stopspeed")->get<float>( );
		const auto sv_accelerate = CONVAR("sv_accelerate")->get<float>( );
		const auto surface_friction = prestate.surface_friction;

		const auto movement_services = memory::read<std::uintptr_t>( local.pawn + SCHEMA( "C_BasePlayerPawn", "m_pMovementServices"_hash ) );
		const auto max_move_speed = movement_services ? memory::read<float>( movement_services + SCHEMA( "CPlayer_MovementServices", "m_flMaxspeed"_hash ) ) : 250.0f;

		const auto result = simulate_friction_stop(
			prestate.networked_velocity,
			ctx.accurate_threshold,
			shared_ctx.weapon_max_speed,
			max_move_speed,
			shared_ctx.is_scoped,
			sv_friction,
			sv_stopspeed,
			sv_accelerate,
			surface_friction
		);

		// result.displacement is the integrated path of the deceleration, not
		// velocity * time -- at 250 u/s over 8 ticks the old form placed the eye
		// roughly twice as far down range as we actually travel, so every shot
		// planned from the predicted stop was aimed from a spot we never reach.
		return stop_prediction
		{
			.eye =
			{
				current_eye.x + result.displacement.x,
				current_eye.y + result.displacement.y,
				current_eye.z
			},
			.inaccuracy = g_shared.get_inaccuracy_at_velocity( local.pawn, result.velocity )
		};
	}

	std::vector<rage::candidate> rage::gather_candidates( const systems::local::snapshot& local, float max_distance_sq ) const
	{
		const auto& shared_ctx = g_shared.ctx( );
		const auto players = systems::g_entities.get_by_type( systems::entities::type::player );

		std::vector<candidate> out;
		out.reserve( players.size( ) );

		const_cast<rage*>( this )->m_extrapolated_records.clear( );
		const_cast<rage*>( this )->m_extrapolated_records.reserve( players.size( ) );
		this->m_gather_stats = {};

		for ( const auto& p : players )
		{
			if ( !p.ptr || p.ptr == local.controller )
			{
				continue;
			}

			if ( !memory::read<bool>( p.ptr + SCHEMA( "CCSPlayerController", "m_bPawnIsAlive"_hash ) ) )
			{
				continue;
			}

			const auto pawn_handle = memory::read<std::uint32_t>( p.ptr + SCHEMA( "CBasePlayerController", "m_hPawn"_hash ) );
			const auto pawn = systems::g_entities.lookup( pawn_handle );

			if ( !pawn || pawn == local.pawn )
			{
				continue;
			}

			const auto team = memory::read<int>( pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum"_hash ) );
			if ( !local.is_this_other_team( team ) )
			{
				continue;
			}

			const auto health = memory::read<int>( pawn + SCHEMA( "C_BaseEntity", "m_iHealth"_hash ) );
			if ( health <= 0 )
			{
				continue;
			}

			++this->m_gather_stats.enemies_alive;

			if ( memory::read<bool>( pawn + SCHEMA( "C_CSPlayerPawn", "m_bGunGameImmunity"_hash ) ) )
			{
				++this->m_gather_stats.immune;
				continue;
			}

			auto records = g_shared.lc( ).get_valid_records( pawn );
			const auto valid_record_count = static_cast< int >( records.size( ) );

			// Extrapolation only as a fallback. The server rewinds to real lag
			// records; a guessed pose misses targets that change direction/jitter.
			if ( records.empty( ) )
			{
				auto extrap = g_shared.lc( ).extrapolate( pawn );
				if ( extrap.has_value( ) )
				{
					const_cast<rage*>( this )->m_extrapolated_records.push_back( std::move( *extrap ) );
					records.push_back( &const_cast<rage*>( this )->m_extrapolated_records.back( ) );
				}
			}

			if ( records.empty( ) )
			{
				++this->m_gather_stats.no_records;
				continue;
			}

			if ( max_distance_sq > 0.0f )
			{
				const auto& origin = systems::g_prediction.pre( ).origin;
				const auto delta_front = records.front( )->origin - origin;
				auto closest_sq = delta_front.x * delta_front.x + delta_front.y * delta_front.y + delta_front.z * delta_front.z;

				if ( records.size( ) > 1 )
				{
					const auto delta_back = records.back( )->origin - origin;
					const auto back_sq = delta_back.x * delta_back.x + delta_back.y * delta_back.y + delta_back.z * delta_back.z;
					closest_sq = std::min( closest_sq, back_sq );
				}

				if ( closest_sq > max_distance_sq )
				{
					++this->m_gather_stats.too_far;
					continue;
				}
			}

			candidate c{};
			c.dbg_valid_records = valid_record_count;
			c.dbg_extrapolated = valid_record_count == 0;
			c.pawn = pawn;
			c.health = health;
			c.armor = memory::read<int>( pawn + SCHEMA( "C_CSPlayerPawn", "m_ArmorValue"_hash ) );

			// Сколько записей сканировать: low 2 / default 3 / high 4 / max 5.
			const auto scan_limit = [ ]( ) -> int
				{
					const auto& lg = settings::g_combat.m_lagcomp;
					if ( !lg.scan_records_enabled.value )
					{
						return 3;
					}

					return std::clamp( lg.scan_records_mode.value, 0, 3 ) + 2;
				}( );

			const auto pick_record_indices = [ &records, scan_limit ]( std::array<int, k_max_scan_records>& out_indices ) -> int
				{
					const auto count = records.size( );
					if ( count == 0 )
					{
						return 0;
					}

					auto picked{ 0 };
					const auto add_index = [ & ]( int idx )
						{
							if ( picked >= scan_limit || picked >= k_max_scan_records )
							{
								return;
							}

							for ( auto i = 0; i < picked; ++i )
							{
								if ( out_indices[ i ] == idx )
								{
									return;
								}
							}

							out_indices[ picked++ ] = idx;
						};

					add_index( 0 );

					// Nearest record showing the other jitter side.
					for ( std::size_t i = 1; i < count; ++i )
					{
						const auto d = std::fabsf( std::remainderf( records[ i ]->eye_yaw - records[ 0 ]->eye_yaw, 360.0f ) );
						if ( d > 25.0f )
						{
							add_index( static_cast< int >( i ) );
							break;
						}
					}

					if ( count > 2 )
					{
						add_index( static_cast< int >( count / 2 ) );
					}

					if ( count > 1 )
					{
						add_index( static_cast< int >( count - 1 ) );
					}

					// Пятая точка для режима max: между свежей и серединой истории.
					if ( count > 4 )
					{
						add_index( static_cast< int >( count / 4 ) );
					}

					return picked;
				};

			std::array<int, k_max_scan_records> record_indices{};
			const auto picked_count = pick_record_indices( record_indices );

			for ( auto i = 0; i < picked_count; ++i )
			{
				c.records[ i ] = records[ static_cast< std::size_t >( record_indices[ i ] ) ];
			}

			c.record_count = picked_count;

			// FIX: запись с "другой стороной" jitter раньше искалась только среди
			// 2-5 записей, выбранных для скана. При быстром jitter соседние
			// выбранные записи часто оказывались на одной стороне, safe point не
			// находился, и бот стрелял в голову наугад. Ищем по всем валидным
			// записям; для проверки safe point записи не нужно быть в скане.
			// Сравниваем и взгляд, и поворот модели: jitter виден в обоих.
			c.alt_record = nullptr;
			{
				const auto* front = c.records[ 0 ];
				auto best_diff = 25.0f;
				for ( auto* rec : records )
				{
					if ( !rec || rec == front || !rec->valid || rec->extrapolated )
					{
						continue;
					}

					const auto eye_diff = std::fabsf( std::remainderf( rec->eye_yaw - front->eye_yaw, 360.0f ) );
					const auto body_diff = std::fabsf( std::remainderf( rec->rotation.y - front->rotation.y, 360.0f ) );
					const auto diff = std::fmaxf( eye_diff, body_diff );
					if ( diff > best_diff )
					{
						best_diff = diff;
						c.alt_record = rec;
					}
				}
			}

			// Приоритет цели (угроза / дистанция / HP / прошлая цель).
			if ( settings::g_combat.m_ragebot.target_priority.value )
			{
				c.priority = this->target_priority( c, g_shared.get_shoot_position( ) );
			}

			// Память промахов по этой цели.
			if ( settings::g_combat.m_ragebot.miss_memory.value )
			{
				std::lock_guard lock( this->m_miss_mtx );
				const auto it = this->m_miss_memory.find( pawn );
				if ( it != this->m_miss_memory.end( ) && detail::now_seconds( ) - it->second.last_miss < detail::k_miss_memory_ttl )
				{
					const auto& m = it->second;
					c.extra_hc = 0.05f * static_cast< float >( std::min( m.spread, 3 ) );
					c.strict_edges = m.occlusion >= 1;
					c.force_safe = m.resolver >= 1;
					c.avoid_unsafe_head = m.resolver >= 2;
					c.record_age_mult = m.lagcomp >= 1 ? 2.0f : 1.0f;
				}
			}

			if ( shared_ctx.weapon_type >= cstypes::weapon_type::pistol && shared_ctx.weapon_type <= cstypes::weapon_type::lmg )
			{
				const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );
				c.min_damage = this->get_min_damage( config, health, config.min_damage_override.value );

				// Lua: rage.override_min_damage(n) на этот тик.
				if ( const auto lua_md = scripting::min_damage_override( ) )
				{
					c.min_damage = std::min( *lua_md, static_cast< float >( health ) + 1.0f );
				}
			}

			out.push_back( c );
		}

		return out;
	}

	void rage::run_gun( systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local, bool allow_fire )
	{
		if ( !settings::g_combat.m_ragebot.enabled )
		{
			return;
		}

		auto& shared_ctx = g_shared.ctx( );
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );

		const auto finish_doubletap = [ & ]( bool charge_dt )
		{
			if ( config.doubletap.value && shared_ctx.item_def_idx != cstypes::item_definition_index::weapon_r8_revolver )
			{
				return this->process_doubletap( cmd, local, charge_dt );
			}

			return false;
		};

		// Real charge-then-release doubletap (g_exploits): holds the shot back for
		// k_required_ticks while charging, then lets it through and shifts the fired
		// command's input-history tick backward in post_fire so the server processes
		// it as if the weapon had already come off cooldown. Runs every tick
		// (independent of target visibility) so the charge timer is real-time.
		// A disabled/ineligible weapon short-circuits to "always ready" so behavior
		// is unchanged when doubletap is off.
		const auto dt_enabled = config.doubletap.value && shared_ctx.item_def_idx != cstypes::item_definition_index::weapon_r8_revolver;
		const auto dt_ready = !dt_enabled || g_exploits.pre_think( cmd, local );

		auto candidates = this->gather_candidates( local );

		{
			std::lock_guard lock( m_debug_mtx );
			m_debug_points.clear( );
		}

		if ( candidates.empty( ) )
		{
			this->log_no_target( candidates, "no candidates" );
			finish_doubletap( false );
			return;
		}

		// Prioritize the target we shot last tick: its position changes smoothly, so
		// reusing the previous aim context keeps selection stable between ticks.
		if ( this->m_last_target_pawn )
		{
			for ( auto i = 1u; i < candidates.size( ); ++i )
			{
				if ( candidates[ i ].pawn == this->m_last_target_pawn )
				{
					std::swap( candidates[ 0 ], candidates[ i ] );
					break;
				}
			}
		}

		auto eye_candidates = g_shared.sh( ).get_candidates( );
		{
			// The server fires from the interpolated shoot position, not the raw eye
			// (ring-buffer candidate or live muzzle fallback) -- those can be up to a
			// full lerp of movement ahead of it during jump-shots, which shifts the
			// aim ray off the hitbox at range while still landing fine up close
			// (small target-angle error at melee range). Always resolve entry 0 from
			// the interpolated position so scanning matches what the server tests.
			const auto interpolated_eye = local.pawn ? g_shared.get_interpolated_shoot_position( local.pawn ) : math::vector3{};

			if ( eye_candidates.count > 0 )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
			}
			else if ( interpolated_eye.length_sqr( ) > 1.0f )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
				eye_candidates.entries[ 0 ].is_uninterpolated = true;
				eye_candidates.count = 1;
			}
		}

		const auto scan_from_eye_candidates = [ & ]( const math::vector3& eye_offset, float inaccuracy )
		{
			std::vector<scan_hit> hits_out;

			for ( auto i = 0; i < eye_candidates.count; ++i )
			{
				const auto eye = eye_candidates.entries[ i ].position + eye_offset;
				auto hits = this->scan_players( eye, inaccuracy, ctx, candidates, local );
				auto found_direct{ false };

				for ( auto& hit : hits )
				{
					auto source_eye = eye_candidates.entries[ i ];
					source_eye.position = eye;
					hit.source_eye = source_eye;
					found_direct = found_direct || !hit.penetrated;
					hits_out.push_back( std::move( hit ) );
				}

				if ( found_direct )
				{
					break;
				}
			}

			return hits_out;
		};

		if ( detail::ns_active( config ) )
		{
			shared_ctx.inaccuracy = g_shared.get_inaccuracy( false );
			auto all_hits = scan_from_eye_candidates( {}, shared_ctx.inaccuracy );

			if ( all_hits.empty( ) )
			{
				this->log_no_target( candidates, "no-spread: scan found no points" );
				finish_doubletap( false );
				return;
			}

			const auto best = this->select_best( ctx, all_hits, shared_ctx.inaccuracy, local );
			if ( !best.valid )
			{
				this->log_no_target( candidates, "no-spread: select_best rejected all points" );
				finish_doubletap( false );
				return;
			}

			if ( !allow_fire )
			{
				return;
			}

			if ( !dt_ready )
			{
				finish_doubletap( false );
				return;
			}

			// Shot timing и в режиме no-spread.
			if ( this->should_delay_shot( ctx, best, local ) )
			{
				finish_doubletap( false );
				return;
			}

			const auto subtick_attack = finish_doubletap( true );
			this->fire_gun( cmd, best, false, best.hit.source_eye.position, local, subtick_attack );

			if ( dt_enabled && this->m_firing_this_tick )
			{
				g_exploits.post_fire( cmd, local );
			}

			return;
		}

		const auto primary_eye = eye_candidates.entries[ 0 ].position;
		const auto& prestate = systems::g_prediction.pre( );

		// Current-shot selection is always based on current engine shoot-history.
		auto current_hits = scan_from_eye_candidates( {}, ctx.predicted_inaccuracy );
		auto best = this->select_best( ctx, current_hits, ctx.predicted_inaccuracy, local );

		// Lua: rage.override_hitchance(n) на этот тик имеет приоритет.
		const auto lua_hc = scripting::hitchance_override( );
		const auto needed_hc = lua_hc ? *lua_hc / 100.0f
			: ( config.hitchance_override.value ? static_cast< float >( config.hitchance_override_value ) / 100.0f : static_cast< float >( config.hitchance ) / 100.0f );
		// Нужный hitchance для конкретной цели: память промахов (spread) добавляет
		// к нему до +15%. Lua override задаёт значение явно и не меняется.
		const auto needed_for = [ & ]( const target& t ) -> float
			{
				return lua_hc ? needed_hc : std::min( needed_hc + t.hit.extra_hc, 0.99f );
			};

		const auto duckpeek_active = settings::g_combat.m_duckpeek.enabled.value && ctx.on_ground;
		const auto is_ducked = ( prestate.flags & cstypes::entity_flags::ducking ) != 0;

		auto standing_inaccuracy = duckpeek_active ? this->get_standing_inaccuracy( local, ctx ) : ctx.predicted_inaccuracy;
		auto standing_hc = best.valid
			? ( duckpeek_active ? this->evaluate_hitchance( best.hit, ctx, standing_inaccuracy ) : best.hitchance )
			: 0.0f;

		// Whether autostop actually intends to halt for this target. Used so we only
		// withhold a shot while moving when a stop is genuinely planned (close /
		// approaching targets do not need one and must still be allowed to fire).
		const auto intend_to_stop = this->should_stop_for_target( ctx, best );

		auto max_acc = g_shared.is_max_accuracy( standing_inaccuracy );
		// Whether we are still fast enough that a planned stop hasn't landed yet.
		// This only guards the predictive re-evaluation below (Improvement #1),
		// which fires using a *hypothetical* future stopped inaccuracy. The base
		// `accurate` check below already uses ctx.predicted_inaccuracy -- the
		// engine's own honest simulation for this exact tick/state (moving, jump
		// apex, whatever it is) -- so it needs no extra gate: as soon as the real,
		// already-achieved hitchance clears the bar, fire. Requiring max_acc here
		// instead would mean waiting for a full stop / literal jump apex on every
		// shot, which is both needlessly slow on the ground and makes the bot
		// nearly never fire in the air (is_max_accuracy is only true on the exact
		// apex tick).
		const auto moving = prestate.networked_velocity.length_2d( ) > ctx.accurate_threshold;
		const auto auto_stop = config.auto_stop.value;
		// Reverted back to generic (2026-08-31): the ground-only version was tried
		// per explicit request and confirmed to reproduce exactly the predicted
		// failure -- firing while actively strafing missed because the shot used
		// predict_air_stop's *predicted* post-counter-strafe accuracy before the
		// real counter-strafe (now working correctly in airstrafe.cpp) had
		// actually brought horizontal velocity down. Generic `moving` makes the
		// bot wait the real ~2-4 ticks for the counter-strafe to land, then fire
		// on genuinely-achieved accuracy -- which is also just what "stop in the
		// air for a couple ticks, instant headshot, keep flying" requires.
		const auto wait_for_stop = auto_stop && moving && intend_to_stop;

		auto accurate = best.valid && standing_hc >= needed_for( best );
		max_acc = g_shared.is_max_accuracy( standing_inaccuracy );
		auto force = best.valid && config.force_shot.value && max_acc;
		auto shot_viable = accurate || force;

		if ( best.valid )
		{
			const auto& weapon_vdata = g_shared.ctx( ).weapon_vdata;
			if ( weapon_vdata )
			{
				const auto full_vel = memory::read<math::vector3>( local.pawn + SCHEMA( "C_BaseEntity", "m_vecVelocity"_hash ) );
				auto real_vel = full_vel;
				real_vel.z = 0.0f;
				const auto real_speed_2d = real_vel.length_2d( );

				const auto inacc_stand = memory::read<float>( weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flInaccuracyStand"_hash ) );
				const auto inacc_floor = std::max( inacc_stand, 0.004f );
				const auto real_inacc = g_shared.get_inaccuracy_at_velocity( local.pawn, real_vel );

				const auto too_inaccurate = real_inacc > inacc_floor * 2.0f + 0.003f;
				// 0.20f sat well under the max_speed * 0.34f accurate threshold the
				// rest of the aimbot uses, so shots were refused at speeds that fire
				// perfectly well. Ground only: in the air airborne_unshootable is the
				// check that matters, and this one just kept us from ever firing.
				const auto on_ground_now = ( prestate.flags & cstypes::entity_flags::on_ground ) != 0;
				const auto too_fast = on_ground_now && ctx.weapon_max_speed > 0.0f && real_speed_2d > ctx.weapon_max_speed * 0.34f;

				// Честный опрос физики движка CS2 для апекса прыжка:
				const auto airborne_unshootable = ( prestate.flags & cstypes::entity_flags::on_ground ) == 0
					&& [ & ]( ) -> bool
					{
						const auto inac_jump_apex = memory::read<float>( weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flInaccuracyJumpApex"_hash ) );
						const auto accuracy_penalty = memory::read<float>( g_shared.ctx( ).weapon + SCHEMA( "C_CSWeaponBase", "m_fAccuracyPenalty"_hash ) );
						const auto min_air_inaccuracy = accuracy_penalty + inac_jump_apex;
						const auto real_air_inaccuracy = g_shared.get_inaccuracy_at_velocity( local.pawn, full_vel );

						constexpr auto air_tolerance{ 0.003f };
						return real_air_inaccuracy > min_air_inaccuracy + air_tolerance;
					}( );

				// These three are guards for force_shot, which fires without ever
				// consulting hitchance. A shot that already cleared needed_hc was
				// measured at ctx.predicted_inaccuracy -- the real cone, jump
				// penalty included -- so vetoing it here re-decides a question
				// hitchance already answered, and keeps us silent for the whole
				// time the landing penalty takes to decay. That is the pause after
				// touching down where the aimbot sees the target and says nothing.
				if ( !accurate && ( too_inaccurate || too_fast || airborne_unshootable ) )
				{
					shot_viable = false;
				}
			}
		}

		float stop_inaccuracy = ctx.predicted_inaccuracy;
		math::vector3 stop_offset{};
		const auto autostop_enabled = config.auto_stop.value;

		if ( autostop_enabled && !shot_viable && this->should_stop_movement( ctx ) )
		{
			const auto stop = this->predict_stop( ctx, primary_eye, local );
			if ( stop )
			{
				stop_inaccuracy = stop->inaccuracy;
				stop_offset = stop->eye - primary_eye;
				const auto future_offset = stop_offset;
				auto planned_hits = scan_from_eye_candidates( future_offset, stop_inaccuracy );
				const auto planned = this->select_best( ctx, planned_hits, stop_inaccuracy, local );
				this->m_should_stop = planned.valid;
			}
			else
			{
				this->m_should_stop = best.valid;
			}
		}

		// Auto scope: снайперка без прицела, а цель есть. Жмём прицел и в этом
		// тике не стреляем: без прицела разброс огромный. Автостоп при этом
		// продолжает работать (m_should_stop уже посчитан выше).
		const auto scoping = best.valid && this->apply_autoscope( cmd, best, config );

		// Improvement #1: if autostop will bring us to a (near) stop, the real
		// inaccuracy at the moment of firing is the stopped inaccuracy, not the
		// current moving one. Re-select with that lower inaccuracy so the fire
		// decision uses a realistic hitchance and can pick a higher-value point.
		// Gated on !wait_for_stop: never fire on the same tick a stop is only just
		// being planned — the character is still moving with the real (wide) cone,
		// so committing here misses. Wait until the stop actually completes.
		if ( this->m_should_stop && stop_inaccuracy < ctx.predicted_inaccuracy - 0.0001f )
		{
			auto effective_hits = scan_from_eye_candidates( stop_offset, stop_inaccuracy );
			const auto effective_best = this->select_best( ctx, effective_hits, stop_inaccuracy, local );
			if ( effective_best.valid && !wait_for_stop )
			{
				current_hits = std::move( effective_hits );
				best = effective_best;
				standing_inaccuracy = stop_inaccuracy;
				standing_hc = best.hitchance;
				accurate = best.valid && standing_hc >= needed_for( best );
				max_acc = g_shared.is_max_accuracy( standing_inaccuracy );
				force = best.valid && ( ctx.on_ground ? ( config.force_shot.value && max_acc ) : ( config.force_shot_air.value && max_acc ) );
				shot_viable = accurate || force;
			}
		}

		// Clutch: a lethal server-time (extrapolated) target must be committed
		// immediately, bypassing the normal hitchance gate and the autostop-wait.
		// The server rewinds the enemy to command time, so the extrapolated pose is
		// exactly where the bullet is tested — delaying a tick lets the enemy's own
		// shot land first (e.g. a 10 HP AWP clutch vs a peeking rusher).
		if ( best.is_lethal( ) && best.hit.record && best.hit.record->extrapolated )
		{
			accurate = best.valid;
			shot_viable = accurate || force;
		}

		// Improvement #6: if standing we cannot reach the needed hitchance, try a
		// crouched eye position — it may open a cleaner line through a wallbang or
		// expose a different hitbox face. Commit only if it is meaningfully better.
		// Hold the crouch across ticks. The press below only starts the movement;
		// the shot itself is taken later, by the ordinary path, once the eye has
		// actually arrived.
		if ( this->m_duck_for_shot_ticks > 0 )
		{
			--this->m_duck_for_shot_ticks;
		}

		this->m_should_duck_for_shot = this->m_duck_for_shot_ticks > 0;

		if ( !accurate && !force && ctx.on_ground && !( prestate.flags & cstypes::entity_flags::ducking ) )
		{
			constexpr auto duck_eye_delta = math::vector3{ 0.0f, 0.0f, -18.0f };

			auto ducked_hits = scan_from_eye_candidates( duck_eye_delta, ctx.predicted_inaccuracy );
			const auto ducked_best = this->select_best( ctx, ducked_hits, ctx.predicted_inaccuracy, local );

			if ( ducked_best.valid )
			{
				const auto ducked_hc = this->evaluate_hitchance( ducked_best.hit, ctx, ctx.predicted_inaccuracy );
				if ( ducked_hc > standing_hc + 0.05f )
				{
					// Duck now, shoot later. This used to adopt the crouched eye and
					// fire on the same command, but pressing +duck does not drop the
					// eye 18 units that tick -- CS2 ramps m_flDuckAmount over about a
					// fifth of a second. The bullet left from the standing eye while
					// the angle had been solved for the crouched one, and the server
					// logged it as a shoot position mismatch: 57 of 127 misses in the
					// last session, the single largest cause.
					//
					// So only start the movement here. Once the pose settles the
					// normal scan sees the same opening from an eye that is really
					// there, and takes the shot with an angle that matches it.
					this->m_duck_for_shot_ticks = 8;
					this->m_should_duck_for_shot = true;

					accurate = false;
					force = false;
					shot_viable = false;
				}
			}
		}

		if ( !best.valid )
		{
			this->log_no_target( candidates, "no valid target after scan/select" );
			finish_doubletap( false );
			return;
		}

		if ( duckpeek_active && allow_fire )
		{
			if ( shot_viable )
			{
				this->m_release_duck_for_shot = true;
			}
			else if ( !this->m_duckpeek_reduck )
			{
				this->m_release_duck_for_shot = false;
			}
		}

		// Outside the fire block on purpose: the tick that starts the crouch is by
		// definition not the tick that fires.
		if ( this->m_should_duck_for_shot )
		{
			cmd->buttons.value |= cstypes::command_buttons::in_duck;
			cmd->buttons.value_changed |= cstypes::command_buttons::in_duck;
			cmd->buttons.value_scroll |= cstypes::command_buttons::in_duck;
		}

		auto ready_to_fire = shot_viable && !scoping;
		if ( duckpeek_active )
		{
			if ( is_ducked )
			{
				ready_to_fire = false;
			}
			else
			{
				ready_to_fire = ready_to_fire && this->m_release_duck_for_shot;
			}
		}

		// calculate_hitchance is pure geometry: a ray against one hitbox capsule,
		// with no world trace anywhere in it. A centre ray that clears the corner
		// of cover while the rest of the cone eats it therefore scores a perfect
		// hitchance, and the shot goes into the wall. Confirm the cone can
		// actually reach before spending the bullet.
		//
		// Once, on the chosen target, on the tick we are about to fire -- doing it
		// per candidate during the scan would multiply the scan's trace count by
		// the sample count.
		auto dbg_cone_factor{ -1.0f };

		if ( ready_to_fire )
		{
			const auto cone_factor = this->validate_shot_cone( best, ctx, standing_inaccuracy, local );
			dbg_cone_factor = cone_factor;

			if ( accurate )
			{
				// Scale the measured hitchance by the share of the cone that is
				// not blocked, then re-apply the user's threshold to it.
				if ( standing_hc * cone_factor < needed_for( best ) )
				{
					ready_to_fire = false;
				}
			}
			else if ( cone_factor <= 0.0f )
			{
				// force_shot deliberately ignores hitchance, but "no part of the
				// cone reaches the target" is not a hitchance question.
				ready_to_fire = false;
			}
		}

		// Shot timing: не смертельный выстрел придерживаем на несколько тиков,
		// если цель вот-вот выйдет под смертельный (голова / грудь).
		auto timing_hold{ false };
		if ( ready_to_fire && allow_fire && dt_ready )
		{
			timing_hold = this->should_delay_shot( ctx, best, local );
			ready_to_fire = ready_to_fire && !timing_hold;
		}

		// Диагностика "навёлся и не стреляет": если цель есть, а выстрела нет
		// дольше ~0.2 с, раз в 12 тиков пишем, что именно держит выстрел.
		{
			static int s_hold_ticks{};
			const auto will_fire = ready_to_fire && allow_fire && dt_ready;

			if ( will_fire )
			{
				if ( s_hold_ticks >= 12 && settings::g_misc.m_interface.shot_log.value )
				{
					logging::console::print( xs( "[rage hold] released after {} ticks" ), s_hold_ticks );
				}
				s_hold_ticks = 0;
			}
			else
			{
				++s_hold_ticks;

				if ( s_hold_ticks >= 12 && s_hold_ticks % 12 == 0 && settings::g_misc.m_interface.shot_log.value )
				{
					const char* why = "?";
					if ( !allow_fire )                      why = "weapon not ready (cooldown / scoping / reload)";
					else if ( !dt_ready )                   why = "double tap charging";
					else if ( scoping )                     why = "auto scope";
					else if ( timing_hold )                 why = "shot timing (waiting for lethal)";
					else if ( this->m_should_duck_for_shot ) why = "crouching for a better angle";
					else if ( duckpeek_active && !this->m_release_duck_for_shot ) why = "duck peek waiting";
					else if ( !shot_viable && wait_for_stop ) why = "waiting for autostop";
					else if ( !shot_viable )                why = "hitchance too low";
					else if ( dbg_cone_factor >= 0.0f )     why = "cone blocked by cover";

					const auto speed = prestate.networked_velocity.length_2d( );
					logging::console::print(
						xs( "[rage hold] {} ticks: {} | hc {:.0f}% need {:.0f}% | cone ok {:.0f}% | aim {} dmg {} | speed {:.0f} ground {} scoped {} | stop plan {} wait {} | autostop cfg {} can_stop {} autoscope cfg {}/{} zoom {}" ),
						s_hold_ticks, why,
						standing_hc * 100.0f, needed_for( best ) * 100.0f,
						dbg_cone_factor < 0.0f ? -1.0f : dbg_cone_factor * 100.0f,
						systems::g_hitboxes.hitgroup_to_name( best.hit.hitgroup ), static_cast< int >( best.hit.damage ),
						speed, ctx.on_ground,
						memory::read<bool>( local.pawn + SCHEMA( "C_CSPlayerPawn", "m_bIsScoped"_hash ) ),
						this->m_should_stop, wait_for_stop,
						config.auto_stop.value, this->should_stop_movement( ctx ),
						settings::g_combat.m_autos.scope.value, config.auto_scope.value,
						memory::read<int>( shared_ctx.weapon + SCHEMA( "C_CSWeaponBaseGun", "m_zoomLevel"_hash ) ) );
				}
			}
		}

		if ( ready_to_fire && allow_fire && dt_ready )
		{
			const auto subtick_attack = finish_doubletap( true );

			this->fire_gun( cmd, best, !accurate && force, best.hit.source_eye.position, local, subtick_attack );

			// The shot is committed, so the stop has done its job. airstrafe runs
			// later in this same create_move and reads should_stop(); leaving the
			// flag set makes it brake for a shot that already went out.
			this->m_should_stop = false;

			// fire_gun already committed the attack bits/history entries above;
			// post_fire only rewrites their recorded tick so the server sees this
			// shot as landing on the tick the weapon actually came off cooldown.
			if ( dt_enabled && this->m_firing_this_tick )
			{
				g_exploits.post_fire( cmd, local );
			}

			if ( duckpeek_active )
			{
				this->m_duckpeek_reduck = true;
				this->m_release_duck_for_shot = false;
			}
		}
		else
		{
			finish_doubletap( false );
		}
	}

	void rage::run_taser( systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local )
	{
		if ( !settings::g_combat.m_zeusbot.enabled )
		{
			return;
		}

		auto candidates = this->gather_candidates( local );
		if ( candidates.empty( ) )
		{
			return;
		}

		auto eye_candidates = g_shared.sh( ).get_candidates( );
		{
			// See run_gun: always resolve from the interpolated shoot position, not
			// the raw eye, so scanning matches what the server actually tests.
			const auto interpolated_eye = local.pawn ? g_shared.get_interpolated_shoot_position( local.pawn ) : math::vector3{};

			if ( eye_candidates.count > 0 )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
			}
			else if ( interpolated_eye.length_sqr( ) > 1.0f )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
				eye_candidates.entries[ 0 ].is_uninterpolated = true;
				eye_candidates.count = 1;
			}
		}

		std::vector<scan_hit> all_hits;

		for ( auto i = 0; i < eye_candidates.count; ++i )
		{
			auto hits = this->scan_taser( eye_candidates.entries[ i ].position, ctx, candidates, local );

			for ( auto& h : hits )
			{
				h.source_eye = eye_candidates.entries[ i ];
				all_hits.push_back( std::move( h ) );
			}
		}

		if ( all_hits.empty( ) )
		{
			return;
		}

		target best{};

		for ( const auto& h : all_hits )
		{
			if ( !best.valid || h.score > best.score )
			{
				best.hit = h;
				best.hitchance = 1.0f;
				best.score = h.score;
				best.valid = true;
			}
		}

		if ( best.valid )
		{
			this->m_zeus_fired = true;
			this->fire_melee( cmd, best, local );
		}
	}

	void rage::run_knife( systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local )
	{
		if ( !settings::g_combat.m_knifebot.enabled )
		{
			return;
		}

		const auto info = this->get_knife_info( local );
		if ( !info.can_slash && !info.can_stab )
		{
			return;
		}

		constexpr auto max_knife_dist_sq = 150.0f * 150.0f;
		auto candidates = this->gather_candidates( local, max_knife_dist_sq );
		if ( candidates.empty( ) )
		{
			return;
		}

		auto eye_candidates = g_shared.sh( ).get_candidates( );
		{
			// See run_gun: always resolve from the interpolated shoot position, not
			// the raw eye, so scanning matches what the server actually tests.
			const auto interpolated_eye = local.pawn ? g_shared.get_interpolated_shoot_position( local.pawn ) : math::vector3{};

			if ( eye_candidates.count > 0 )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
			}
			else if ( interpolated_eye.length_sqr( ) > 1.0f )
			{
				eye_candidates.entries[ 0 ].position = interpolated_eye;
				eye_candidates.entries[ 0 ].is_uninterpolated = true;
				eye_candidates.count = 1;
			}
		}

		std::vector<scan_hit> all_hits;

		for ( auto i = 0; i < eye_candidates.count; ++i )
		{
			auto hits = this->scan_knife( eye_candidates.entries[ i ].position, ctx, info, candidates, local );

			for ( auto& h : hits )
			{
				h.source_eye = eye_candidates.entries[ i ];
				all_hits.push_back( std::move( h ) );
			}
		}

		if ( all_hits.empty( ) )
		{
			return;
		}

		target best{};
		target best_backstab{};

		for ( const auto& h : all_hits )
		{
			auto& dest = h.is_backstab ? best_backstab : best;

			if ( !dest.valid || h.score > dest.score )
			{
				dest.hit = h;
				dest.hitchance = 1.0f;
				dest.score = h.score;
				dest.valid = true;
			}
		}

		auto& chosen = best_backstab.valid ? best_backstab : best;
		if ( !chosen.valid )
		{
			return;
		}

		this->m_knife_attack = static_cast< std::uint8_t >( chosen.hit.attack_type );
		this->fire_melee( cmd, chosen, local );
	}

	void rage::auto_revolver( systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local )
	{
		if ( !settings::g_combat.m_ragebot.enabled )
		{
			this->m_revolver_cock_ticks = 0;
			return;
		}

		if ( !g_shared.can_shoot( cmd, local.controller ) )
		{
			this->m_revolver_cock_ticks = 0;
			return;
		}

		if ( !settings::g_combat.m_autos.revolver.value )
		{
			this->m_revolver_cock_ticks = 0;
			return;
		}

		constexpr auto cock_ticks{ 13 };
		if ( this->m_revolver_cock_ticks >= cock_ticks )
		{
			// End the held cycle. Target selection adds attack back on this
			// command only when the revolver should actually fire.
			cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
			cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
			cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
			cmd->csgo_user_cmd.set_attack1_start_history_index( -1 );
			this->m_revolver_cock_ticks = 0;

			this->run_gun( cmd, ctx, local );
			return;
		}

		// Keep target and hitchance planning active throughout the cock cycle.
		// Autostop consumes this command's decision on the following command.
		this->run_gun( cmd, ctx, local, false );

		cmd->buttons.value |= cstypes::command_buttons::in_attack;
		cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
		cmd->buttons.value_scroll |= cstypes::command_buttons::in_attack;

		const auto history_index = cmd->csgo_user_cmd.input_history_size( ) - 1;
		if ( history_index >= 0 )
		{
			cmd->csgo_user_cmd.set_attack1_start_history_index( history_index );
		}

		++this->m_revolver_cock_ticks;
	}

	std::vector<rage::scan_hit> rage::scan_players( const math::vector3& eye, float inaccuracy, const aim_context& ctx, std::vector<candidate>& candidates, const systems::local::snapshot& local ) const
	{
		std::vector<std::vector<scan_hit>> per_candidate( candidates.size( ) );

		const auto min_batch = candidates.size( ) < 4 ? static_cast< int >( candidates.size( ) ) : 1;
		threadpool::parallel_for( 0, static_cast< int >( candidates.size( ) ), [ & ]( int begin, int end )
			{
				for ( auto ci = begin; ci < end; ++ci )
				{
					auto& cand = candidates[ ci ];
					auto& candidate_hits = per_candidate[ ci ];
					candidate_hits.reserve( 24 );

					for ( auto ri = 0; ri < cand.record_count; ++ri )
					{
						if ( !cand.records[ ri ] || !cand.records[ ri ]->valid )
						{
							continue;
						}

						auto hits = this->scan_player( eye, inaccuracy, ctx, cand, cand.records[ ri ], local );
						const auto has_direct_hit = std::any_of( hits.begin( ), hits.end( ), [ ]( const scan_hit& hit )
							{
								return !hit.penetrated;
							} );

						for ( auto& h : hits )
						{
							candidate_hits.push_back( std::move( h ) );
						}

						// A viable shot on the newest record is both more reliable and
						// cheaper than evaluating historical poses for the same target.
						if ( has_direct_hit )
						{
							break;
						}
					}
				}
			}, min_batch );

		std::vector<scan_hit> flat;
		auto total_hits{ std::size_t{} };
		for ( const auto& hits : per_candidate )
		{
			total_hits += hits.size( );
		}
		flat.reserve( total_hits );

		for ( auto& v : per_candidate )
		{
			for ( auto& h : v )
			{
				flat.push_back( std::move( h ) );
			}
		}

		return flat;
	}

	std::vector<rage::scan_hit> rage::scan_player( const math::vector3& eye, float inaccuracy, const aim_context& ctx, candidate& cand, shared::lagcomp::record* record, const systems::local::snapshot& local ) const
	{
		// idk how this happens
		if (!cand.pawn || cand.record_count <= 0 || cand.health <= 0)
			return {};

		const auto& shared_ctx = g_shared.ctx( );
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );

		const auto game_scene_node = memory::read<std::uintptr_t>( cand.pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		const auto hitbox_set = systems::g_hitboxes.query( game_scene_node );
		const auto skeleton = g_shared.lc( ).get_skeleton( *record );
		const auto pen_ctx = g_shared.pen( ).prepare_target( cand.pawn, record );

		// FIX: учитываем fallback резольвера после промахов в голову.
		auto force_body = config.body_aim.value || g_shared.res( ).should_force_body_aim( cand.pawn ) || scripting::force_body_aim( );

		// Auto body-aim when the enemy is on low HP: a torso shot is enough to kill,
		// so there is no reason to gamble on a lower-hitchance headshot.
		if ( !force_body && cand.health <= 35 && cand.armor > 0 )
		{
			force_body = true;
		}

		std::array<int, 19> scan_order{};
		auto scan_count{ 0 };

		if ( !force_body && config.hitboxes.values[ 0 ] )
		{
			scan_order[ scan_count++ ] = 0;
		}

		if ( config.hitboxes.values[ 1 ] )
		{
			scan_order[ scan_count++ ] = 4;
			scan_order[ scan_count++ ] = 5;
			scan_order[ scan_count++ ] = 6;
		}

		if ( config.hitboxes.values[ 2 ] )
		{
			scan_order[ scan_count++ ] = 3;
			scan_order[ scan_count++ ] = 2;
		}

		if ( config.hitboxes.values[ 3 ] )
		{
			for ( auto idx : { 13, 14, 15, 16, 17, 18 } )
			{
				scan_order[ scan_count++ ] = idx;
			}
		}

		if ( config.hitboxes.values[ 4 ] )
		{
			for ( auto idx : { 7, 8, 9, 10 } )
			{
				scan_order[ scan_count++ ] = idx;
			}
		}

		if ( config.hitboxes.values[ 5 ] )
		{
			for ( auto idx : { 11, 12 } )
			{
				scan_order[ scan_count++ ] = idx;
			}
		}

		// Old configs can deserialize with every hitbox disabled. Keep the
		// ragebot operational with the core head and torso hitboxes.
		if ( scan_count == 0 )
		{
			if ( !force_body )
			{
				scan_order[ scan_count++ ] = 0;
			}

			for ( auto idx : { 4, 5, 6, 3, 2 } )
			{
				scan_order[ scan_count++ ] = idx;
			}
		}

		struct trace_point
		{
			math::vector3 position;
			int hitbox_index;
			int bone_index;
			systems::hitboxes::entry hitbox;
			bool is_center;
		};

		std::vector<trace_point> points;
		points.reserve( static_cast< std::size_t >( scan_count ) * 12 );

		for ( auto idx = 0; idx < scan_count; ++idx )
		{
			const auto hitbox_index = scan_order[ idx ];
			const systems::hitboxes::entry* hb{ nullptr };

			for ( const auto& entry : hitbox_set )
			{
				if ( entry.index == hitbox_index )
				{
					hb = &entry;
					break;
				}
			}

			if ( !hb || hb->bone < 0 || hb->bone >= k_max_hitbox_bones )
			{
				continue;
			}

			const auto& bone = skeleton[ hb->bone ];
			if ( bone.position.length_sqr( ) < 1.0f )
			{
				continue;
			}

			const auto hitbox_center = ( hb->mins + hb->maxs ) * 0.5f;
			const auto center = bone.rotation.rotate_vector( hitbox_center ) + bone.position;

			trace_point cp{};
			cp.position = center;
			cp.hitbox_index = hitbox_index;
			cp.bone_index = hb->bone;
			cp.hitbox = *hb;
			cp.is_center = true;
			points.push_back( cp );

			if ( config.debug_multipoints.value )
			{
				std::lock_guard lock( m_debug_mtx );
				m_debug_points.push_back( { center, hitbox_index, true } );
			}

			if ( config.pointscale > 0.0f )
			{
				std::vector<math::vector3> mps;
		this->generate_multipoints( *hb, center, bone.rotation, config.pointscale, eye, inaccuracy, mps );

				for ( const auto& mp : mps )
				{
					const auto duplicate = std::any_of( points.begin( ), points.end( ), [ & ]( const trace_point& point )
						{
							return point.hitbox_index == hitbox_index && ( point.position - mp ).length_sqr( ) < 0.01f;
						} );
					if ( duplicate )
					{
						continue;
					}

					trace_point tp{};
					tp.position = mp;
					tp.hitbox_index = hitbox_index;
					tp.bone_index = hb->bone;
					tp.hitbox = *hb;
					tp.is_center = false;
					points.push_back( tp );

					if ( config.debug_multipoints.value )
					{
						std::lock_guard lock( m_debug_mtx );
						m_debug_points.push_back( { mp, hitbox_index, false } );
					}
				}
			}
		}

		if ( points.empty( ) )
		{
			return {};
		}

		std::vector<scan_hit> results;
		results.reserve( static_cast< std::size_t >( scan_count ) * 2 );
		std::array<bool, 19> center_sufficient{};

		// FIX (occlusion на пике): состояние центра каждого хитбокса.
		// 0 — не проверен, 1 — простреливается напрямую, 2 — за стеной / мало урона.
		// Центр в points всегда идёт перед своими мультипоинтами.
		std::array<std::uint8_t, 19> center_state{};
		std::array<math::vector3, 19> center_pos{};
		const auto hb_slot = [ ]( int index ) { return index >= 0 && index < 19; };

		// Safe point: the ray also hits the same hitbox in the record with the
		// other jitter side. The alt skeleton is shifted to this record's origin
		// so only the rotation difference is compared.
		const auto alt = ( cand.alt_record && cand.alt_record != record && cand.alt_record->valid ) ? cand.alt_record : nullptr;
		std::array<systems::bones::data, 27> alt_skeleton{};
		if ( alt )
		{
			alt_skeleton = g_shared.lc( ).get_skeleton( *alt );
		}

		const auto is_safe_point = [ & ]( const math::vector3& pos, const systems::hitboxes::entry& hb ) -> bool
			{
				if ( !alt || hb.radius <= 0.001f || hb.bone < 0 || hb.bone >= 27 )
				{
					return false;
				}

				const auto& b = alt_skeleton[ hb.bone ];
				if ( b.position.length_sqr( ) < 1.0f )
				{
					return false;
				}

				const auto shift = record->origin - alt->origin;
				const auto a = b.rotation.rotate_vector( hb.mins ) + b.position + shift;
				const auto c = b.rotation.rotate_vector( hb.maxs ) + b.position + shift;

				auto frac{ 1.0f };
				return g_shared.ray_vs_capsule( eye, ( pos - eye ) * 1.05f, a, c, hb.radius, frac );
			};

		auto dbg_checked = 0;
		auto dbg_fov_reject = 0;
		auto dbg_trace_reject = 0;
		auto dbg_damage_reject = 0;
		auto dbg_edge_reject = 0;
		auto dbg_min_fov = 999.0f;
		auto dbg_max_damage = 0.0f;

		for ( const auto& tp : points )
		{
			if ( !tp.is_center && tp.hitbox_index >= 0 && tp.hitbox_index < static_cast< int >( center_sufficient.size( ) ) && center_sufficient[ tp.hitbox_index ] )
			{
				continue;
			}

			++dbg_checked;

			const auto aim = math::helpers::calculate_angle( eye, tp.position );
			const auto fov = math::helpers::angle_distance( ctx.view_angles, aim );
			dbg_min_fov = std::fminf( dbg_min_fov, fov );

			if ( tp.is_center && hb_slot( tp.hitbox_index ) )
			{
				center_pos[ tp.hitbox_index ] = tp.position;
				center_state[ tp.hitbox_index ] = 2;
			}

			if ( fov > config.max_fov )
			{
				++dbg_fov_reject;
				continue;
			}

			shared::penetration::result pen{};
			if ( !g_shared.pen( ).run( eye, tp.position, pen_ctx, local.pawn, local.team, pen ) )
			{
				++dbg_trace_reject;
				continue;
			}

			dbg_max_damage = std::fmaxf( dbg_max_damage, pen.damage );

			if ( pen.damage < cand.min_damage )
			{
				++dbg_damage_reject;
				continue;
			}

			if ( tp.is_center && hb_slot( tp.hitbox_index ) && !pen.penetrated )
			{
				center_state[ tp.hitbox_index ] = 1;
			}

			// FIX (occlusion на пике): hitchance считается только по форме
			// хитбокса и не видит стен. Если центр хитбокса за стеной, а
			// простреливается лишь край (голова выглядывает из-за угла), часть
			// разлёта уходит в стену. Такой край берём, только если проходит и
			// точка на полпути к центру; иначе ждём, пока цель выйдет сильнее.
			// Память промахов: после промаха "occlusion" по этой цели край
			// хитбокса берём только при центре, видимом напрямую.
			if ( cand.strict_edges && !tp.is_center && hb_slot( tp.hitbox_index ) && center_state[ tp.hitbox_index ] != 1 )
			{
				++dbg_edge_reject;
				continue;
			}

			if ( !tp.is_center && hb_slot( tp.hitbox_index ) && center_state[ tp.hitbox_index ] != 1 )
			{
				const auto& c = center_pos[ tp.hitbox_index ];
				if ( c.length_sqr( ) > 1.0f )
				{
					const auto mid = c + ( tp.position - c ) * 0.5f;
					shared::penetration::result mid_pen{};
					const auto mid_ok = g_shared.pen( ).run( eye, mid, pen_ctx, local.pawn, local.team, mid_pen )
						&& mid_pen.damage >= cand.min_damage
						&& ( pen.penetrated || !mid_pen.penetrated );

					if ( !mid_ok )
					{
						++dbg_edge_reject;
						continue;
					}
				}
			}

			if ( !tp.is_center && tp.hitbox_index == 0 )
			{
				if ( pen.hitgroup != systems::g_hitboxes.hitgroup_from_hitbox( tp.hitbox_index ) )
				{
					continue;
				}
			}

			// A point on the neck / upper chest whose ray happens to clip the head
			// capsule *in our record* came back with head damage (293 for a scout)
			// and was picked as "lethal". The head is the one hitbox that moves
			// with the resolver's yaw guess; the server's head was elsewhere and
			// the shot landed in the chest for 73, or missed. Only credit head
			// damage to points that were aimed at the head. Everything else is
			// scaled as the hitgroup it was aimed at (a safe underestimate: if the
			// server does agree the ray hits the head, the shot only does more).
			if ( tp.hitbox_index != 0 && pen.hitgroup == 1 )
			{
				const auto aimed_group = systems::g_hitboxes.hitgroup_from_hitbox( tp.hitbox_index );
				pen.hitgroup = aimed_group;
				pen.hitbox = tp.hitbox_index;
				pen.damage = g_shared.pen( ).rescale( aimed_group, pen_ctx, pen.raw_damage );

				if ( pen.damage < cand.min_damage )
				{
					++dbg_damage_reject;
					continue;
				}
			}

			if ( tp.is_center && tp.hitbox_index >= 0 && tp.hitbox_index < static_cast< int >( center_sufficient.size( ) ) )
			{
				// Only skip multipoints when the center hit is both direct and lethal.
				// Otherwise a center point near the capsule edge may have worse hitchance
				// than a side multipoint, so keep evaluating them.
				center_sufficient[ tp.hitbox_index ] = !pen.penetrated && pen.damage >= static_cast< float >( cand.health );
			}

			scan_hit h{};
			h.position = tp.position;
			h.aim_angle = aim;
			h.damage = pen.damage;
			h.fov = fov;
			h.hitbox_index = tp.hitbox_index;
			h.hitgroup = pen.hitgroup;
			h.bone_index = tp.bone_index;
			h.hitbox = tp.hitbox;
			h.is_center = tp.is_center;
			h.penetrated = pen.penetrated;
			h.is_safe = is_safe_point( tp.position, tp.hitbox );
			h.target_jitter = alt != nullptr;
			h.priority = cand.priority;
			h.extra_hc = cand.extra_hc;
			h.force_safe = cand.force_safe;
			h.avoid_unsafe_head = cand.avoid_unsafe_head;
			h.record_age_mult = cand.record_age_mult;
			h.pawn = cand.pawn;
			h.health = cand.health;
			h.record = record;

			results.push_back( h );
		}

		// Копим причины отказа в кандидате: печатает их log_no_target раз в секунду.
		cand.dbg_points += dbg_checked;
		cand.dbg_fov_reject += dbg_fov_reject;
		cand.dbg_trace_reject += dbg_trace_reject;
		cand.dbg_damage_reject += dbg_damage_reject;
		cand.dbg_edge_reject += dbg_edge_reject;
		cand.dbg_min_fov = std::fminf( cand.dbg_min_fov, dbg_min_fov );
		cand.dbg_max_damage = std::fmaxf( cand.dbg_max_damage, dbg_max_damage );

		return results;
	}

	rage::target rage::select_best( const aim_context& aim_ctx, const std::vector<scan_hit>& hits, float eval_inaccuracy, const systems::local::snapshot& local ) const
	{
		// Голова важнее тела среди НЕ смертельных хитов. Смертельные идут
		// отдельным уровнем выше (см. scoring).
		auto hitgroup_priority = [ ]( int hitbox_index ) -> float
			{
				if ( hitbox_index == 0 ) { return scoring::k_head_priority; }
				if ( hitbox_index >= 1 && hitbox_index <= 6 ) { return scoring::k_body_priority; }
				if ( hitbox_index >= 13 && hitbox_index <= 18 ) { return scoring::k_limb_priority; }
				return 0.0f;
			};
		const auto prefer_body_lethal = settings::g_combat.m_ragebot.prefer_body_lethal.value;

		struct record_group
		{
			shared::lagcomp::record* record;
			std::vector<int> hit_indices;
		};

		std::vector<record_group> groups;
		groups.reserve( 16 );

		for ( auto i = 0; i < static_cast< int >( hits.size( ) ); ++i )
		{
			auto rec = hits[ i ].record;
			auto found{ false };

			for ( auto& g : groups )
			{
				if ( g.record == rec )
				{
					g.hit_indices.push_back( i );
					found = true;
					break;
				}
			}

			if ( !found )
			{
				record_group g{};
				g.record = rec;
				g.hit_indices.reserve( 16 );
				g.hit_indices.push_back( i );
				groups.push_back( std::move( g ) );
			}
		}

		constexpr auto top_k_per_record{ 8 };

		auto cheap_score = [ & ]( const scan_hit& h ) -> float
			{
			const auto lethal = h.damage >= static_cast< float >( h.health );
			const auto lethal_bonus = lethal ? scoring::k_lethal_bonus : 0.0f;
			const auto direct_bonus = h.penetrated ? 0.0f : scoring::k_direct_bonus;
			const auto center_bonus = h.is_center ? scoring::k_center_bonus : 0.0f;
			// Смертельные точки не должны вытесняться из top-k точками головы.
			const auto group_bonus = lethal ? 0.0f : hitgroup_priority( h.hitbox_index );

			return lethal_bonus + direct_bonus + center_bonus + h.damage * scoring::k_damage_scale +
				group_bonus - h.fov * scoring::k_cheap_fov_penalty;
			};

		for ( auto& group : groups )
		{
			if ( static_cast< int >( group.hit_indices.size( ) ) <= top_k_per_record )
			{
				continue;
			}

			std::partial_sort
			(
				group.hit_indices.begin( ),
				group.hit_indices.begin( ) + top_k_per_record,
				group.hit_indices.end( ),
				[ & ]( int a, int b ) { return cheap_score( hits[ a ] ) > cheap_score( hits[ b ] ); }
			);

			group.hit_indices.resize( top_k_per_record );
		}

		struct evaluated_hit
		{
			int hit_index;
			float hitchance;
			float score;
		};

		std::vector<evaluated_hit> evaluated;
		evaluated.reserve( hits.size( ) );

		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( g_shared.ctx( ).item_def_idx, g_shared.ctx( ).weapon_type );
		const auto lua_hc = scripting::hitchance_override( );
		const auto needed_hc = lua_hc ? *lua_hc / 100.0f
			: ( config.hitchance_override.value
				? static_cast< float >( config.hitchance_override_value ) / 100.0f
				: static_cast< float >( config.hitchance ) / 100.0f );

		for ( auto& group : groups )
		{
			if ( !group.record || !group.record->valid )
			{
				continue;
			}

			for ( const auto idx : group.hit_indices )
			{
				const auto& h = hits[ idx ];

				if ( !h.record || !h.record->valid )
				{
					continue;
				}

				if ( h.bone_index < 0 || h.bone_index >= k_max_hitbox_bones )
				{
					continue;
				}

				const auto& bone = group.record->bones[ h.bone_index ];
				const auto hc = detail::ns_active( config )
					? 1.0f
					: ( h.penetrated
						? this->evaluate_hitchance_with_pen( h, aim_ctx, eval_inaccuracy, local )
						: g_shared.calculate_hitchance( h.source_eye.position, h.aim_angle, h.hitbox, bone, eval_inaccuracy, aim_ctx.spread ) );
				const auto hp = static_cast< float >( h.health );
				const auto can_kill = h.damage >= hp;
				// Память промахов (resolver) включает safe points для цели даже
				// без общей галочки Prefer safe.
				const auto prefer_safe = settings::g_combat.m_ragebot.general.prefer_safe_point.value || h.force_safe;
				// FIX: у цели с jitter голова сильнее всего зависит от угла, а
				// не-safe точка головы — это попадание "50 на 50". Если включён
				// Prefer safe, такая голова теряет свой приоритет, и бот выберет
				// тело (оно ближе к оси вращения и почти не смещается).
				const auto unsafe_head = !h.is_safe && h.hitbox_index == 0;
				const auto unsafe_jitter_head = prefer_safe && h.target_jitter && unsafe_head;

				// 2+ промаха по resolver: не safe голова этой цели не берётся вовсе.
				if ( h.avoid_unsafe_head && unsafe_head && !can_kill )
				{
					continue;
				}

				// Память промахов (spread) поднимает нужный hitchance для этой цели.
				// Lua override задаёт значение явно, его не трогаем.
				const auto hit_needed_hc = lua_hc ? needed_hc : std::min( needed_hc + h.extra_hc, 0.99f );
				const auto passes_hitchance = detail::ns_active( config ) || hc >= hit_needed_hc;
				auto score = passes_hitchance ? scoring::k_pass_hitchance : 0.0f;

				if ( can_kill )
				{
					// Смертельный хит — отдельный уровень выше головы. Между
					// двумя смертельными выбираем тело или голову по настройке.
					score += scoring::k_lethal_score + hc * scoring::k_hc_scale;
					const auto is_body = h.hitbox_index >= 1 && h.hitbox_index <= 6;
					const auto is_head = h.hitbox_index == 0;
					if ( prefer_body_lethal ? is_body : ( is_head && !unsafe_jitter_head ) )
					{
						score += scoring::k_lethal_pick_bonus;
					}
				}
				else
				{
					score += h.damage * hc * scoring::k_damage_hc_scale + h.damage * scoring::k_damage_base;
					score += unsafe_jitter_head ? 0.0f : hitgroup_priority( h.hitbox_index );
				}

				score += h.penetrated ? 0.0f : scoring::k_pen_direct;
				score += h.is_center ? scoring::k_center_score : 0.0f;
				score += ( prefer_safe && h.is_safe ) ? scoring::k_safe_bonus : 0.0f;
				score += h.priority * scoring::k_priority_scale;
				score -= h.fov * scoring::k_fov_score_penalty;

				// Backtrack age: fresher records are more reliable (smaller deviation
				// from the real position), so penalize older lag-comp records.
				// После промахов "lag compensation" по цели штраф намного сильнее.
				const auto current_tick = g_shared.ctx( ).current_tick;
				const auto record_age = std::abs( current_tick - h.record->tick );
				const auto age_penalty = h.record_age_mult > 1.0f ? scoring::k_lag_miss_age_penalty : scoring::k_record_age_penalty;
				score -= static_cast< float >( record_age ) * age_penalty;

				// Prefer the forward-extrapolated (server-time) record so the shot lands
			// where the enemy actually is when the server processes the command.
			// Non-extrapolated (newest networked) poses are already stale by
			// delta_ticks for moving targets, so aiming there misses fast movers.
			if ( h.record->extrapolated )
				{
					score += scoring::k_extrapolated_bonus;
				}

				evaluated.push_back( evaluated_hit{ idx, hc, score } );
			}
		}

		target best{};

		for ( const auto& e : evaluated )
		{
			if ( e.hit_index < 0 || e.hit_index >= static_cast< int >( hits.size( ) ) )
			{
				continue;
			}

			const auto& h = hits[ e.hit_index ];

			if ( !h.record || !h.record->valid )
			{
				continue;
			}

			auto is_better = !best.valid || e.score > best.score;
			if ( best.valid && std::fabsf( e.score - best.score ) < 0.01f )
			{
				if ( h.record->tick != best.hit.record->tick )
				{
					is_better = h.record->tick > best.hit.record->tick;
				}
				else if ( h.is_center != best.hit.is_center )
				{
					is_better = h.is_center;
				}
				else
				{
					is_better = h.fov < best.hit.fov;
				}
			}

			if ( is_better )
			{
				best.hit = h;
				best.hitchance = e.hitchance;
				best.score = e.score;
				best.valid = true;
			}
		}

		return best;
	}

	float rage::evaluate_hitchance( const scan_hit& hit, const aim_context& ctx, float inaccuracy ) const
	{
		if ( !hit.record || !hit.record->valid || hit.bone_index < 0 || hit.bone_index >= k_max_hitbox_bones )
		{
			return 0.0f;
		}

		return g_shared.calculate_hitchance( hit.source_eye.position, hit.aim_angle, hit.hitbox, hit.record->bones[ hit.bone_index ], inaccuracy, ctx.spread );
	}

	float rage::evaluate_hitchance_with_pen( const scan_hit& hit, const aim_context& ctx, float inaccuracy, const systems::local::snapshot& local ) const
	{
		const auto base_hc = this->evaluate_hitchance( hit, ctx, inaccuracy );

		if ( !hit.penetrated )
		{
			return base_hc; // Direct shots are not weakened by penetration.
		}

		// For wallbang targets, confirm that the spread cone also penetrates, not
		// just the exact center ray. Sample points inside the hitchance cone and
		// keep the fraction that still deals damage through the obstacle.
		//
		// The ring is trig on purpose: seeding these from calculate_spread is a
		// truer picture of the cone but costs an engine call per sample, on top
		// of the pen trace each one already runs, and this is called per
		// penetrated candidate across the whole scan. The centre sample is the
		// part worth keeping -- it is the single most likely bullet path, and a
		// ring alone never tested it.
		constexpr auto ring_samples = 8;
		constexpr auto sample_count = ring_samples + 1;
		auto passing = 0;

		const auto pen_ctx = g_shared.pen( ).prepare_target( hit.pawn, hit.record );

		const auto distance = ( hit.position - hit.source_eye.position ).length( );
		const auto spread_radius = std::tanf( inaccuracy + ctx.spread ) * distance;

		math::vector3 right{}, up{};
		math::helpers::angle_vectors_left( hit.aim_angle, nullptr, &right, &up );

		for ( auto i = 0; i < sample_count; ++i )
		{
			auto offset_x = 0.0f;
			auto offset_y = 0.0f;

			if ( i < ring_samples )
			{
				const auto angle = static_cast< float >( i ) / static_cast< float >( ring_samples ) * 6.2831853f;
				offset_x = std::cosf( angle ) * spread_radius * 0.5f;
				offset_y = std::sinf( angle ) * spread_radius * 0.5f;
			}

			const auto sample_target = hit.position + right * offset_x + up * offset_y;

			shared::penetration::result pen{};
			if ( g_shared.pen( ).run( hit.source_eye.position, sample_target, pen_ctx, local.pawn, local.team, pen ) )
			{
				if ( pen.damage >= 1.0f )
				{
					++passing;
				}
			}
		}

		const auto pen_factor = static_cast< float >( passing ) / static_cast< float >( sample_count );
		return base_hc * pen_factor;
	}

	float rage::validate_shot_cone( const target& tgt, const aim_context& ctx, float inaccuracy, const systems::local::snapshot& local ) const
	{
		if ( !tgt.valid || !tgt.hit.record )
		{
			return 1.0f;
		}

		// Penetrated candidates already had their cone sampled against the world
		// in evaluate_hitchance_with_pen, and their hitchance carries that factor
		// already -- applying it twice would square it.
		if ( tgt.hit.penetrated )
		{
			return 1.0f;
		}

		constexpr auto ring_samples = 8;
		constexpr auto sample_count = ring_samples + 1;

		const auto pen_ctx = g_shared.pen( ).prepare_target( tgt.hit.pawn, tgt.hit.record );

		const auto distance = ( tgt.hit.position - tgt.hit.source_eye.position ).length( );
		const auto spread_radius = std::tanf( inaccuracy + ctx.spread ) * distance;

		math::vector3 right{}, up{};
		math::helpers::angle_vectors_left( tgt.hit.aim_angle, nullptr, &right, &up );

		auto passing = 0;

		for ( auto i = 0; i < sample_count; ++i )
		{
			auto offset_x = 0.0f;
			auto offset_y = 0.0f;

			// The last sample is the centre -- the single most likely bullet path,
			// and the one a ring alone never tests.
			if ( i < ring_samples )
			{
				const auto angle = static_cast< float >( i ) / static_cast< float >( ring_samples ) * 6.2831853f;
				offset_x = std::cosf( angle ) * spread_radius * 0.5f;
				offset_y = std::sinf( angle ) * spread_radius * 0.5f;
			}

			const auto sample_target = tgt.hit.position + right * offset_x + up * offset_y;

			shared::penetration::result pen{};
			if ( g_shared.pen( ).run( tgt.hit.source_eye.position, sample_target, pen_ctx, local.pawn, local.team, pen )
				&& pen.damage >= 1.0f )
			{
				++passing;
			}
		}

		return static_cast< float >( passing ) / static_cast< float >( sample_count );
	}

	float rage::get_standing_inaccuracy( const systems::local::snapshot& local, const aim_context& ctx ) const
	{
		const auto& prestate = systems::g_prediction.pre( );
		auto velocity = prestate.networked_velocity;
		velocity.z = 0.0f;

		const auto speed = velocity.length_2d( );
		if ( speed > ctx.accurate_threshold )
		{
			return g_shared.get_inaccuracy_at_velocity( local.pawn, velocity );
		}

		const auto& shared_ctx = g_shared.ctx( );
		if ( !shared_ctx.weapon_vdata )
		{
			return ctx.predicted_inaccuracy;
		}

		const auto inaccuracy_stand = memory::read<float>( shared_ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flInaccuracyStand"_hash ) );
		return std::max( inaccuracy_stand, g_shared.get_inaccuracy_at_velocity( local.pawn, velocity ) );
	}

	std::vector<rage::scan_hit> rage::scan_taser( const math::vector3& eye, const aim_context& ctx, std::vector<candidate>& candidates, const systems::local::snapshot& local ) const
	{
		const auto& shared_ctx = g_shared.ctx( );
		std::vector<scan_hit> results;

		for ( auto& cand : candidates )
		{
			for ( auto ri = 0; ri < cand.record_count; ++ri )
			{
				auto* record = cand.records[ ri ];
				if ( !record || !record->valid )
				{
					continue;
				}

				const auto game_scene_node = memory::read<std::uintptr_t>( cand.pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
				if ( !game_scene_node )
				{
					continue;
				}

				const auto hitbox_set = systems::g_hitboxes.query( game_scene_node );
				if ( hitbox_set.count <= 0 )
				{
					continue;
				}

				record->apply( );
				const auto skeleton = g_shared.lc( ).get_skeleton( *record );

				for ( auto i = 0; i < hitbox_set.count; ++i )
				{
					const auto& hb = hitbox_set.entries[ i ];

					if ( hb.bone < 0 || hb.bone >= k_max_hitbox_bones )
					{
						continue;
					}

					const auto& bone = skeleton[ hb.bone ];
					if ( bone.position.length_sqr( ) < 1.0f )
					{
						continue;
					}

					const auto center = bone.rotation.rotate_vector( ( hb.mins + hb.maxs ) * 0.5f ) + bone.position;
					const auto aim = math::helpers::calculate_angle( eye, center );
					const auto fov = math::helpers::angle_distance( ctx.view_angles, aim );

					if ( fov > settings::g_combat.m_zeusbot.max_fov )
					{
						continue;
					}

					math::vector3 forward{};
					math::helpers::angle_vectors_left( aim, &forward );

					const auto trace = this->trace_taser_hit( eye, forward, shared_ctx.range * 0.85f, cand.pawn, local.pawn );
					if ( trace.hit_entity != cand.pawn )
					{
						continue;
					}

					const auto dist = ( center - eye ).length( );
					const auto range_fraction = dist / shared_ctx.range;

					scan_hit h{};
					h.position = center;
					h.aim_angle = aim;
					h.damage = 500.0f;
					h.score = ( 10000.0f - dist ) * ( range_fraction > 0.92f ? 0.8f : 1.0f );
					h.fov = fov;
					h.hitbox_index = hb.index;
					h.hitgroup = systems::g_hitboxes.hitgroup_from_hitbox( hb.index );
					h.bone_index = hb.bone;
					h.hitbox = hb;
					h.is_center = true;
					h.pawn = cand.pawn;
					h.health = cand.health;
					h.record = record;

					results.push_back( h );
				}

				record->restore( );
			}
		}

		return results;
	}

	rage::knife_info rage::get_knife_info( const systems::local::snapshot& local ) const
	{
		const auto& shared_ctx = g_shared.ctx( );
		const auto tick_base = memory::read<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase"_hash ) );
		const auto next_primary = memory::read<int>( shared_ctx.weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextPrimaryAttackTick"_hash ) );
		const auto next_secondary = memory::read<int>( shared_ctx.weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextSecondaryAttackTick"_hash ) );
		const auto last_shot_time = memory::read<float>( shared_ctx.weapon + SCHEMA( "C_CSWeaponBase", "m_fLastShotTime"_hash ) );
		const auto cur_time = static_cast< float >( tick_base ) * cstypes::tick_interval;

		return knife_info
		{
			.can_slash = tick_base >= next_primary,
			.can_stab = tick_base >= next_secondary,
			.charged = ( cur_time - last_shot_time ) > 0.4f,
			.armor_ratio = memory::read<float>( shared_ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flArmorRatio"_hash ) )
		};
	}

	std::vector<rage::scan_hit> rage::scan_knife( const math::vector3& eye, const aim_context& ctx, const knife_info& info, std::vector<candidate>& candidates, const systems::local::snapshot& local ) const
	{
		constexpr auto stab_range{ 50.0f };
		constexpr auto slash_range{ 66.0f };

		std::vector<scan_hit> results;

		for ( auto& cand : candidates )
		{
			const auto eye_angles = memory::read<math::vector3>( cand.pawn + SCHEMA( "C_CSPlayerPawn", "m_angEyeAngles"_hash ) );
			const auto hp = static_cast< float >( cand.health );

			const auto frontal_slash_dmg = this->get_knife_damage( info.charged ? 40.0f : 25.0f, cand.armor, info.armor_ratio );
			const auto frontal_stab_dmg = this->get_knife_damage( 65.0f, cand.armor, info.armor_ratio );
			const auto frontal_can_kill = ( info.can_slash && frontal_slash_dmg >= hp ) || ( info.can_stab && frontal_stab_dmg >= hp );

			for ( auto ri = 0; ri < cand.record_count; ++ri )
			{
				auto* record = cand.records[ ri ];
				if ( !record || !record->valid )
				{
					continue;
				}

				const auto game_scene_node = memory::read<std::uintptr_t>( cand.pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
				if ( !game_scene_node )
				{
					continue;
				}

				const auto hitbox_set = systems::g_hitboxes.query( game_scene_node );
				if ( hitbox_set.count <= 0 )
				{
					continue;
				}

				record->apply( );
				const auto skeleton = g_shared.lc( ).get_skeleton( *record );

				auto backstab{ false };
				{
					const auto delta = record->origin - systems::g_prediction.pre( ).origin;
					const auto dist_2d = std::sqrtf( delta.x * delta.x + delta.y * delta.y );

					if ( dist_2d > 0.001f )
					{
						const auto dir_x = delta.x / dist_2d;
						const auto dir_y = delta.y / dist_2d;

						math::vector3 body_forward{};
						math::helpers::angle_vectors_left( record->rotation, &body_forward );

						math::vector3 eye_forward{};
						math::helpers::angle_vectors_left( eye_angles, &eye_forward );

						backstab = ( dir_x * body_forward.x + dir_y * body_forward.y ) > 0.475f ||
							( dir_x * eye_forward.x + dir_y * eye_forward.y ) > 0.475f;
					}
				}

				const auto wait_for_backstab = backstab && !frontal_can_kill;

				for ( auto i = 0; i < hitbox_set.count; ++i )
				{
					const auto& hb = hitbox_set.entries[ i ];

					if ( hb.bone < 0 || hb.bone >= k_max_hitbox_bones )
					{
						continue;
					}

					const auto& bone = skeleton[ hb.bone ];
					if ( bone.position.length_sqr( ) < 1.0f )
					{
						continue;
					}

					const auto center = bone.rotation.rotate_vector( ( hb.mins + hb.maxs ) * 0.5f ) + bone.position;
					const auto dist = ( center - eye ).length( );
					const auto max_reach = info.can_slash ? slash_range : stab_range;

					if ( dist > max_reach )
					{
						continue;
					}

					const auto aim = math::helpers::calculate_angle( eye, center );
					const auto fov = math::helpers::angle_distance( ctx.view_angles, aim );

					if ( fov > settings::g_combat.m_knifebot.max_fov )
					{
						continue;
					}

					math::vector3 forward{};
					math::helpers::angle_vectors_left( aim, &forward );

					for ( const auto try_stab : { true, false } )
					{
						if ( try_stab && !info.can_stab )
						{
							continue;
						}

						if ( !try_stab && !info.can_slash )
						{
							continue;
						}

						const auto reach = try_stab ? stab_range : slash_range;
						if ( dist > reach )
						{
							continue;
						}

						const auto raw_dmg = try_stab ? ( backstab ? 180.0f : 65.0f ) : ( backstab ? 90.0f : ( info.charged ? 40.0f : 25.0f ) );
						const auto damage = this->get_knife_damage( raw_dmg, cand.armor, info.armor_ratio );
						const auto can_kill = damage >= hp;

						if ( wait_for_backstab && !can_kill )
						{
							continue;
						}

						const auto trace = this->trace_knife_hit( eye, forward, reach, cand.pawn, local.pawn );
						if ( trace.hit_entity != cand.pawn )
						{
							continue;
						}

						const auto reach_margin = 1.0f - ( dist / reach );

						scan_hit h{};
						h.position = center;
						h.aim_angle = aim;
						h.damage = damage;
						h.score = can_kill ? ( 10000.0f + damage * reach_margin ) : ( damage * 100.0f * reach_margin );
						h.fov = fov;
						h.hitbox_index = hb.index;
						h.hitgroup = systems::g_hitboxes.hitgroup_from_hitbox( hb.index );
						h.bone_index = hb.bone;
						h.hitbox = hb;
						h.is_center = true;
						h.is_backstab = backstab;
						h.attack_type = try_stab ? 1 : 0;
						h.pawn = cand.pawn;
						h.health = cand.health;
						h.record = record;

						results.push_back( h );
						break;
					}
				}

				record->restore( );
			}
		}

		return results;
	}

	void rage::fire_gun( systems::input::usercmd* cmd, const target& tgt, bool was_forced, const math::vector3& shoot_eye, const systems::local::snapshot& local, bool subtick_attack )
	{
		if ( !tgt.hit.record || !tgt.hit.record->valid )
		{
			return;
		}

		this->m_firing_this_tick = true;

		// Cache the target we committed to so next tick's scan can prioritize it.
		this->m_last_target_pawn = tgt.hit.pawn;
		this->m_last_target_hitbox = tgt.hit.hitbox_index;
		g_shared.res( ).on_shot_target_hitbox( tgt.hit.pawn, tgt.hit.hitbox_index );

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		const auto tick_base = memory::read<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase"_hash ) );
		const auto& shared_ctx = g_shared.ctx( );
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );
		const auto aim_punch = g_shared.get_aim_punch( local.pawn );
		const bool ns_on = detail::ns_active( config );
		auto aim_angle = ns_on ? math::helpers::calculate_angle( shoot_eye, tgt.hit.position ) : tgt.hit.aim_angle;
		const auto uncorrected_aim = aim_angle;

		// Для лога выстрелов: каким способом считали no-spread и для какого тика.
		auto meta_ns_mode = 0;
		auto meta_stamp_tick = tick_base;

		if ( ns_on )
		{
			// The seed has to be solved for the same tick the command is stamped
			// to, which is the interpolated backtrack tick whenever the shot is
			// aimed at a rewound record -- not our own client tick. The input
			// history entries below carry that stamp, and the server derives the
			// seed from them.
			auto stamp_tick = tick_base;
			auto stamp_frac{ 0.0f };

			if ( !tgt.hit.source_eye.is_uninterpolated )
			{
				std::tie( stamp_tick, stamp_frac ) = detail::tick_add( tgt.hit.source_eye.player_tick, tgt.hit.source_eye.player_frac, tgt.hit.source_eye.lerp_ticks_int, tgt.hit.source_eye.lerp_ticks_frac );
			}

			// Solve for the angle that goes on the wire, not for the one we aim at.
			//
			// The seed is a function of the view angles the command carries, and
			// what the command carries is aim_angle minus the accumulated punch --
			// the subtraction happens further down, and it used to happen after the
			// correction had already been verified against the un-subtracted angle.
			// While the punch is near zero the two are the same angle and the shot
			// lands; once it has built up they are different angles with different
			// seeds, and the compensation cancels a spread the weapon was never
			// going to use.
			//
			// That is exactly the shape the log has: no spread misses at all below a
			// five degree cone, and no compensation whatsoever above twelve -- the
			// cone is wide precisely when the punch has accumulated.
			meta_stamp_tick = stamp_tick;
			meta_ns_mode = 3;

			// Порт из "другого чита", где no-spread работал: сид решается от угла
			// прицеливания (с отдачей), разброс берётся на момент выстрела.
			const auto corrected = g_shared.find_spread_correction( aim_angle, stamp_tick, g_shared.get_inaccuracy( false ), g_shared.get_spread( ) );

			if ( corrected.x == 0.0f && corrected.y == 0.0f && corrected.z == 0.0f )
			{
				this->m_firing_this_tick = false;
				return;
			}

			// Put it back into aim space, so the punch subtraction below reproduces
			// `corrected` byte for byte and the wire carries the angle that was
			// actually verified.
			aim_angle = corrected;
		}

		g_shared.last_shoot_tick( ) = tick_base;

		// Lua: событие выстрела.
		scripting::on_shot( scripting::shot_event{
			tgt.hit.pawn,
			tgt.hit.hitgroup,
			tgt.hit.hitbox_index,
			tgt.hit.damage,
			tgt.hitchance,
			g_shared.ctx( ).current_tick - tgt.hit.record->tick } );

		// Номер выстрела: по нему строка "[rage] shot #N" связывается с итогом
		// "[shot #N] HIT/MISS" из лога попаданий.
		static int s_shot_id = 0;
		++s_shot_id;

		{
			features::misc::impacts::shot_meta meta{};
			meta.id = s_shot_id;
			meta.bt_ticks = g_shared.ctx( ).current_tick - tgt.hit.record->tick;
			meta.record_tick = tgt.hit.record->tick;
			meta.stamp_tick = meta_stamp_tick;
			meta.ns_mode = ns_on ? meta_ns_mode : 0;
			meta.doubletap = config.doubletap.value;
			meta.cone_deg = math::helpers::rad_to_deg( std::atanf( std::max( shared_ctx.inaccuracy, 0.0f ) + std::max( shared_ctx.spread, 0.0f ) ) );
			features::misc::g_impacts.set_next_shot_meta( meta );
		}

		if constexpr (k_enable_shot_logging)
		{
			const auto hitgroup_name = systems::g_hitboxes.hitgroup_to_name( tgt.hit.hitgroup );
			const auto bt_delta = g_shared.ctx( ).current_tick - tgt.hit.record->tick;
			logging::console::print(
				xs( "[rage] shot #{} target hp {} for {:.0f} in {} (hc {:.0f}%, bt {}t{})" ),
				s_shot_id,
				tgt.hit.health,
				tgt.hit.damage,
				hitgroup_name,
				tgt.hitchance * 100.0f,
				bt_delta,
				was_forced ? xs( ", forced" ) : ""
			);

			// Диагностика формулы урона: какие множители реально пошли в
			// scale_damage для этого выстрела. Сравнивать с "[shot #N] HIT ... for X".
			{
				const auto& wd = g_shared.pen( ).get_weapon_data( );
				const auto& sc = shared_ctx.scales;
				const auto t_armor = memory::read<int>( tgt.hit.pawn + SCHEMA( "C_CSPlayerPawn", "m_ArmorValue"_hash ) );
				const auto t_team = memory::read<int>( tgt.hit.pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum"_hash ) );
				auto t_helmet = false;
				if ( const auto services = memory::read<std::uintptr_t>( tgt.hit.pawn + SCHEMA( "C_BasePlayerPawn", "m_pItemServices"_hash ) ) )
				{
					t_helmet = memory::read<bool>( services + SCHEMA( "CCSPlayer_ItemServices", "m_bHasHelmet"_hash ) );
				}
				const auto dist = ( tgt.hit.position - shoot_eye ).length( );
				const auto head_max = g_shared.pen( ).get_max_damage( 1, t_armor, t_helmet, t_team );
				const auto chest_max = g_shared.pen( ).get_max_damage( 2, t_armor, t_helmet, t_team );

				// Пробитие: прогоняем симуляцию пули ещё раз для выбранной точки с
				// подробным логом записей. По ним сверяем с реальным уроном сервера.
				if ( tgt.hit.penetrated && tgt.hit.record )
				{
					auto dbg_ctx = g_shared.pen( ).prepare_target( tgt.hit.pawn, tgt.hit.record );
					dbg_ctx.debug_log = true;
					shared::penetration::result dbg_res{};
					( void )g_shared.pen( ).run( shoot_eye, tgt.hit.position, dbg_ctx, local.pawn, local.team, dbg_res );
				}

				// Какой порог реально действовал: группа оружия, min damage из
				// конфига, override, Lua. Нужен, чтобы понять, почему выстрел в тело
				// на 92 прошёл при min damage 101.
				{
					const auto group_idx = settings::g_combat.m_ragebot.group_index_for( shared_ctx.item_def_idx, shared_ctx.weapon_type );
					const auto lua_md = scripting::min_damage_override( );
					const auto used_md = lua_md
						? std::min( *lua_md, static_cast< float >( tgt.hit.health ) + 1.0f )
						: this->get_min_damage( config, tgt.hit.health, config.min_damage_override.value );
					logging::console::print(
						xs( "[md-diag] shot #{} item_def={} weapon_type={} group={} cfg_min={} override_on={} override_val={} lua={} -> min_used={:.0f} | target hp={} predicted={:.0f}" ),
						s_shot_id, shared_ctx.item_def_idx, shared_ctx.weapon_type, group_idx,
						config.min_damage.value, config.min_damage_override.value, config.min_damage_override_value.value,
						lua_md ? *lua_md : -1.0f, used_md, tgt.hit.health, tgt.hit.damage );
				}

				logging::console::print(
					xs( "[dmg-diag] shot #{} wpn dmg={:.0f} hs_mult={:.2f} armor_ratio={:.2f} range_mod={:.3f} range={:.0f} | target armor={} helmet={} team={} dist={:.0f}u | scales ct_head={:.2f} t_head={:.2f} ct_body={:.2f} t_body={:.2f} | max_head={:.0f} max_chest={:.0f} | aimed hb={} hg={} pen={}" ),
					s_shot_id,
					wd.damage, wd.headshot_multiplier, wd.armor_ratio, wd.range_modifier, wd.range,
					t_armor, t_helmet, t_team, dist,
					sc.ct_head, sc.t_head, sc.ct_body, sc.t_body,
					head_max, chest_max,
					tgt.hit.hitbox_index, tgt.hit.hitgroup, tgt.hit.penetrated
				);
			}
		}

		// В лог промахов отдаём направление на цель, а не угол с поправкой на
		// разброс: с no-spread пуля должна уйти именно туда, и отклонение (dev)
		// надо мерить от него. Раньше dev считался от уже сдвинутого угла и при
		// рабочем no-spread выглядел как обычный разброс.
		features::misc::g_impacts.on_boom( tgt.hit.pawn, tgt.hit.hitgroup, tgt.hit.damage, tgt.hitchance, shared_ctx.inaccuracy, shared_ctx.spread, uncorrected_aim, shoot_eye, tgt.hit.record->tick, g_shared.lc( ).get_skeleton( *tgt.hit.record ), was_forced );
		features::esp::player::g_chams.os ().push (tgt.hit.pawn);
		const auto record_time = cstypes::tick_fraction::from_value( tgt.hit.record->simulation_time / cstypes::tick_interval );
		const auto history_size = cmd->csgo_user_cmd.input_history_size( );
		for ( auto i = 0; i < history_size; ++i )
		{
			const auto entry = cmd->csgo_user_cmd.mutable_input_history( i );
			if ( !entry )
			{
				continue;
			}

			if ( const auto angles = entry->mutable_view_angles( ) )
			{
				angles->set_x( aim_angle.x - aim_punch.x );
				angles->set_y( aim_angle.y - aim_punch.y );

				if ( ns_on )
				{
					angles->set_z( aim_angle.z );
				}
			}

			this->stamp_input_entry( entry, record_time, tgt.hit.source_eye );
		}

		const auto quick_revolver = shared_ctx.item_def_idx == cstypes::item_definition_index::weapon_r8_revolver
			&& settings::g_combat.m_autos.revolver_quick.value;

		if ( !subtick_attack )
		{

			// Hand the cone we solved for to the calibrator, so the engine hook can
			// say how far off it was once this shot actually goes out.
			g_shared.note_pending_shot( shared_ctx.inaccuracy, quick_revolver, tick_base );

			// The hook has stayed silent across three sessions, and silence has too
			// many explanations: never fired, fired and agreed, or never asked
			// because the flag below was false. Say what this side saw, so the next
			// log rules out at least this half.
			if ( shared_ctx.item_def_idx == cstypes::item_definition_index::weapon_r8_revolver )
			{
				static std::atomic<std::uint32_t> revolver_shots{};
				const auto n = revolver_shots.fetch_add( 1, std::memory_order_relaxed ) + 1;

				if ( n <= 5 || ( n % 25 ) == 0 )
				{
					const auto mode_offset = SCHEMA( "C_CSWeaponBase", "m_weaponMode"_hash );
					const auto live_mode = mode_offset > 0
						? memory::read<int>( shared_ctx.weapon + mode_offset )
						: -1;

					// pitch_fix is deg( atan( |spread| ) ) -- the exact size of the
					// deviation no_spread believes it cancelled. Hold it against the
					// dev= figure in the miss line: equal magnitudes mean the amount
					// was right and only the direction was lost, which is a roll
					// problem; different magnitudes mean the cone itself is wrong.
					char line[ 256 ]{};
					_snprintf_s( line, sizeof( line ), _TRUNCATE,
						"[revolver] fire #%u: quick=%d live_mode=%d inacc=%.5f spread=%.5f pitch_fix=%.2fdeg roll=%.2fdeg punch=%.2f,%.2f",
						n, quick_revolver ? 1 : 0, live_mode,
						shared_ctx.inaccuracy, shared_ctx.spread,
						aim_angle.x - uncorrected_aim.x, aim_angle.z,
						aim_punch.x, aim_punch.y );
					diag::step( line );
				}
			}

			const auto attack_button = quick_revolver
				? cstypes::command_buttons::in_second_attack
				: cstypes::command_buttons::in_attack;

			cmd->buttons.value |= attack_button;
			cmd->buttons.value_changed |= attack_button;
			cmd->buttons.value_scroll |= attack_button;

			if ( history_size > 0 )
			{
				// The server reads the shot out of the history entry this index
				// points at, and it looks at a different field per button. Naming
				// the wrong one leaves the shot with no angles attached.
				if ( quick_revolver )
				{
					cmd->csgo_user_cmd.set_attack2_start_history_index( history_size - 1 );

					// Never leave the primary index pointing at an entry as well --
					// two live indices let the server pick the shot we did not send.
					cmd->csgo_user_cmd.set_attack1_start_history_index( -1 );
				}
				else
				{
					cmd->csgo_user_cmd.set_attack1_start_history_index( history_size - 1 );
				}
			}

			// Wire state after every mutation, not before. Roll being present in the
			// entry the index names is the one thing that cannot be inferred from
			// this side of the correction.
			if ( quick_revolver )
			{
				static std::atomic<std::uint32_t> wire{};
				const auto w = wire.fetch_add( 1, std::memory_order_relaxed ) + 1;

				if ( w <= 5 || ( w % 25 ) == 0 )
				{
					const auto idx = cmd->csgo_user_cmd.attack2_start_history_index( );
					const auto named = ( idx >= 0 && idx < history_size )
						? cmd->csgo_user_cmd.mutable_input_history( idx )
						: nullptr;
					const auto named_angles = named ? named->mutable_view_angles( ) : nullptr;

					char line[ 240 ]{};
					_snprintf_s( line, sizeof( line ), _TRUNCATE,
						"[revolver] wire #%u: hist=%d a2=%d a1=%d entry_roll=%.2f held_attack1=%d",
						w, history_size, idx,
						cmd->csgo_user_cmd.attack1_start_history_index( ),
						named_angles ? named_angles->z( ) : -999.0f,
						( cmd->buttons.value & cstypes::command_buttons::in_attack ) ? 1 : 0 );
					diag::step( line );
				}
			}
		}

		math::vector3 forward{};
		{
			if ( const auto angles = base->viewangles( ) )
			{
				math::helpers::angle_vectors_left( { angles->x( ), angles->y( ), angles->z( ) }, &forward );
			}
		}

		// Roll normally rides in the input history entries and nowhere else, because
		// that is where the server reads an attack1 shot from -- and leaving the
		// command angles flat keeps the view upright for everything else.
		//
		// The revolver's quick shot is judged from attack2, and every sign points
		// at the server taking those angles from the command rather than from the
		// history entry: the compensation is computed, the fixed point verifies,
		// and the bullet still lands with the full width of the cone in a random
		// direction. That is precisely what losing the roll looks like -- the pitch
		// half of the correction is applied while the half that aims it is not.
		const auto carry_roll_in_command = ns_on && quick_revolver;
		const auto punched_aim = math::vector3{
			aim_angle.x - aim_punch.x,
			aim_angle.y - aim_punch.y,
			carry_roll_in_command ? aim_angle.z : 0.0f
		};
		const auto facing_away = forward.dot( ( tgt.hit.record->origin - systems::g_prediction.pre( ).networked_origin ).normalized( ) ) < 0.707107f;

		auto command_aim = punched_aim;
		if ( !subtick_attack && facing_away && settings::g_combat.m_antiaim.hide_shots.value )
		{
			command_aim.x = 179.9f;
			command_aim.y = std::remainderf( punched_aim.y + 180.0f, 360.0f );
		}

		if ( const auto angles = base->mutable_viewangles( ) )
		{
			// FIX: АА уже повернул движение под свой угол. Меняем угол команды
			// на угол прицела и доворачиваем движение, иначе на тике выстрела
			// персонажа тянет вбок (сильнее всего при manual ±90 и hide_shots).
			const auto previous_yaw = angles->y( );

			angles->set_x( command_aim.x );
			angles->set_y( command_aim.y );

			if ( carry_roll_in_command )
			{
				angles->set_z( command_aim.z );
			}

			move_basis::rotate_command( base, previous_yaw, command_aim.y );
			if ( systems::g_prediction.pre( ).flags & cstypes::entity_flags::on_ground )
			{
				move_basis::set_move_buttons( cmd->buttons.value, base->forwardmove( ), base->leftmove( ) );
			}
		}

		if ( !config.silent.value )
		{
			systems::g_input.set_view_angles( punched_aim );
		}
	}

	void rage::fire_melee( systems::input::usercmd* cmd, const target& tgt, const systems::local::snapshot& local )
	{
		if ( !tgt.hit.record || !tgt.hit.record->valid )
		{
			return;
		}

		this->m_firing_this_tick = true;

		const auto base = cmd->csgo_user_cmd.mutable_base( );
		const auto tick_base = memory::read<int>( local.controller + SCHEMA( "CBasePlayerController", "m_nTickBase"_hash ) );

		g_shared.last_shoot_tick( ) = tick_base;

		const auto record_time = cstypes::tick_fraction::from_value( tgt.hit.record->simulation_time / cstypes::tick_interval );
		const auto history_index = cmd->csgo_user_cmd.input_history_size( ) - 1;
		const auto entry = history_index >= 0 ? cmd->csgo_user_cmd.mutable_input_history( history_index ) : nullptr;

		if ( entry )
		{
			if ( const auto angles = entry->mutable_view_angles( ) )
			{
				angles->set_x( tgt.hit.aim_angle.x );
				angles->set_y( tgt.hit.aim_angle.y );
			}

			this->stamp_input_entry( entry, record_time, tgt.hit.source_eye );

		}

		const auto is_secondary = tgt.hit.attack_type == 1;
		const auto attack_button = is_secondary
			? cstypes::command_buttons::in_second_attack
			: cstypes::command_buttons::in_attack;

		cmd->buttons.value |= attack_button;
		cmd->buttons.value_changed |= attack_button;
		cmd->buttons.value_scroll |= attack_button;

		if ( history_index >= 0 )
		{
			if ( is_secondary )
			{
				cmd->csgo_user_cmd.set_attack2_start_history_index( history_index );
			}
			else
			{
				cmd->csgo_user_cmd.set_attack1_start_history_index( history_index );
			}
		}

		if ( const auto angles = base->mutable_viewangles( ) )
		{
			const auto previous_yaw = angles->y( );

			angles->set_x( tgt.hit.aim_angle.x );
			angles->set_y( tgt.hit.aim_angle.y );

			// FIX: то же, что в fire_gun: доворачиваем движение под новый угол.
			move_basis::rotate_command( base, previous_yaw, tgt.hit.aim_angle.y );
			if ( systems::g_prediction.pre( ).flags & cstypes::entity_flags::on_ground )
			{
				move_basis::set_move_buttons( cmd->buttons.value, base->forwardmove( ), base->leftmove( ) );
			}
		}
	}

	template <typename Entry>
	void rage::stamp_input_entry(
		Entry* entry,
		const cstypes::tick_fraction& record_time,
		const shared::shoot_history::eye_candidate& source_eye ) const
	{
		entry->set_render_tick_count( record_time.tick + 1 );
		entry->set_render_tick_fraction( 0.0f );

		if ( !source_eye.is_uninterpolated )
		{
			const auto [stamp_tick, stamp_frac] = detail::tick_add(
				source_eye.player_tick, source_eye.player_frac,
				source_eye.lerp_ticks_int, source_eye.lerp_ticks_frac );

			entry->set_player_tick_count( stamp_tick );
			entry->set_player_tick_fraction( stamp_frac );
		}

		if ( entry->has_sv_interp0( ) )
		{
			const auto interp = entry->mutable_sv_interp0( );
			interp->set_src_tick( -1 );
			interp->set_dst_tick( -1 );
			interp->set_frac( 0.0f );
		}

		if ( entry->has_sv_interp1( ) )
		{
			const auto interp = entry->mutable_sv_interp1( );
			interp->set_src_tick( -1 );
			interp->set_dst_tick( -1 );
			interp->set_frac( 0.0f );
		}

		if ( entry->has_cl_interp( ) )
		{
			const auto interp = entry->mutable_cl_interp( );
			interp->set_frac( 0.0f );
		}
	}

	namespace detail {

		// Насколько враг целится в нас: 0 — смотрит в сторону (>20 градусов),
		// 1 — прицел прямо на нас (<6 градусов). Плавно, без порога.
		inline float enemy_threat( std::uintptr_t pawn, const math::vector3& enemy_origin, const math::vector3& local_eye )
		{
			const auto view_offset = memory::read<math::vector3>( pawn + SCHEMA( "C_BaseModelEntity", "m_vecViewOffset"_hash ) );
			const auto enemy_eye = enemy_origin + view_offset;
			const auto to_us = local_eye - enemy_eye;
			const auto dist = to_us.length( );
			if ( dist < 1.0f )
			{
				return 1.0f;
			}

			const auto eye_angles = memory::read<math::vector3>( pawn + SCHEMA( "C_CSPlayerPawn", "m_angEyeAngles"_hash ) );
			math::vector3 forward{};
			math::helpers::angle_vectors_left( eye_angles, &forward );

			const auto cos_angle = forward.dot( to_us * ( 1.0f / dist ) );
			constexpr auto k_cos_20 = 0.9397f;
			constexpr auto k_cos_6 = 0.9945f;
			return std::clamp( ( cos_angle - k_cos_20 ) / ( k_cos_6 - k_cos_20 ), 0.0f, 1.0f );
		}

	} // namespace detail

	float rage::target_priority( const candidate& cand, const math::vector3& local_eye ) const
	{
		if ( !cand.pawn || cand.record_count <= 0 || !cand.records[ 0 ] )
		{
			return 0.0f;
		}

		const auto& origin = cand.records[ 0 ]->origin;
		const auto dist = ( origin - local_eye ).length( );

		// Кто целится в нас — опаснее всех. Ближний опаснее дальнего. Раненого
		// проще добить. Прошлая цель чуть важнее, чтобы бот не метался между
		// двумя равными врагами каждый тик.
		const auto threat = detail::enemy_threat( cand.pawn, origin, local_eye );
		const auto dist_score = std::clamp( 1.0f - dist / 3000.0f, 0.0f, 1.0f );
		const auto hp_score = std::clamp( 1.0f - static_cast< float >( cand.health ) / 100.0f, 0.0f, 1.0f );
		const auto sticky = cand.pawn == this->m_last_target_pawn ? 1.0f : 0.0f;

		return threat * 0.40f + dist_score * 0.25f + hp_score * 0.20f + sticky * 0.15f;
	}

	bool rage::apply_autoscope( systems::input::usercmd* cmd, const target& best, const settings::combat::ragebot::weapon_group& config )
	{
		if ( !best.valid || !settings::g_combat.m_autos.scope.value || !config.auto_scope.value )
		{
			return false;
		}

		const auto& sc = g_shared.ctx( );
		if ( sc.weapon_type != cstypes::weapon_type::sniper || sc.is_scoped || !sc.weapon )
		{
			return false;
		}

		// No-spread: разброс и так убран, прицел не нужен.
		if ( detail::ns_active( config ) )
		{
			return false;
		}

		if ( memory::read<int>( sc.weapon + SCHEMA( "C_CSWeaponBaseGun", "m_zoomLevel"_hash ) ) > 0 )
		{
			return false;
		}

		// Прицел переключается нажатием: нажали один раз и ждём, пока игра
		// его включит. Нажать снова сразу — значит тут же выключить. Если за
		// 8 тиков прицел не появился (перезарядка, затвор), жмём ещё раз.
		const auto tick = sc.current_tick;
		const auto since_press = tick - this->m_scope_press_tick;
		if ( since_press >= 0 && since_press < 8 )
		{
			return true;
		}

		this->m_scope_press_tick = tick;
		this->m_scope_release_pending = true;
		++this->m_scope_press_count;

		cmd->buttons.value |= cstypes::command_buttons::in_second_attack;
		cmd->buttons.value_changed |= cstypes::command_buttons::in_second_attack;
		cmd->buttons.value_scroll |= cstypes::command_buttons::in_second_attack;

		// Сервер берёт нажатие attack2 из записи input history, на которую
		// указывает этот индекс (так же, как выстрел attack1). Без индекса
		// нажатие прицела могло просто теряться.
		const auto history_size = cmd->csgo_user_cmd.input_history_size( );
		if ( history_size > 0 )
		{
			cmd->csgo_user_cmd.set_attack2_start_history_index( history_size - 1 );
		}

		if ( settings::g_misc.m_interface.shot_log.value && ( this->m_scope_press_count <= 10 || this->m_scope_press_count % 20 == 0 ) )
		{
			logging::console::print( xs( "[autoscope] press #{} | zoom_level {} scoped {} | history {} | next_secondary {} tick {}" ),
				this->m_scope_press_count,
				memory::read<int>( sc.weapon + SCHEMA( "C_CSWeaponBaseGun", "m_zoomLevel"_hash ) ),
				sc.is_scoped, history_size,
				memory::read<int>( sc.weapon + SCHEMA( "C_BasePlayerWeapon", "m_nNextSecondaryAttackTick"_hash ) ),
				tick );
		}

		return true;
	}

	bool rage::future_lethal_exposure( const aim_context& ctx, const target& best, const systems::local::snapshot& local, int ticks )
	{
		const auto pawn = best.hit.pawn;
		if ( !pawn || ticks <= 0 )
		{
			return false;
		}

		const auto records = g_shared.lc( ).get_valid_records( pawn );
		if ( records.empty( ) || !records.front( ) || !records.front( )->valid )
		{
			return false;
		}

		const auto* base = records.front( );

		// Стоящая цель через пару тиков будет там же: ждать нечего.
		const auto velocity = memory::read<math::vector3>( pawn + SCHEMA( "C_BaseEntity", "m_vecVelocity"_hash ) );
		if ( velocity.length_2d( ) < 20.0f )
		{
			return false;
		}

		math::vector3 obb_mins{ -16.0f, -16.0f, 0.0f };
		math::vector3 obb_maxs{ 16.0f, 16.0f, 72.0f };
		if ( const auto collision = memory::read<std::uintptr_t>( pawn + SCHEMA( "C_BaseEntity", "m_pCollision"_hash ) ) )
		{
			obb_mins = memory::read<math::vector3>( collision + SCHEMA( "CCollisionProperty", "m_vecMins"_hash ) );
			obb_maxs = memory::read<math::vector3>( collision + SCHEMA( "CCollisionProperty", "m_vecMaxs"_hash ) );
		}

		const auto delta = g_shared.lc( ).predict_position_physics( pawn, base->origin, velocity, base->flags, obb_mins, obb_maxs, ticks );
		if ( delta.length_2d( ) < 2.0f )
		{
			return false;
		}

		// Будущая поза: та же анимация, сдвинутая на предсказанное смещение.
		// Отдельная копия, чтобы автовол проверял хитбоксы именно в ней.
		this->m_timing_record = *base;
		this->m_timing_record.origin = base->origin + delta;
		this->m_timing_record.extrapolated = true;
		for ( auto i = 0; i < this->m_timing_record.bone_count && i < k_max_skeleton_bones; ++i )
		{
			this->m_timing_record.bones[ i ].position += delta;
		}

		const auto game_scene_node = memory::read<std::uintptr_t>( pawn + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !game_scene_node )
		{
			return false;
		}

		const auto hitbox_set = systems::g_hitboxes.query( game_scene_node );
		const auto skeleton = g_shared.lc( ).get_skeleton( this->m_timing_record );
		const auto pen_ctx = g_shared.pen( ).prepare_target( pawn, &this->m_timing_record );

		const auto& sc = g_shared.ctx( );
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( sc.item_def_idx, sc.weapon_type );
		const auto head_allowed = config.hitboxes.values[ 0 ]
			&& !config.body_aim.value
			&& !g_shared.res( ).should_force_body_aim( pawn )
			&& !scripting::force_body_aim( )
			&& !best.hit.avoid_unsafe_head;
		const auto chest_allowed = config.hitboxes.values[ 1 ];

		const auto& eye = best.hit.source_eye.position;
		const auto health = static_cast< float >( best.hit.health );

		for ( const auto hitbox_index : { 0, 4, 5, 6 } )
		{
			if ( hitbox_index == 0 ? !head_allowed : !chest_allowed )
			{
				continue;
			}

			for ( const auto& entry : hitbox_set )
			{
				if ( entry.index != hitbox_index || entry.bone < 0 || entry.bone >= k_max_hitbox_bones )
				{
					continue;
				}

				const auto& bone = skeleton[ entry.bone ];
				if ( bone.position.length_sqr( ) < 1.0f )
				{
					break;
				}

				const auto center = bone.rotation.rotate_vector( ( entry.mins + entry.maxs ) * 0.5f ) + bone.position;
				const auto aim = math::helpers::calculate_angle( eye, center );
				if ( math::helpers::angle_distance( ctx.view_angles, aim ) > config.max_fov )
				{
					break;
				}

				shared::penetration::result pen{};
				if ( g_shared.pen( ).run( eye, center, pen_ctx, local.pawn, local.team, pen ) && pen.damage >= health )
				{
					return true;
				}

				break;
			}
		}

		return false;
	}

	bool rage::should_delay_shot( const aim_context& ctx, const target& best, const systems::local::snapshot& local )
	{
		const auto& rb = settings::g_combat.m_ragebot;

		const auto reset = [ this ]( )
			{
				this->m_hold_pawn = 0;
				this->m_hold_ticks = 0;
			};

		const auto cooldown = [ this ]( std::uintptr_t pawn, int until )
			{
				this->m_hold_cooldown_pawn = pawn;
				this->m_hold_cooldown_until = until;
			};

		// Ждать есть смысл только за не смертельным выстрелом не в голову:
		// смертельный стреляем сразу, а голову лучше уже не найти.
		if ( !rb.shot_timing.value || !best.valid || best.is_lethal( ) || best.hit.hitbox_index == 0 )
		{
			reset( );
			return false;
		}

		const auto pawn = best.hit.pawn;
		const auto tick = g_shared.ctx( ).current_tick;
		const auto max_ticks = std::clamp( rb.shot_timing_ticks.value, 1, 8 );

		// Враг целится в нас — каждый тик ожидания это его шанс выстрелить первым.
		const auto enemy_origin = best.hit.record ? best.hit.record->origin : math::vector3{};
		if ( detail::enemy_threat( pawn, enemy_origin, best.hit.source_eye.position ) >= 0.5f )
		{
			reset( );
			return false;
		}

		if ( this->m_hold_pawn && this->m_hold_pawn != pawn )
		{
			reset( );
		}

		if ( this->m_hold_pawn == pawn )
		{
			// Время вышло: стреляем тем, что есть, и какое-то время по этой цели
			// больше не ждём.
			if ( this->m_hold_ticks >= max_ticks )
			{
				cooldown( pawn, tick + 32 );
				reset( );
				return false;
			}
		}
		else if ( pawn == this->m_hold_cooldown_pawn && tick < this->m_hold_cooldown_until && this->m_hold_cooldown_until - tick <= 64 )
		{
			return false;
		}

		// Проверяем середину и конец оставшегося окна ожидания.
		const auto remaining = std::max( max_ticks - this->m_hold_ticks, 1 );
		const auto half = std::max( ( remaining + 1 ) / 2, 1 );
		const auto promising = this->future_lethal_exposure( ctx, best, local, half )
			|| ( remaining != half && this->future_lethal_exposure( ctx, best, local, remaining ) );

		if ( !promising )
		{
			if ( this->m_hold_pawn == pawn )
			{
				cooldown( pawn, tick + 16 );
			}

			reset( );
			return false;
		}

		this->m_hold_pawn = pawn;
		++this->m_hold_ticks;
		return true;
	}

	void rage::on_target_miss( std::uintptr_t pawn, std::string_view reason )
	{
		if ( !pawn || reason.empty( ) )
		{
			return;
		}

		// Причины из impacts::classify_shot_deviation. Остальные ("death",
		// "forced", "impact mismatch", "prediction error", "shoot position
		// mismatch") не про цель, а про нас, и память по цели не меняют.
		enum class kind { none, spread, occlusion, resolver, lagcomp };
		auto k = kind::none;

		if ( reason.starts_with( "spread" ) )
		{
			k = kind::spread;
		}
		else if ( reason == "occlusion" || reason.starts_with( "impact too close" ) )
		{
			k = kind::occlusion;
		}
		else if ( reason == "server discrepancy" )
		{
			// Пуля прошла через хитбокс нашей записи, а сервер попадания не
			// засчитал: модель была в другом положении (анти-аим / резольвер).
			k = kind::resolver;
		}
		else if ( reason == "lag compensation" )
		{
			k = kind::lagcomp;
		}

		if ( k == kind::none )
		{
			return;
		}

		const auto now = detail::now_seconds( );

		std::lock_guard lock( this->m_miss_mtx );

		// Не даём таблице расти: старые записи чистим при каждом промахе.
		for ( auto it = this->m_miss_memory.begin( ); it != this->m_miss_memory.end( ); )
		{
			if ( now - it->second.last_miss > detail::k_miss_memory_ttl )
			{
				it = this->m_miss_memory.erase( it );
			}
			else
			{
				++it;
			}
		}

		auto& e = this->m_miss_memory[ pawn ];
		const auto bump = [ ]( int& v ) { v = std::min( v + 1, 3 ); };

		switch ( k )
		{
		case kind::spread:    bump( e.spread ); break;
		case kind::occlusion: bump( e.occlusion ); break;
		case kind::resolver:  bump( e.resolver ); break;
		case kind::lagcomp:   bump( e.lagcomp ); break;
		default: break;
		}

		e.last_miss = now;
	}

	void rage::on_target_hit( std::uintptr_t pawn )
	{
		if ( !pawn )
		{
			return;
		}

		// Попадание показывает, что текущая подстройка работает: ослабляем
		// память на шаг, а не стираем целиком, иначе следующий выстрел снова
		// пойдёт тем способом, которым мы промахивались.
		std::lock_guard lock( this->m_miss_mtx );
		const auto it = this->m_miss_memory.find( pawn );
		if ( it == this->m_miss_memory.end( ) )
		{
			return;
		}

		auto& e = it->second;
		const auto drop = [ ]( int& v ) { v = std::max( v - 1, 0 ); };
		drop( e.spread );
		drop( e.occlusion );
		drop( e.resolver );
		drop( e.lagcomp );

		if ( !e.spread && !e.occlusion && !e.resolver && !e.lagcomp )
		{
			this->m_miss_memory.erase( it );
		}
	}

	void rage::generate_multipoints( const systems::hitboxes::entry& hitbox, const math::vector3& center, const math::quaternion& bone_rot, float pointscale, const math::vector3& shoot_pos, float inaccuracy, std::vector<math::vector3>& out ) const
	{
		out.clear( );

		auto scale = std::clamp( pointscale / 100.0f, 0.0f, 1.0f );
		if ( scale <= 0.01f )
		{
			return;
		}

		const auto hb_mid   = ( hitbox.mins + hitbox.maxs ) * 0.5f;
		const auto capsule_a = center + bone_rot.rotate_vector( hitbox.mins - hb_mid );
		const auto capsule_b = center + bone_rot.rotate_vector( hitbox.maxs - hb_mid );

		// Keep points inside the part of the hitbox reachable by the full spread cone.
		const auto& config = settings::g_combat.m_ragebot.get_group_by_weapon( g_shared.ctx( ).item_def_idx, g_shared.ctx( ).weapon_type );
		if ( config.dynamic_pointscale.value && hitbox.radius > 0.001f )
		{
			const auto cone = std::max( inaccuracy + g_shared.ctx( ).spread, 0.0f );
			const auto cone_radius = std::tanf( cone ) * ( center - shoot_pos ).length( );
			const auto automatic_scale = std::clamp( 0.9f - cone_radius / hitbox.radius, 0.0f, 1.0f );
			scale = std::min( scale, automatic_scale );

			if ( scale <= 0.01f )
			{
				return;
			}
		}

		// Build a view-relative frame so points rotate correctly above and below us.
		const auto shoot_dir = ( center - shoot_pos ).normalized( );
		const auto ang       = math::helpers::vector_to_angle( shoot_dir );

		math::vector3 left{}, up{};
		math::helpers::angle_vectors_left( ang, nullptr, &left, &up );

		// angle_vectors_left returns left, so negate it for right.
		const auto right = math::vector3{ -left.x, -left.y, -left.z };

		// Trace from outside through the center to find the real capsule surface.
		// This is accurate around rounded end caps, where radius offsets are not.
		const auto surface_point = [ & ]( const math::vector3& direction ) -> math::vector3
		{
			const auto dir = direction.normalized( );

			if ( hitbox.radius > 0.001f )
			{
				const auto reach = ( capsule_b - capsule_a ).length( ) + hitbox.radius * 2.0f + 1.0f;
				const auto origin = center + dir * reach;
				const auto delta = dir * ( reach * -2.0f );
				auto fraction{ 1.0f };

				if ( g_shared.ray_vs_capsule( origin, delta, capsule_a, capsule_b, hitbox.radius, fraction ) )
				{
					return origin + delta * fraction;
				}
			}
			else
			{
				// Intersect box hitboxes in bone space using their directional support.
				auto inverse = bone_rot;
				inverse.x = -inverse.x;
				inverse.y = -inverse.y;
				inverse.z = -inverse.z;
				const auto local_dir = inverse.rotate_vector( dir );
				const auto extents = ( hitbox.maxs - hitbox.mins ) * 0.5f;
				auto distance = 8192.0f;

				if ( std::fabs( local_dir.x ) > 1.0e-6f ) distance = std::min( distance, std::fabs( extents.x / local_dir.x ) );
				if ( std::fabs( local_dir.y ) > 1.0e-6f ) distance = std::min( distance, std::fabs( extents.y / local_dir.y ) );
				if ( std::fabs( local_dir.z ) > 1.0e-6f ) distance = std::min( distance, std::fabs( extents.z / local_dir.z ) );

				if ( distance < 8192.0f )
				{
					return center + dir * distance;
				}
			}

			return center;
		};

		const auto scaled_surface = [ & ]( const math::vector3& direction )
		{
			const auto surface = surface_point( direction );
			return center + ( surface - center ) * scale;
		};

		switch ( hitbox.index )
		{
		case 0: // head
		{
			// Nine points. Four sides alone leave the corners of the capsule
			// silhouette uncovered, which is exactly where a tight cone at range
			// lands. The extra traces only run when the centre point did not
			// already score a direct kill -- see center_sufficient in scan_player.
			out.reserve( 9 );
			out.push_back( scaled_surface( right ) );
			out.push_back( scaled_surface( -right ) );
			out.push_back( scaled_surface( up ) );
			out.push_back( scaled_surface( -up ) );

			out.push_back( scaled_surface( ( right + up ).normalized( ) ) );
			out.push_back( scaled_surface( ( -right + up ).normalized( ) ) );
			out.push_back( scaled_surface( ( right + -up ).normalized( ) ) );
			out.push_back( scaled_surface( ( -right + -up ).normalized( ) ) );

			// shoot_dir points from us to the head, so this lands on the near face
			// of the head capsule (toward the enemy's front when they face us, or
			// their back when they face away) — the side most likely to connect.
			out.push_back( scaled_surface( shoot_dir ) );
			break;
		}

		case 2: case 3: // stomach / pelvis
		{
			out.reserve( 4 );
			out.push_back( scaled_surface( right ) );
			out.push_back( scaled_surface( -right ) );
			out.push_back( scaled_surface( up ) );
			out.push_back( scaled_surface( -up ) );
			break;
		}

		case 4: case 5: case 6: // chest
		{
			out.reserve( 5 );
			out.push_back( scaled_surface( right ) );
			out.push_back( scaled_surface( -right ) );
			out.push_back( scaled_surface( up ) );
			out.push_back( scaled_surface( -up ) );
			if ( hitbox.index == 6 )
			{
				out.push_back( scaled_surface( shoot_dir ) );
			}
			break;
		}

		case 7: case 8: case 9: case 10: case 11: case 12: // legs / feet
		{
			out.reserve( 2 );
			out.push_back( capsule_a );
			out.push_back( capsule_b );
			break;
		}

		case 13: case 14: case 15: case 16: case 17: case 18: // arms
		{
			out.reserve( 1 );
			out.push_back( capsule_b );
			break;
		}

		default:
		{
			out.reserve( 2 );
			out.push_back( scaled_surface( right ) );
			out.push_back( scaled_surface( -right ) );
			break;
		}
		}

		return;
	}

	bool rage::should_stop_for_target( const aim_context& ctx, const target& best_target ) const
	{
		if ( !this->should_stop_movement( ctx ) )
		{
			return false;
		}

		if ( !best_target.valid )
		{
			return true;
		}

		const auto& prestate = systems::g_prediction.pre( );
		const auto velocity = prestate.networked_velocity;
		const auto speed = velocity.length_2d( );

		if ( speed < 1.0f )
		{
			return false;
		}

		// Direction we are moving in (flattened to the ground plane).
		const auto move_dir = math::vector3{ velocity.x / speed, velocity.y / speed, 0.0f };

		// Direction from us to the target.
		const auto to_target = best_target.hit.position - prestate.origin;
		const auto dist_2d = std::sqrtf( to_target.x * to_target.x + to_target.y * to_target.y );

		if ( dist_2d < 1.0f )
		{
			return true; // Practically on top of the target, just stop.
		}

		const auto target_dir = math::vector3{ to_target.x / dist_2d, to_target.y / dist_2d, 0.0f };
		const auto dot = move_dir.x * target_dir.x + move_dir.y * target_dir.y;

		// Moving strongly sideways or away from the target: always stop.
		if ( dot < 0.3f )
		{
			return true;
		}

		// Moving toward a distant target: approaching improves hitchance on later
		// ticks, so there is no need to kill our momentum right now.
		if ( dot > 0.7f && dist_2d > 1500.0f )
		{
			return false;
		}

		return true;
	}

	bool rage::should_stop_movement( const aim_context& ctx ) const
	{
		const auto& shared_ctx = g_shared.ctx( );
		const auto& prestate = systems::g_prediction.pre( );
		const auto velocity = prestate.networked_velocity;

		if ( shared_ctx.weapon_type == cstypes::weapon_type::sniper && !ctx.is_scoped )
		{
			return false;
		}

		// Per-weapon stop mode. This is the one place the decision is made, so
		// restricting it here covers every caller rather than each of them having
		// to remember the setting.
		const auto& stop_config = settings::g_combat.m_ragebot.get_group_by_weapon( shared_ctx.item_def_idx, shared_ctx.weapon_type );
		const auto stop_mode = stop_config.auto_stop_mode.value;

		if ( stop_mode == 2 && ctx.on_ground )
		{
			return false;
		}

		if ( stop_mode == 3 && !ctx.on_ground )
		{
			return false;
		}

		{
			const auto predicted_speed = std::sqrtf( ctx.velocity.x * ctx.velocity.x + ctx.velocity.y * ctx.velocity.y );
			if ( predicted_speed <= ctx.accurate_threshold )
			{
				return false;
			}
		}

		if ( ctx.on_ground )
		{
			const auto speed_2d = velocity.length_2d( );
			if ( speed_2d <= 0.1f )
			{
				return false;
			}

			if ( !shared_ctx.weapon_vdata )
			{
				return speed_2d > ctx.accurate_threshold;
			}

			// The comparison this replaces multiplied a speed in units per second
			// by a move-inaccuracy coefficient and held the result against a bare
			// standing cone. Those are not the same quantity: for a rifle the left
			// side lands around 25 and the right around 0.02, so it was true for
			// any movement at all. "auto" and "early" therefore did exactly the
			// same thing -- brake the instant we pass the accuracy threshold --
			// which is the mode behaving badly rather than the threshold being
			// wrong.
			//
			// Express it as a fraction instead, which is dimensionless and honest.
			// Movement adds no cone at all below 34% of max speed; that is what
			// accurate_threshold already encodes, and the guard above has cleared
			// it. Past that point the penalty grows with how far into the
			// remaining speed range we are.
			const auto max_speed = ctx.weapon_max_speed > 1.0f ? ctx.weapon_max_speed : 250.0f;
			const auto free_zone = ctx.accurate_threshold;
			const auto span = std::max( max_speed - free_zone, 1.0f );
			const auto move_ratio = std::clamp( ( speed_2d - free_zone ) / span, 0.0f, 1.0f );

			// Эту функцию спрашивают только когда выстрел уже невозможен из-за
			// разброса (!shot_viable). Запас 45% в режиме auto означал, что скаут
			// на 78..147 u/s не тормозил вообще: стоял в прицеле с hc 10% и
			// умирал. Поэтому тормозим сразу за порогом точности в обоих режимах.
			( void )move_ratio;
			return speed_2d > free_zone;
		}

		if ( shared_ctx.weapon_type != cstypes::weapon_type::sniper )
		{
			return false;
		}

		if ( !shared_ctx.weapon_vdata )
		{
			return false;
		}

		// Still rising: too early to plan a stop.
		if ( velocity.z > 120.0f )
		{
			return false;
		}

		const auto sv_gravity = CONVAR ("sv_gravity")->get<float>( );
		const auto sv_friction = CONVAR ("sv_friction")->get<float>( );
		const auto sv_stopspeed = CONVAR ("sv_stopspeed")->get<float>( );

		const auto inac_jump_initial = memory::read<float>( shared_ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flInaccuracyJumpInitial"_hash ) );
		const auto inac_jump_apex = memory::read<float>( shared_ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flInaccuracyJumpApex"_hash ) );

		const auto shootable_threshold = inac_jump_apex + 0.001f;
		const auto air_inaccuracy = g_shared.get_air_inaccuracy( velocity.z, inac_jump_initial, inac_jump_apex );

		const auto speed_2d = velocity.length_2d( );
		const auto max_speed = memory::read<float>( shared_ctx.weapon_vdata + SCHEMA( "CCSWeaponBaseVData", "m_flMaxSpeed"_hash ) );
		const auto accurate_threshold = max_speed * 0.34f;

		// Glide: we are already inside the accuracy window, so asking movement to
		// brake here buys nothing and kills the strafe. This used to return true,
		// which is what made the aimbot stall in mid-air instead of shooting and
		// flying on.
		if ( air_inaccuracy <= shootable_threshold )
		{
			return false;
		}

		// "early" restores the pre-apex trigger: brake as soon as the cone is on
		// its way in rather than waiting for the last moment that still lands.
		if ( stop_mode == 1 )
		{
			const auto early_threshold = inac_jump_initial * 0.55f + inac_jump_apex * 0.45f;
			if ( air_inaccuracy <= early_threshold )
			{
				return true;
			}
		}

		// Horizontal speed is already fine, so there is nothing to brake off.
		if ( speed_2d <= accurate_threshold )
		{
			return false;
		}

		auto sim_vz = velocity.z;
		auto ticks_to_shootable{ 0 };

		for ( auto i = 1; i <= 32; ++i )
		{
			sim_vz -= sv_gravity * cstypes::tick_interval;

			if ( g_shared.get_air_inaccuracy( sim_vz, inac_jump_initial, inac_jump_apex ) <= shootable_threshold )
			{
				ticks_to_shootable = i;
				break;
			}
		}

		if ( ticks_to_shootable == 0 )
		{
			return false;
		}

		auto sim_speed = speed_2d;
		auto ticks_to_stop{ 32 };

		for ( auto i = 1; i <= 32; ++i )
		{
			const auto drop = std::fmaxf( sim_speed, sv_stopspeed ) * sv_friction * cstypes::tick_interval;
			sim_speed -= drop;

			if ( sim_speed <= accurate_threshold )
			{
				ticks_to_stop = i;
				break;
			}
		}

		// Late stop: brake at the last moment that still lands the shot at the apex.
		// The old +2 committed a tick earlier than needed.
		return ticks_to_shootable <= ticks_to_stop + 1;
	}

	// Раз в секунду, пока есть живой враг, а рейдж не стреляет: на каком шаге
	// цель отвалилась. Без этого "ни разу не выстрелил" не отличить от
	// "не видит", "нет записей lagcomp", "мало урона" или "за стеной".
	void rage::log_no_target( const std::vector<candidate>& candidates, const char* stage )
	{
		if ( !settings::g_misc.m_interface.shot_log.value )
		{
			return;
		}

		const auto& gs = this->m_gather_stats;
		if ( gs.enemies_alive <= 0 )
		{
			return;
		}

		const auto tick = g_shared.ctx( ).current_tick;
		if ( tick - this->m_no_target_log_tick < 64 && tick >= this->m_no_target_log_tick )
		{
			return;
		}
		this->m_no_target_log_tick = tick;

		logging::console::print(
			xs( "[no-target] {} | enemies alive {} immune {} no_records {} too_far {} scanned {}" ),
			stage, gs.enemies_alive, gs.immune, gs.no_records, gs.too_far, candidates.size( ) );

		for ( const auto& c : candidates )
		{
			const auto speed = memory::read<math::vector3>( c.pawn + SCHEMA( "C_BaseEntity", "m_vecAbsVelocity"_hash ) ).length_2d( );
			const auto flags = memory::read<std::uint32_t>( c.pawn + SCHEMA( "C_BaseEntity", "m_fFlags"_hash ) );
			logging::console::print(
				xs( "[no-target]   hp {} speed {:.0f} ground {} | records valid {} scanned {} extrap {} | points {} fov_rej {} trace_rej {} dmg_rej {} edge_rej {} | min_fov {:.1f} max_dmg {:.0f} need {:.0f}" ),
				c.health, speed, ( flags & cstypes::entity_flags::on_ground ) != 0,
				c.dbg_valid_records, c.record_count, c.dbg_extrapolated,
				c.dbg_points, c.dbg_fov_reject, c.dbg_trace_reject, c.dbg_damage_reject, c.dbg_edge_reject,
				c.dbg_min_fov, c.dbg_max_damage, c.min_damage );
		}
	}

	float rage::get_min_damage( const settings::combat::ragebot::weapon_group& config, int target_health, bool override_active ) const
	{
		if ( override_active )
		{
			return static_cast< float >( config.min_damage_override_value );
		}

		const auto base = static_cast< float >( config.min_damage );

		const auto hp = static_cast< float >( target_health );
		if ( hp < base )
		{
			return hp + 1.0f;
		}

		return base;
	}

	float rage::get_knife_damage( float raw, int armor, float armor_ratio ) const
	{
		if ( armor <= 0 )
		{
			return raw;
		}

		const auto ratio = armor_ratio * 0.5f;
		auto damage_to_health = raw * ratio;
		const auto damage_to_armor = ( raw - damage_to_health ) * 0.5f;

		if ( damage_to_armor > static_cast< float >( armor ) )
		{
			damage_to_health = raw - static_cast< float >( armor ) * 2.0f;
		}

		return std::max( 0.0f, std::floorf( damage_to_health ) );
	}

	systems::tracing::result rage::trace_taser_hit( const math::vector3& origin, const math::vector3& forward, float range, std::uintptr_t target_pawn, std::uintptr_t local_pawn ) const
	{
		const auto end = origin + forward * range;
		const int filter_extras[ ]{ 0, 15 };

		for ( const auto extra : filter_extras )
		{
			const auto filter = extra == 0 ? systems::g_tracing.make_filter( local_pawn, 0x001c1003, 4 ) : systems::g_tracing.make_filter( local_pawn, 0x001c1003, 4, 15 );
			auto result = systems::g_tracing.trace( origin, end, filter );

			if ( ( result.fraction < 1.0f || result.all_solid ) && result.hit_entity == target_pawn )
			{
				return result;
			}

			for ( auto radius = 2.0f; radius <= 4.0f; radius += 2.0f )
			{
				const auto sweep_end = end - forward * radius;
				result = systems::g_tracing.trace_sphere( origin, sweep_end, radius, filter );

				if ( ( result.fraction < 1.0f || result.all_solid ) && result.hit_entity == target_pawn )
				{
					return result;
				}
			}
		}

		systems::tracing::result miss{};
		miss.fraction = 1.0f;
		miss.hit_entity = 0;
		return miss;
	}

	systems::tracing::result rage::trace_knife_hit( const math::vector3& origin, const math::vector3& forward, float reach, std::uintptr_t target_pawn, std::uintptr_t local_pawn ) const
	{
		const auto end = origin + forward * reach;
		const auto knife_filter = systems::g_tracing.make_filter( local_pawn, 0x0c3001, 4 );
		auto result = systems::g_tracing.trace( origin, end, knife_filter );

		if ( ( result.fraction < 1.0f || result.all_solid ) && result.hit_entity == target_pawn )
		{
			return result;
		}

		const auto weapon_filter = systems::g_tracing.make_filter( local_pawn, 0x0c3001, 4, 15 );
		result = systems::g_tracing.trace( origin, end, weapon_filter );

		if ( ( result.fraction < 1.0f || result.all_solid ) && result.hit_entity == target_pawn )
		{
			return result;
		}

		for ( auto radius = 14.0f; radius > 0.0f; radius -= 3.0f )
		{
			const auto sweep_end = end - forward * radius;
			result = systems::g_tracing.trace_sphere( origin, sweep_end, radius, weapon_filter );

			if ( ( result.fraction < 1.0f || result.all_solid ) && result.hit_entity == target_pawn )
			{
				return result;
			}
		}

		result.fraction = 1.0f;
		result.hit_entity = 0;
		return result;
	}

	void rage::update_penetration_crosshair( const systems::local::snapshot& local )
	{
		const auto& cfg = settings::g_combat.m_penetration_crosshair;
		const auto& ctx = g_shared.ctx( );

		if ( !cfg.enabled.value || !ctx.valid || !local.is_alive || local.team < 2
			|| !local.pawn || !ctx.weapon
			|| ctx.weapon_type < cstypes::weapon_type::pistol || ctx.weapon_type > cstypes::weapon_type::lmg )
		{
			this->m_penetration_crosshair_state.store( penetration_crosshair_state::unavailable, std::memory_order_relaxed );
			return;
		}

		// get_shoot_position() can be zero before prediction has populated the
		// weapon-services shoot history. The crosshair needs the current eye now.
		const auto eye_pos = g_shared.get_eye_position( local.pawn );
		auto view_angles = systems::g_input.get_view_angles( );
		const auto aim_punch = g_shared.get_aim_punch( local.pawn );
		view_angles.x += aim_punch.x;
		view_angles.y += aim_punch.y;

		math::vector3 forward{};
		math::helpers::angle_vectors_left( view_angles, &forward );

		auto pen_damage{ 0.0f };
		const auto can_pen = g_shared.pen( ).can( eye_pos, forward, pen_damage, local );
		this->m_penetration_crosshair_state.store(
			can_pen ? penetration_crosshair_state::penetrable : penetration_crosshair_state::blocked,
			std::memory_order_relaxed );
	}

	void rage::draw_penetration_crosshair( xdraw::draw_list& draw_list ) const
	{
		const auto& cfg = settings::g_combat.m_penetration_crosshair;
		if ( !cfg.enabled.value )
		{
			return;
		}

		const auto state = this->m_penetration_crosshair_state.load( std::memory_order_relaxed );
		const auto local = systems::g_local.get( );
		if ( state == penetration_crosshair_state::unavailable || !local.is_alive || systems::g_local.is_in_cinematic( ) )
		{
			return;
		}

		const auto can_pen = state == penetration_crosshair_state::penetrable;

		const auto& fill = can_pen ? cfg.can_penetrate_fill : cfg.blocked_fill;
		const auto& outline = can_pen ? cfg.can_penetrate_outline : cfg.blocked_outline;
		const auto [ screen_w, screen_h ] = xdraw::viewport_size( );
		const auto cx = std::floorf( static_cast< float >( screen_w ) * 0.5f );
		const auto cy = std::floorf( static_cast< float >( screen_h ) * 0.5f );
		constexpr auto half_size{ 3.0f };
		constexpr auto outline_size{ 1.0f };

		if ( cfg.glow )
		{
			auto& glow = xdraw::get_glow( );
			const auto glow_a = static_cast< std::uint8_t >( static_cast< float >( outline.value.a ) * cfg.glow_strength );
			const auto glow_col = xdraw::color{ outline.value.r, outline.value.g, outline.value.b, glow_a };

			glow.rect_filled( cx - half_size - outline_size, cy - half_size - outline_size,
				( half_size + outline_size ) * 2.0f, ( half_size + outline_size ) * 2.0f, glow_col );
		}

		draw_list.rect_filled( cx - half_size - outline_size, cy - half_size - outline_size,
			( half_size + outline_size ) * 2.0f, ( half_size + outline_size ) * 2.0f, outline );
		draw_list.rect_filled( cx - half_size, cy - half_size, half_size * 2.0f, half_size * 2.0f, fill );
	}

} // namespace features::combat
