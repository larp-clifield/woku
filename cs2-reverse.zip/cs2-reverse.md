# CS2 Reverse Engineering

Этот документ содержит описание архитектуры, логику работы внутренних систем движка и воссозданный псевдокод ключевых функций. Содержит только статичную логику, пригодную для создания софтов. Динамические данные (оффсеты, сигнатуры, паттерны) отсутствуют.

## Список сущностей (Entity List)

Список сущностей разбит на двухуровневые сегменты (чанки). Каждый чанк содержит максимум 512 слотов. Каждый слот имеет размер 112 байт. Первые 8 байт слота содержат указатель на саму сущность. Смещение +0x10 содержит 32-битный индекс/хэндл сущности для валидации.

```cpp
C_BaseEntity* ResolveEntityIndex(CEntityList* entityList, int targetIndex)
{
    if (targetIndex == INVALID_HANDLE || targetIndex == SPECIAL_HANDLE)
        return nullptr;

    uintptr_t chunkDir = entityList->m_pChunks[(targetIndex & INDEX_MASK) >> CHUNK_SHIFT];
    if (!chunkDir)
        return nullptr;

    uintptr_t slot = chunkDir + SLOT_SIZE * (targetIndex & SLOT_MASK);
    if (slot->m_nIndex != targetIndex)
        return nullptr;

    return slot->m_pEntity;
}
```

## Кости и скелет игрока (Skeletal System)

Кости привязаны к сцене и модели. Указатель на ноду сцены лежит в пешке игрока. Для анимированных объектов этот указатель приводится к классу `CSkeletonInstance`. Указатель на массив костей (Bone Array) лежит внутри `CSkeletonInstance`. Каждая кость в массиве представлена структурой `CTransform` размером ровно 32 байта (Vector4D позиция и Vector4D кватерниона вращения).

```cpp
struct CTransform
{
    float position[4];
    float rotation[4];
};

CTransform* GetBoneArray(CSkeletonInstance* skeletonInstance)
{
    if (!skeletonInstance)
        return nullptr;
    return skeletonInstance->m_modelState.m_pBoneArray;
}

void CopyBoneTransform(CTransform* boneArray, int boneIndex, CTransform* outTransform)
{
    CTransform* bone = &boneArray[boneIndex];
    outTransform->position[0] = bone->position[0];
    outTransform->position[1] = bone->position[1];
    outTransform->position[2] = bone->position[2];
    outTransform->position[3] = bone->position[3];
    outTransform->rotation[0] = bone->rotation[0];
    outTransform->rotation[1] = bone->rotation[1];
    outTransform->rotation[2] = bone->rotation[2];
    outTransform->rotation[3] = bone->rotation[3];
}
```

## Матрица вида и World-To-Screen (W2S)

Матрица вида (ViewMatrix) представляет собой плоский массив из 16 элементов типа float (размер 64 байта), расположенных в row-major формате. Движок полностью исключает расчет координаты clip.z для 2D-проекции на экран.

```cpp
bool WorldToScreen(const float* worldPos, float* screenPosOut, const float* viewMatrix, float width, float height)
{
    float clipX = viewMatrix[0] * worldPos[0] + viewMatrix[1] * worldPos[1] + viewMatrix[2] * worldPos[2] + viewMatrix[3];
    float clipY = viewMatrix[4] * worldPos[0] + viewMatrix[5] * worldPos[1] + viewMatrix[6] * worldPos[2] + viewMatrix[7];
    float clipW = viewMatrix[12] * worldPos[0] + viewMatrix[13] * worldPos[1] + viewMatrix[14] * worldPos[2] + viewMatrix[15];

    if (clipW < 0.001f)
        return false;

    float invW = 1.0f / clipW;
    float ndcX = clipX * invW;
    float ndcY = clipY * invW;

    screenPosOut[0] = (width * 0.5f) + (ndcX * (width * 0.5f));
    screenPosOut[1] = (height * 0.5f) - (ndcY * (height * 0.5f));
    return true;
}
```

## Архитектура игрока: Контроллеры и Пешки (Controllers & Pawns)

Движок полностью разделяет сетевое представление игрока и его физическое воплощение в игровом мире.

- **CCSPlayerController**: Стабильный объект. Создается при подключении игрока и существует до его выхода с сервера. Хранит метаданные (имя, SteamID, статистику, пинг, команду).
- **C_CSPlayerPawn**: Временный физический объект персонажа в мире. Создается при каждом спавне и уничтожается при смерти. Хранит здоровье, координаты, оружие, скелет и данные хитбоксов.

Для нахождения пешки из контроллера используется логика битового маскирования хэндла `m_hPawn`.

```cpp
C_CSPlayerPawn* GetPawnFromController(CCSPlayerController* controller, CEntityList* entityList)
{
    if (!controller || !entityList)
        return nullptr;

    uint32_t pawnHandle = controller->m_hPawn;
    if (pawnHandle == INVALID_HANDLE)
        return nullptr;

    int pawnIndex = pawnHandle & INDEX_MASK;
    return reinterpret_cast<C_CSPlayerPawn*>(ResolveEntityIndex(entityList, pawnIndex));
}
```

## Система типов движка (Schema System)

Source 2 использует встроенную систему рефлексии для хранения информации о структурах, классах, полях и смещениях. Обход этой системы позволяет динамически получать смещения во время выполнения.

```cpp
struct SchemaClassFieldData_t
{
    const char* m_pszName;
    CSchemaType* m_pSchemaType;
    int32_t m_nOffset;
    int32_t m_nMetadataCount;
    void* m_pMetadata;
};

struct SchemaBaseClassInfoData_t
{
    int32_t m_nOffset;
    SchemaClassInfoData_t* m_pClass;
};

struct SchemaClassInfoData_t
{
    void* m_pVTable;
    const char* m_pszName;
    const char* m_pszModuleName;
    CSchemaType* m_pSchemaType;
    int32_t m_nSize;
    int16_t m_nFieldCount;
    int16_t m_nStaticFieldCount;
    uint8_t m_nMetadataCount;
    uint8_t m_nBaseClassesCount;
    int16_t m_nDerivationLevel;
    int16_t m_nInheritanceDepth;
    int16_t m_pad0;
    SchemaClassFieldData_t* m_pFields;
    SchemaBaseClassInfoData_t* m_pBaseClasses;
    void* m_pMetadata;
    void* m_pStaticFields;
    CSchemaSystemTypeScope* m_pSchemaTypeScope;
    CSchemaType* m_pSchemaType2;
    uint32_t m_nFlags;
    int32_t m_pad1;
    void* m_pfnCallback;
};

struct CSchemaType
{
    void* m_pVTable;
    const char* m_pszName;
    CSchemaSystemTypeScope* m_pTypeScope;
    uint8_t m_nTypeCategory;
    uint8_t m_nETypeCategory;
    uint8_t m_pad0[6];
};

class CSchemaSystemTypeScope
{
public:
    SchemaClassInfoData_t* FindDeclaredClass(const char* name)
    {
        using FindDeclaredClass_t = SchemaClassInfoData_t*(__fastcall*)(CSchemaSystemTypeScope*, const char*);
        auto fn = reinterpret_cast<FindDeclaredClass_t>((*reinterpret_cast<void***>(this))[VTABLE_FIND_DECLARED_CLASS]);
        return fn(this, name);
    }

    const char* GetName()
    {
        using GetName_t = const char*(__fastcall*)(CSchemaSystemTypeScope*);
        auto fn = reinterpret_cast<GetName_t>((*reinterpret_cast<void***>(this))[VTABLE_GET_NAME]);
        return fn(this);
    }
};

class ISchemaSystem
{
public:
    CSchemaSystemTypeScope* FindTypeScopeForModule(const char* name)
    {
        using FindTypeScopeForModule_t = CSchemaSystemTypeScope*(__fastcall*)(ISchemaSystem*, const char*, void*);
        auto fn = reinterpret_cast<FindTypeScopeForModule_t>((*reinterpret_cast<void***>(this))[VTABLE_FIND_TYPE_SCOPE]);
        return fn(this, name, nullptr);
    }
};
```

## Субтик-движение и пользовательский ввод (Subtick UserCmd)

Передача команд управления заменена на Protobuf-сообщения, содержащие субтик-данные и историю ввода для точной интерполяции и симуляции выстрелов.

```cpp
struct CSubtickMoveStep
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t button;
    bool pressed;
    float when;
    float analog_forward_delta;
    float analog_left_delta;
    float pitch_delta;
    float yaw_delta;
};

struct CInButtonStatePB
{
    uint32_t has_bits;
    uint32_t cached_size;
    uint64_t buttonstate1;
    uint64_t buttonstate2;
    uint64_t buttonstate3;
};

struct CMsgQAngle
{
    uint32_t has_bits;
    uint32_t cached_size;
    float x;
    float y;
    float z;
};

struct CBaseUserCmdPB
{
    uint32_t has_bits;
    uint32_t cached_size;
    RepeatedPtrField_t<CSubtickMoveStep> subtick_moves;
    std::string* move_crc;
    CInButtonStatePB* buttons_pb;
    CMsgQAngle* viewangles;
    CBaseUserCmdPB* execution_notes;
    int32_t legacy_command_number;
    int32_t client_tick;
    float forwardmove;
    float leftmove;
    float upmove;
    int32_t impulse;
    int32_t weaponselect;
    int32_t random_seed;
    int32_t mousedx;
    int32_t mousedy;
    uint32_t prediction_offset_ticks_x256;
    uint32_t consumed_server_angle_changes;
    int32_t cmd_flags;
    uint32_t pawn_entity_handle;
};

struct CSGOInputHistoryEntryPB
{
    uint32_t has_bits;
    uint32_t cached_size;
    CMsgQAngle* view_angles;
    CSGOInterpolationInfoPB_CL* cl_interp;
    CSGOInterpolationInfoPB* sv_interp0;
    CSGOInterpolationInfoPB* sv_interp1;
    CSGOInterpolationInfoPB* player_interp;
    CMsgVector* shoot_position;
    CMsgVector* target_head_pos_check;
    CMsgVector* target_abs_pos_check;
    CMsgQAngle* target_abs_ang_check;
    int32_t render_tick_count;
    float render_tick_fraction;
    int32_t player_tick_count;
    float player_tick_fraction;
    int32_t frame_number;
    int32_t target_ent_index;
};

struct CSGOUserCmdPB
{
    uint32_t has_bits;
    uint32_t cached_size;
    RepeatedPtrField_t<CSGOInputHistoryEntryPB> input_history;
    CBaseUserCmdPB* base;
    bool left_hand_desired;
    bool is_predicting_body_shot_fx;
    bool is_predicting_head_shot_fx;
    bool is_predicting_kill_ragdolls;
    int32_t attack1_start_history_index;
    int32_t attack2_start_history_index;
};
```

## Консольные переменные (ConVars)

Движок хранит зарегистрированные консольные переменные во внутренней хэш-таблице `IEngineCvar`. Прямой обход позволяет обходить флаг скрытия консольных переменных без модификации кода функций поиска.

```cpp
struct CVValue_t
{
    bool i1;
    short i16;
    uint16_t u16;
    int i32;
    uint32_t u32;
    int64_t i64;
    uint64_t u64;
    float fl;
    double db;
    const char* sz;
    ColorVal clr;
    Vec2 vec2;
    Vec3 vec3;
    Vec4 vec4;
    QAngle_t ang;
};

class CConVar
{
public:
    const char* szName;
    CVValue_t* m_pDefaultValue;
    const char* szDescription;
    uint32_t nType;
    uint32_t nRegistered;
    uint32_t nFlags;
    CVValue_t value;
};

class IEngineCvar
{
public:
    CConVar* Find(const char* name)
    {
        uint16_t size = this->m_nSize & SIZE_MASK;
        Node_t* nodes = this->m_pNodes;
        if (!nodes)
            return nullptr;

        for (uint16_t i = 0; i < size; i++)
        {
            CConVar* pConVar = nodes[i].pConVar;
            if (pConVar && pConVar->szName && strcmp(pConVar->szName, name) == 0)
                return pConVar;
        }
        return nullptr;
    }

    void UnlockHiddenCVars()
    {
        uint16_t size = this->m_nSize & SIZE_MASK;
        Node_t* nodes = this->m_pNodes;
        if (!nodes)
            return;

        for (uint16_t i = 0; i < size; i++)
        {
            CConVar* pConVar = nodes[i].pConVar;
            if (pConVar && (pConVar->nFlags & FCVAR_HIDDEN))
                pConVar->nFlags &= ~FCVAR_HIDDEN;
        }
    }
};
```

## Сервисы перемещения игрока (CCSPlayer_MovementServices)

Смещение физических полей и логика применения гравитации внутри игрового тика.

```cpp
namespace CCSPlayerMovementServices
{
    inline void AddGravity(CPlayer_MovementServices* pMovementServices, CMoveData* pMoveData)
    {
        C_BasePlayerPawn* pPlayerPawn = pMovementServices->m_pOuter;
        if (!pPlayerPawn)
            return;

        CCSPlayer_WaterServices* pWaterServices = pPlayerPawn->m_pWaterServices;
        if (!pWaterServices || pWaterServices->m_flWaterJumpTime == 0.0f)
        {
            float flGravityScale = pPlayerPawn->m_flActualGravityScale;
            float flGravityValue = sv_gravity.GetFloat() * flGravityScale;

            pMoveData->m_vecVelocity.z -= flGravityValue * gpGlobals->interval_per_tick;
            pMoveData->m_vecContinousAcceleration.z -= flGravityValue;

            float vecBaseVelocityOut[3];
            CBaseEntity::GetBaseVelocity(pPlayerPawn, vecBaseVelocityOut);

            pMoveData->m_vecVelocity.z += vecBaseVelocityOut[2] * gpGlobals->interval_per_tick;
            pMoveData->m_vecContinousAcceleration.z += vecBaseVelocityOut[2];

            float vecBaseVelocityTemp[3] = { vecBaseVelocityOut[0], vecBaseVelocityOut[1], 0.0f };
            CBaseEntity::SetBaseVelocity(pPlayerPawn, vecBaseVelocityTemp);

            PostGravityUpdate(pMovementServices, pMoveData, "AddGravity");
        }
    }
}
```

## Получение позиции кости по имени

Цепочка: из пешки извлекается `CGameSceneNode`. Из `CGameSceneNode` через vtable получается `CModelState`. В `CModelState` находится указатель на хэш-таблицу костей. Имя кости хэшируется функцией CRC32. По хэшу из таблицы извлекается мировая позиция.

```cpp
Vector GetBonePositionByName(C_CSPlayerPawn* pawn, const char* boneName)
{
    CGameSceneNode* pSceneNode = pawn->m_pGameSceneNode;
    if (!pSceneNode)
        return Vector{};

    CModelState* pModelState = pSceneNode->GetModelState();
    if (!pModelState)
        return Vector{};

    unsigned int hash = 0;
    if (boneName && *boneName)
        hash = CRC32(boneName, CRC_SEED);

    uintptr_t* pTable = pModelState->m_pBoneHashTable;
    if (!pTable || !*pTable)
        return Vector{INVALID_FLOAT, INVALID_FLOAT, INVALID_FLOAT};

    return GetBonePositionFromTable(*pTable, hash);
}
```

## Трассировка и проверка видимости

Подготавливает структуру луча и фильтр, вызывает внутренний трассировщик движка.

```cpp
void CreateTrace(Ray_t* ray, CTraceFilter* filter, GameTrace_t* trace)
{
    InitGameTrace(trace);
    trace->m_pEnt = nullptr;
    TraceRayInternal(ray, filter, trace);
    TraceFinalize(trace);
}

void GameTraceLine(Vector* start, Vector* end, CTraceFilter* filter, GameTrace_t* trace)
{
    InitTraceFilter(filter);
    ExecuteTrace(start, end, filter, trace);
}

void TraceGetInfo(GameTrace_t* trace, TraceInfo_t* info)
{
    info->m_pEnt = trace->m_pEnt;
    info->m_HitGroup = trace->m_HitGroup;
}
```

## Разброс и неточность

Вычисление текущей неточности оружия и генерация углов разброса для серии выстрелов.

```cpp
float GetInaccuracy(C_CSWeaponBase* weapon)
{
    float baseInaccuracy = weapon->GetBaseInaccuracy();
    float movementPenalty = CalcMovementPenalty(weapon->GetPlayer());
    float speedPenalty = GetSpeedPenalty(weapon->GetPlayer());

    float totalInaccuracy = baseInaccuracy + movementPenalty + speedPenalty;
    return ClampFloat(totalInaccuracy, 0.0f, 1.0f);
}

void CalcSpread(uint16_t weaponId, int numBullets, int randomSeed, float inaccuracy, float spread, float* outAngles)
{
    RandomSeed(randomSeed);
    for (int i = 0; i < numBullets; i++)
    {
        float r1 = RandomFloat();
        float r2 = RandomFloat();

        float spreadRad = r1 * inaccuracy;
        float angleRad = r2 * 2.0f * PI;

        outAngles[i * 2] = cosf(angleRad) * spreadRad;
        outAngles[i * 2 + 1] = sinf(angleRad) * spreadRad;
    }
}

uint32_t GenerateSpreadSeed(int seed)
{
    CSHA1 sha1;
    sha1.Reset();
    sha1.Update(&seed, sizeof(seed));
    sha1.Final();
    return sha1.GetHash();
}
```

## Система оружия (Weapon Services)

Оружие игрока хранится в объекте `CPlayer_WeaponServices`, доступном через поле пешки `m_pWeaponServices`. Поля: `m_hMyWeapons` (вектор хэндлов), `m_hActiveWeapon` (текущее), `m_hLastWeapon` (предыдущее), `m_iAmmo` (массив uint16). При изменении полей вызываются сетевые колбэки.

```cpp
void RegisterWeaponServices()
{
    RegisterNetworkVar("m_hMyWeapons", "CNetworkUtlVectorBase< CHandle< C_BasePlayerWeapon > >");
    RegisterNetworkVar("m_hActiveWeapon", "CHandle< C_BasePlayerWeapon >");
    RegisterNetworkVar("m_hLastWeapon", "CHandle< C_BasePlayerWeapon >");
    RegisterNetworkVar("m_iAmmo", "uint16[AMMO_POSITION_COUNT]");
}
```

## Поля оружия (C_BasePlayerWeapon)

Поля: `m_nNextPrimaryAttackTick`, `m_flNextPrimaryAttackTickRatio`, `m_nNextSecondaryAttackTick`, `m_flNextSecondaryAttackTickRatio`, `m_iClip1`, `m_iClip2`, `m_pReserveAmmo`.
Возможность выстрела: текущий тик + tickratio >= m_nNextPrimaryAttackTick + m_flNextPrimaryAttackTickRatio и m_iClip1 > 0.

```cpp
void RegisterWeaponFields()
{
    RegisterNetworkVar("m_nNextPrimaryAttackTick", "GameTick_t");
    RegisterNetworkVar("m_flNextPrimaryAttackTickRatio", "float32");
    RegisterNetworkVar("m_nNextSecondaryAttackTick", "GameTick_t");
    RegisterNetworkVar("m_flNextSecondaryAttackTickRatio", "float32");
    RegisterNetworkVar("m_iClip1", "int32");
    RegisterNetworkVar("m_iClip2", "int32");
    RegisterNetworkVar("m_pReserveAmmo", "int[AMMO_POSITION_COUNT]");
}
```

## Углы обзора и смещения viewmodel

Логика получения углов обзора и смещений модели оружия.

```cpp
QAngle* GetViewAngles(CPlayer_Input* input, int slot)
{
    if (slot != 0)
        return &globalViewAngles;

    int viewIndex = input->m_nViewAngleIndex;
    if (viewIndex > 0)
        return &input->m_pViewAngleHistory[viewIndex - 1].m_angView;

    return &input->m_angView;
}

void GetViewModelOffsets(C_CSPlayerPawn* pawn, Vector* outOffset, float* outFOV)
{
    C_CSPlayerPawn* localPawn = GetLocalPlayerPawn();
    if (pawn != localPawn)
    {
        outOffset->x = GetConVarFloat("cl_viewmodel_offset_x");
        outOffset->y = GetConVarFloat("cl_viewmodel_offset_y");
        outOffset->z = GetConVarFloat("cl_viewmodel_offset_z");
        *outFOV = GetConVarFloat("cl_viewmodel_fov");
    }
    else
    {
        *outOffset = pawn->m_vecViewOffset;
        *outFOV = pawn->m_flFOV;
    }

    ClampFloat(outOffset->x, MIN_OFFSET, MAX_OFFSET);
    ClampFloat(outOffset->y, MIN_OFFSET, MAX_OFFSET);
    ClampFloat(outOffset->z, MIN_OFFSET, MAX_OFFSET);
    ClampFloat(*outFOV, MIN_FOV, MAX_FOV);
}
```

## Логика выстрела и баллистика (FireBullets)

Функция обработки выстрела является точкой входа для баллистических расчетов.

```cpp
void FireBullets(C_CSPlayerPawn* pawn, C_CSWeaponBase* weapon, FireBulletData_t* data)
{
    if (!weapon || !weapon->IsReady())
        return;

    weapon->UpdateNextAttackTime();

    CCSWeaponBaseVData* vdata = weapon->GetVData();
    int numBullets = vdata->m_nNumBullets;
    float range = vdata->m_flRange;

    float spreadAngles[MAX_BULLETS];
    CalcSpread(weapon->GetItemDefinitionIndex(), numBullets, data->randomSeed, data->inaccuracy, data->spread, spreadAngles);

    for (int i = 0; i < numBullets; i++)
    {
        TraceAttack(weapon, data->startPos, spreadAngles[i], range, vdata, pawn);
    }

    weapon->PlayFireEffects(pawn);
}
```

## Система хитбоксов и HitGroup (Hitbox / Hitgroup)

Хитбоксы существуют как компонент `CHitboxComponent`, прикрепляемый к энтити через `CBodyComponentSkeletonInstance`. CS использует собственную систему `CCSHitboxSystem` для дополнительной логики. `CSkeletonInstance` содержит `m_nHitboxSet`, определяющий активный набор хитбоксов модели. Каждый хитбокс ассоциирован с определённой группой `HitGroup_t`, полем материала `m_nMaterial` и способностью к пробитию `m_nPenetrate`.

```cpp
enum HitGroup_t
{
    HITGROUP_INVALID  = -1,
    HITGROUP_GENERIC  = 0,
    HITGROUP_HEAD     = 1,
    HITGROUP_CHEST    = 2,
    HITGROUP_STOMACH  = 3,
    HITGROUP_LEFTARM  = 4,
    HITGROUP_RIGHTARM = 5,
    HITGROUP_LEFTLEG  = 6,
    HITGROUP_RIGHTLEG = 7,
    HITGROUP_NECK     = 8,
    HITGROUP_UNUSED   = 9,
    HITGROUP_GEAR     = 10,
    HITGROUP_SPECIAL  = 11,
    HITGROUP_COUNT
};

struct Hitbox_t
{
    int16_t     m_nBoneIndex;
    int16_t     m_nGroup;
    Vector      m_vMinBounds;
    Vector      m_vMaxBounds;
    float       m_flRadius;
    uint32_t    m_nHitboxIndex;
    int16_t     m_nPenetrate;
    int16_t     m_nMaterial;
    int16_t     m_nHitGroupId;
};

struct HitboxSet_t
{
    CUtlVector<Hitbox_t> m_Hitboxes;
    const char*          m_pszName;
};

struct CHitboxComponent::Storage_t
{
    HitboxSet_t** m_ppHitboxSets;
    int32_t       m_nHitboxSetCount;
    int32_t       m_nActiveSetIndex;
};

class CHitboxComponent
{
public:
    CTransform* GetHitboxPosition(int hitboxIndex, int setIndex)
    {
        CSkeletonInstance* skeleton = this->m_pSkeleton;
        if (!skeleton)
            return nullptr;

        CModelState* modelState = skeleton->m_pModelState;
        if (!modelState)
            return nullptr;

        CTransform* boneArray = modelState->m_pBoneArray;
        if (!boneArray)
            return nullptr;

        HitboxSet_t* set = this->m_pStorage->m_ppHitboxSets[setIndex];
        if (!set || hitboxIndex >= set->m_Hitboxes.Count())
            return nullptr;

        int boneIndex = set->m_Hitboxes[hitboxIndex].m_nBoneIndex;
        return &boneArray[boneIndex];
    }

    HitGroup_t GetHitGroup(int hitboxIndex)
    {
        HitboxSet_t* set = GetActiveSet();
        if (!set || hitboxIndex >= set->m_Hitboxes.Count())
            return HITGROUP_GENERIC;

        return static_cast<HitGroup_t>(set->m_Hitboxes[hitboxIndex].m_nHitGroupId);
    }

private:
    HitboxSet_t* GetActiveSet()
    {
        int activeIdx = this->m_pStorage->m_nActiveSetIndex;
        if (activeIdx < 0 || activeIdx >= this->m_pStorage->m_nHitboxSetCount)
            return nullptr;
        return this->m_pStorage->m_ppHitboxSets[activeIdx];
    }

    CSkeletonInstance* m_pSkeleton;
    CHitboxComponent::Storage_t* m_pStorage;
};

int GetHitboxFromHitGroup(C_CSPlayerPawn* pawn, HitGroup_t group)
{
    CHitboxComponent* hitbox = pawn->m_pHitboxComponent;
    if (!hitbox)
        return -1;

    HitboxSet_t* set = hitbox->GetActiveSet();
    if (!set)
        return -1;

    for (int i = 0; i < set->m_Hitboxes.Count(); i++)
    {
        if (static_cast<HitGroup_t>(set->m_Hitboxes[i].m_nHitGroupId) == group)
            return i;
    }
    return -1;
}
```

## Система отдачи (Recoil System)

Отдача реализуется через два угловых смещения `m_aimPunchAngle` (текущий угол отдачи) и `m_aimPunchAngleVel` (скорость изменения отдачи), хранящихся в пешке. Счётчик `m_iShotsFired` увеличивается с каждым выстрелом и влияет на величину отдачи. `m_flRecoilIndex` в оружии управляет интерполяцией между различными паттернами отдачи.

```cpp
struct AimPunchAngle_t
{
    float x;
    float y;
    float z;
};

void ApplyRecoil(C_CSPlayerPawn* pawn, C_CSWeaponBase* weapon, QAngle* viewAngles)
{
    if (!pawn || !weapon)
        return;

    int shotsFired = pawn->m_iShotsFired;
    if (shotsFired <= 0)
        return;

    float recoilIndex = weapon->m_flRecoilIndex;

    CCSWeaponBaseVData* vdata = weapon->GetVData();
    if (!vdata)
        return;

    float recoilPunchX = vdata->m_flRecoilPunchX * recoilIndex;
    float recoilPunchY = vdata->m_flRecoilPunchY * recoilIndex;

    float punchVelX = pawn->m_aimPunchAngleVel.x;
    float punchVelY = pawn->m_aimPunchAngleVel.y;

    punchVelX -= (recoilPunchX * gpGlobals->interval_per_tick);
    punchVelY -= (recoilPunchY * gpGlobals->interval_per_tick);

    pawn->m_aimPunchAngleVel.x = punchVelX;
    pawn->m_aimPunchAngleVel.y = punchVelY;

    pawn->m_aimPunchAngle.x += punchVelX * gpGlobals->interval_per_tick;
    pawn->m_aimPunchAngle.y += punchVelY * gpGlobals->interval_per_tick;

    pawn->m_aimPunchAngle.x *= vdata->m_flRecoilDecay;
    pawn->m_aimPunchAngle.y *= vdata->m_flRecoilDecay;

    viewAngles->x += pawn->m_aimPunchAngle.x;
    viewAngles->y += pawn->m_aimPunchAngle.y;
}

void OnWeaponFired(C_CSPlayerPawn* pawn, C_CSWeaponBase* weapon)
{
    if (!pawn || !weapon)
        return;

    pawn->m_iShotsFired++;

    float recoilSeed = GenerateRecoilSeed(pawn->m_iShotsFired);
    weapon->m_flRecoilIndex = CalcRecoilIndex(recoilSeed, weapon->GetItemDefinitionIndex());
}

float CalcRecoilIndex(int seed, uint16_t weaponId)
{
    return (seed & 0xFFFF) * (1.0f / 65535.0f);
}

void DecayRecoil(C_CSPlayerPawn* pawn)
{
    if (!pawn)
        return;

    pawn->m_aimPunchAngle.x *= RECOIL_DECAY_PER_TICK;
    pawn->m_aimPunchAngle.y *= RECOIL_DECAY_PER_TICK;

    pawn->m_aimPunchAngleVel.x *= RECOIL_VEL_DECAY_PER_TICK;
    pawn->m_aimPunchAngleVel.y *= RECOIL_VEL_DECAY_PER_TICK;

    if (pawn->m_iShotsFired > 0)
        pawn->m_iShotsFired--;
}
```

## Система камеры и FOV (Camera / FOV)

Камера представлена двумя сущностями: `C_PointCamera` (стационарная камера в мире) и `C_PointCameraVFOV` (камера с вертикальным FOV). `m_iDesiredFOV` на `CBasePlayerController` определяет целевой FOV игрока. Поле `m_FOV` в `C_PointCamera` хранит горизонтальный FOV. Вертикальный FOV доступен через `m_flVerticalFOV`. Система `CPlayer_CameraServices` управляет пост-процессинг объёмами камеры.

```cpp
struct CameraSettings_t
{
    float m_FOV;
    float m_flVerticalFOV;
    float m_Resolution;
    bool  m_bFogEnabled;
    float m_FogStart;
    float m_FogEnd;
    float m_FogMaxDensity;
    Color m_FogColor;
};

class C_PointCamera
{
public:
    float GetFOV() { return m_FOV; }
    float GetVerticalFOV() { return m_flVerticalFOV; }
    float GetResolution() { return m_Resolution; }

private:
    float m_FOV;
    float m_Resolution;
    float m_flVerticalFOV;
    bool  m_bFogEnabled;
    float m_FogStart;
    float m_FogEnd;
    float m_FogMaxDensity;
    Color m_FogColor;
    bool  m_bActive;
    bool  m_bFogOverride;
};

float GetPlayerFOV(C_CSPlayerPawn* pawn, CBasePlayerController* controller)
{
    if (!pawn || !controller)
        return DEFAULT_FOV;

    float desiredFOV = static_cast<float>(controller->m_iDesiredFOV);
    if (desiredFOV <= 0.0f)
        desiredFOV = DEFAULT_FOV;

    if (pawn->m_bIsScoped)
    {
        float zoomLevel = pawn->m_zoomLevel;
        if (zoomLevel > 0.0f)
            desiredFOV /= zoomLevel;
    }

    return ClampFloat(desiredFOV, MIN_FOV, MAX_FOV);
}

void ChangeFOV(CBasePlayerController* controller, int newFOV)
{
    if (!controller)
        return;

    controller->m_iDesiredFOV = ClampValue(newFOV, MIN_FOV, MAX_FOV);
}

void InputChangeFOV(CBasePlayerController* controller, int deltaFOV)
{
    if (!controller)
        return;

    int currentFOV = controller->m_iDesiredFOV;
    if (currentFOV <= 0)
        currentFOV = DEFAULT_FOV;

    controller->m_iDesiredFOV = ClampValue(currentFOV + deltaFOV, MIN_FOV, MAX_FOV);
}

float ComputeVerticalFOV(float horizontalFOV, float aspectRatio)
{
    return 2.0f * atanf(tanf(horizontalFOV * 0.5f * DEG2RAD) / aspectRatio) * RAD2DEG;
}
```

## Система пробития (Penetration / Wallbang)

Пули могут пробивать объекты, пока счётчик `m_nPenetrate` не обнулится. Каждый пробитый объект уменьшает счётчик. `m_nNumObjectsPenetrated` отслеживает общее количество пробитых объектов. Урон уменьшается в зависимости от материала и толщины стены, а также случайного разброса.

```cpp
enum Material_t
{
    MATERIAL_GLASS = 0,
    MATERIAL_WOOD = 1,
    MATERIAL_METAL = 2,
    MATERIAL_FLESH = 3,
    MATERIAL_CONCRETE = 4,
    MATERIAL_DIRT = 5,
    MATERIAL_WATER = 6,
    MATERIAL_ASPHALT = 7,
    MATERIAL_ROCK = 8,
    MATERIAL_COUNT,
    MATERIAL_NONE = -1
};

struct PenetrationData_t
{
    Vector     m_vecStart;
    Vector     m_vecEnd;
    int        m_nPenetrationCount;
    int        m_nPenetratedObjects;
    float      m_flCurrentDamage;
    float      m_flRange;
    Material_t m_Material;
    HitGroup_t m_HitGroup;
    int        m_nHitBox;
};

float GetMaterialPenetrationModifier(Material_t material)
{
    switch (material)
    {
        case MATERIAL_GLASS:    return 0.25f;
        case MATERIAL_WOOD:     return 0.5f;
        case MATERIAL_METAL:    return 0.7f;
        case MATERIAL_FLESH:    return 0.4f;
        case MATERIAL_CONCRETE: return 0.8f;
        case MATERIAL_DIRT:     return 0.6f;
        case MATERIAL_WATER:    return 0.3f;
        case MATERIAL_ASPHALT:  return 0.85f;
        case MATERIAL_ROCK:     return 0.9f;
        default:                return 1.0f;
    }
}

float GetHitGroupDamageModifier(HitGroup_t group)
{
    switch (group)
    {
        case HITGROUP_HEAD:    return 4.0f;
        case HITGROUP_CHEST:   return 1.0f;
        case HITGROUP_STOMACH: return 1.25f;
        case HITGROUP_LEFTARM:
        case HITGROUP_RIGHTARM: return 0.75f;
        case HITGROUP_LEFTLEG:
        case HITGROUP_RIGHTLEG: return 0.6f;
        case HITGROUP_NECK:    return 1.5f;
        case HITGROUP_GEAR:    return 0.5f;
        default:               return 1.0f;
    }
}

float GetArmorPenetrationModifier(int ArmorValue, float armorPenetrationRatio)
{
    if (ArmorValue <= 0)
        return 1.0f;

    float armorRatio = armorPenetrationRatio * 0.5f;
    float armorBonus = 0.5f;

    if (ArmorValue > 0)
    {
        float armorMod = powf(1.0f - armorRatio, (ARMOR_MAX - ArmorValue) / ARMOR_MAX);
        armorBonus = 1.0f - (0.5f * armorMod);
    }

    return armorBonus;
}

PenetrationResult_t ApplyPenetration(PenetrationData_t* data, float wallThickness)
{
    if (data->m_nPenetrationCount <= 0)
        return PENETRATION_STOPPED;

    float penMod = GetMaterialPenetrationModifier(data->m_Material);
    float distanceMod = data->m_flCurrentDamage / data->m_flRange;
    float thicknessMod = expf(-wallThickness * penMod * THICKNESS_SCALE);

    data->m_flCurrentDamage *= distanceMod * thicknessMod;
    data->m_nPenetrationCount--;
    data->m_nPenetratedObjects++;

    if (data->m_flCurrentDamage < MIN_DAMAGE_THRESHOLD)
        return PENETRATION_STOPPED;

    return PENETRATION_CONTINUES;
}

float CalcDamageAfterPenetration(float baseDamage, float armorPenetration,
                                  int armorValue, HitGroup_t hitGroup,
                                  int penetrationCount, float distance, float maxRange)
{
    float rangeMod = 1.0f;
    if (distance < maxRange)
        rangeMod = 1.0f - (distance / maxRange) * 0.25f;

    float damage = baseDamage * rangeMod;
    damage *= GetHitGroupDamageModifier(hitGroup);

    if (armorValue > 0 && hitGroup == HITGROUP_HEAD)
        damage *= GetArmorPenetrationModifier(armorValue, armorPenetration);

    if (penetrationCount < MAX_PENETRATION_COUNT)
        damage *= powf(0.75f, MAX_PENETRATION_COUNT - penetrationCount);

    return fmaxf(damage, 0.0f);
}
```

## Сетевая система / NetVars (Network System)

Source 2 использует шаблонную систему `CNetworkVarBase` для автоматической репликации полей. Каждое сетевое поле регистрируется с типом и именем через макросы `NetworkVar_`. Контейнеры используют `CNetworkUtlVectorBase` для динамических массивов. `CNetworkTransmitComponent` управляет отправкой изменений.

```cpp
template<typename T, typename Tag>
class CNetworkVarBase
{
public:
    T Get() const { return m_value; }
    void Set(const T& val)
    {
        if (m_value != val)
        {
            m_value = val;
            m_bDirty = true;
        }
    }

    operator T() const { return Get(); }
    CNetworkVarBase& operator=(const T& val) { Set(val); return *this; }

private:
    T       m_value;
    bool    m_bDirty;
    uint8_t m_pad[3];
};

template<typename T, typename Tag>
class CNetworkHandleBase : public CNetworkVarBase<uint32_t, Tag>
{
public:
    C_BaseEntity* Get(CEntityList* list)
    {
        uint32_t handle = this->Get();
        if (handle == INVALID_HANDLE)
            return nullptr;

        int index = handle & ENTITY_INDEX_MASK;
        return list->GetEntityByIndex(index);
    }
};

template<typename T, typename Tag, int Count, typename IndexType = int>
class CNetworkArrayBase
{
public:
    T& operator[](int index) { return m_array[index]; }
    const T& operator[](int index) const { return m_array[index]; }
    int Count() const { return Count; }

private:
    T m_array[Count];
};

template<typename T, typename Tag, int InitialSize, typename IndexType = int>
class CNetworkUtlVectorBase
{
public:
    int Count() const { return m_size; }

    T& operator[](int index)
    {
        if (index < 0 || index >= m_size)
            HandleInvalidIndex(index);
        return m_memory[index];
    }

    void AddToTail(const T& val)
    {
        if (m_size >= m_capacity)
            Grow();
        m_memory[m_size++] = val;
        m_bDirty = true;
    }

    void RemoveAll()
    {
        m_size = 0;
        m_bDirty = true;
    }

private:
    T*      m_memory;
    int     m_size;
    int     m_capacity;
    bool    m_bDirty;
    uint8_t m_pad[3];
};

class CNetworkTransmitComponent
{
public:
    void FireEvent()
    {
        if (!m_bPendingStateChange)
            return;

        m_nChangeFlags |= TRANSMIT_CHANGE_FULL;
        m_nFlattenedSerial = 0;
        m_bPendingStateChange = false;
    }

    void MarkAsChanged()
    {
        m_bPendingStateChange = true;
    }

private:
    bool          m_bPendingStateChange;
    int32_t       m_nChangeFlags;
    int32_t       m_nFlattenedSerial;
    CEntityHandle m_hOwner;
};

class CNetworkSerializer
{
public:
    bool ReadField(const char* fieldName, void* outData)
    {
        SchemaClassInfoData_t* classInfo = FindSchemaClass(this->m_pType);
        if (!classInfo)
            return false;

        for (int i = 0; i < classInfo->m_nFieldCount; i++)
        {
            SchemaClassFieldData_t* field = &classInfo->m_pFields[i];
            if (strcmp(field->m_pszName, fieldName) == 0)
            {
                memcpy(outData, (uint8_t*)this + field->m_nOffset, field->m_pSchemaType->GetSize());
                return true;
            }
        }
        return false;
    }

private:
    CSchemaType* m_pType;
    uint8_t*     m_pData;
};
```

## Ввод и оконная процедура (Input / WndProc)

Ввод обрабатывается системой панелей Panorama. `CInputForwardingPanel` перехватывает события мыши и клавиатуры. Движок не использует прямую оконную процедуру (WndProc) в `client.dll` вся обработка ввода происходит через `IInputSystem` в `inputsystem.dll`. Клиентская часть в CS2 использует Protobuf-команды через `CSGOUserCmdPB` для отправки действий на сервер.

```cpp
enum InputEventType_t
{
    IE_ButtonPressed = 0,
    IE_ButtonReleased = 1,
    IE_ButtonDoubleClicked = 2,
    IE_AnalogValueChanged = 3,
};

struct InputEvent_t
{
    InputEventType_t m_Type;
    uint32_t         m_nTick;
    uint32_t         m_nData;
    int              m_nAction;
    int              m_nDeltaX;
    int              m_nDeltaY;
};

class CInputForwardingPanel
{
public:
    bool OnMouseMove(float x, float y)
    {
        if (!m_bEnabled)
            return false;

        m_nCursorX = static_cast<int>(x);
        m_nCursorY = static_cast<int>(y);

        DispatchMouseEvent(MOUSE_EVENT_MOVE, m_nCursorX, m_nCursorY);
        return true;
    }

    bool OnMouseWheel(int delta)
    {
        if (!m_bEnabled)
            return false;

        m_nScrollAccum += delta;
        DispatchMouseEvent(MOUSE_EVENT_WHEEL, delta, 0);
        return true;
    }

    bool OnKeyEvent(int keyCode, bool pressed)
    {
        if (!m_bEnabled)
            return false;

        DispatchKeyEvent(keyCode, pressed);
        return true;
    }

    void SetEnabled(bool enabled) { m_bEnabled = enabled; }

    int GetCursorX() const { return m_nCursorX; }
    int GetCursorY() const { return m_nCursorY; }

private:
    void DispatchMouseEvent(int type, int param1, int param2)
    {
        InputEvent_t ev;
        ev.m_Type = IE_AnalogValueChanged;
        ev.m_nTick = GetCurrentTick();
        ev.m_nData = (static_cast<uint32_t>(param2) << 16) | static_cast<uint32_t>(param1);
        PushEvent(ev);
    }

    void DispatchKeyEvent(int keyCode, bool pressed)
    {
        InputEvent_t ev;
        ev.m_Type = pressed ? IE_ButtonPressed : IE_ButtonReleased;
        ev.m_nTick = GetCurrentTick();
        ev.m_nAction = keyCode;
        PushEvent(ev);
    }

    bool        m_bEnabled;
    int         m_nCursorX;
    int         m_nCursorY;
    int         m_nScrollAccum;
    void*       m_pEventQueue;
};

class CPlayer_Input
{
public:
    void CreateMove(int sequenceNumber, float inputSampleTime, bool active)
    {
        if (!active)
            return;

        CSGOUserCmdPB* cmd = GetPendingCmd(sequenceNumber);
        if (!cmd)
            return;

        cmd->m_nTickCount = sequenceNumber;

        QAngle* viewAngles = GetViewAngles(this, 0);
        if (viewAngles)
        {
            cmd->m_pBase->m_pViewAngles->x = viewAngles->x;
            cmd->m_pBase->m_pViewAngles->y = viewAngles->y;
        }

        cmd->m_pBase->m_nButtons = GetButtonState();
        cmd->m_pBase->m_nForwardMove = GetAnalogValue(ANALOG_FORWARD);
        cmd->m_pBase->m_nSideMove = GetAnalogValue(ANALOG_SIDE);
        cmd->m_pBase->m_nUpMove = GetAnalogValue(ANALOG_UP);

        EncodeUserCmdToPb(cmd, sequenceNumber);
    }

private:
    uint32_t GetButtonState()
    {
        uint32_t buttons = 0;
        if (IsKeyDown(KEY_SPACE))    buttons |= IN_JUMP;
        if (IsKeyDown(KEY_CTRL))     buttons |= IN_DUCK;
        if (IsKeyDown(KEY_SHIFT))    buttons |= IN_SPEED;
        if (IsKeyDown(KEY_MOUSE1))   buttons |= IN_ATTACK;
        if (IsKeyDown(KEY_MOUSE2))   buttons |= IN_ATTACK2;
        if (IsKeyDown(KEY_W))        buttons |= IN_FORWARD;
        if (IsKeyDown(KEY_S))        buttons |= IN_BACK;
        if (IsKeyDown(KEY_A))        buttons |= IN_MOVELEFT;
        if (IsKeyDown(KEY_D))        buttons |= IN_MOVERIGHT;
        if (IsKeyDown(KEY_R))        buttons |= IN_RELOAD;
        if (IsKeyDown(KEY_1))        buttons |= IN_WEAPON1;
        if (IsKeyDown(KEY_2))        buttons |= IN_WEAPON2;
        if (IsKeyDown(KEY_E))        buttons |= IN_USE;
        return buttons;
    }

    CSGOUserCmdPB*  m_pCurrentCmd;
    int             m_nViewAngleIndex;
    QAngle          m_angView;
    CUtlVector<CSGOUserCmdPB*> m_CmdHistory;
};
```

## Система рендеринга (Rendering / Draw System)

Рендеринг в Source 2 построен на слоях (layers). `CRenderGameSystem` управляет всем рендер-пайплайном. `CViewRender` отвечает за рендеринг конкретного вида (view). Пост процессинг реализован через `CCsgoPostProcessRenderer`. Рендеринг панелей UI происходит через систему Panorama с `CRenderPanel`. Материалы представлены ресурсами `IMaterial2`.

```cpp
enum RenderLayer_t
{
    RENDER_LAYER_BACKGROUND = 0,
    RENDER_LAYER_SKYBOX,
    RENDER_LAYER_WORLD,
    RENDER_LAYER_ENTITIES,
    RENDER_LAYER_TRANSLUCENT,
    RENDER_LAYER_OVERLAY,
    RENDER_LAYER_POST_PROCESS,
    RENDER_LAYER_UI,
    RENDER_LAYER_COUNT
};

struct ViewSetup_t
{
    int      m_nX;
    int      m_nY;
    int      m_nWidth;
    int      m_nHeight;
    float    m_flFOV;
    float    m_flNearZ;
    float    m_flFarZ;
    Vector   m_vecOrigin;
    QAngle   m_angAngles;
    bool     m_bOrtho;
    float    m_flOrthoLeft;
    float    m_flOrthoRight;
    float    m_flOrthoTop;
    float    m_flOrthoBottom;
    float    m_flAspectRatio;
};

class CViewRender
{
public:
    void RenderView(const ViewSetup_t& setup)
    {
        m_CurrentView = setup;
        SetupViewMatrix(&m_ViewMatrix, &setup);
        SetupProjectionMatrix(&m_ProjMatrix, &setup);

        for (int i = 0; i < RENDER_LAYER_COUNT; i++)
        {
            if (!IsLayerEnabled(static_cast<RenderLayer_t>(i)))
                continue;
            RenderLayer(static_cast<RenderLayer_t>(i));
        }

        if (m_bPostProcessEnabled)
            ApplyPostProcessing();
    }

    void GetViewMatrix(float* outMatrix) const
    {
        memcpy(outMatrix, m_ViewMatrix, sizeof(float) * 16);
    }

    void SetPostProcessEnabled(bool enabled) { m_bPostProcessEnabled = enabled; }

private:
    void SetupViewMatrix(float* matrix, const ViewSetup_t* setup)
    {
        Vector forward, right, up;
        AngleVectors(setup->m_angAngles, &forward, &right, &up);

        matrix[0] = right.x;
        matrix[1] = right.y;
        matrix[2] = right.z;
        matrix[3] = -(right.Dot(setup->m_vecOrigin));

        matrix[4] = up.x;
        matrix[5] = up.y;
        matrix[6] = up.z;
        matrix[7] = -(up.Dot(setup->m_vecOrigin));

        matrix[8] = forward.x;
        matrix[9] = forward.y;
        matrix[10] = forward.z;
        matrix[11] = -(forward.Dot(setup->m_vecOrigin));

        matrix[12] = 0.0f;
        matrix[13] = 0.0f;
        matrix[14] = 0.0f;
        matrix[15] = 1.0f;
    }

    void SetupProjectionMatrix(float* matrix, const ViewSetup_t* setup)
    {
        float fovRad = setup->m_flFOV * DEG2RAD;
        float w = 1.0f / tanf(fovRad * 0.5f);
        float h = w / setup->m_flAspectRatio;
        float q = setup->m_flFarZ / (setup->m_flFarZ - setup->m_flNearZ);

        matrix[0] = w;
        matrix[1] = 0.0f;
        matrix[2] = 0.0f;
        matrix[3] = 0.0f;

        matrix[4] = 0.0f;
        matrix[5] = h;
        matrix[6] = 0.0f;
        matrix[7] = 0.0f;

        matrix[8] = 0.0f;
        matrix[9] = 0.0f;
        matrix[10] = q;
        matrix[11] = 1.0f;

        matrix[12] = 0.0f;
        matrix[13] = 0.0f;
        matrix[14] = -setup->m_flNearZ * q;
        matrix[15] = 0.0f;
    }

    void RenderLayer(RenderLayer_t layer)
    {
        switch (layer)
        {
            case RENDER_LAYER_WORLD:
                RenderWorld();
                break;
            case RENDER_LAYER_ENTITIES:
                RenderEntities();
                break;
            case RENDER_LAYER_TRANSLUCENT:
                RenderTranslucent();
                break;
            case RENDER_LAYER_OVERLAY:
                RenderOverlays();
                break;
            case RENDER_LAYER_POST_PROCESS:
                if (m_pPostProcessor)
                    m_pPostProcessor->Render();
                break;
            case RENDER_LAYER_UI:
                RenderUI();
                break;
            default:
                break;
        }
    }

    void RenderEntities()
    {
        for (int i = 0; i < m_VisibleEntities.Count(); i++)
        {
            C_BaseEntity* entity = m_VisibleEntities[i];
            if (!entity || !entity->ShouldDraw())
                continue;

            CRenderComponent* renderComp = entity->m_pRenderComponent;
            if (!renderComp)
                continue;

            renderComp->Draw(m_CurrentView);
        }
    }

    void ApplyPostProcessing()
    {
        if (!m_pPostProcessor)
            return;

        PostProcessingConstantBuffer_t constants;
        constants.m_flBloomStrength = GetConVarFloat("r_csgo_postprocess_enable") > 0.0f ? 0.5f : 0.0f;
        constants.m_flExposure = ComputeExposure();
        constants.m_flTonemapScale = 1.0f;

        m_pPostProcessor->Apply(&constants);
    }

    float ComputeExposure()
    {
        float avgLuminance = m_pPostProcessor->GetAverageLuminance();
        if (avgLuminance < 0.001f)
            avgLuminance = 0.001f;

        float targetExposure = 0.125f / avgLuminance;
        float prevExposure = m_pPostProcessor->GetCurrentExposure();

        float speedUp = GetConVarFloat("r_exposure_speed_up");
        float speedDown = GetConVarFloat("r_exposure_speed_down");
        float speed = (targetExposure > prevExposure) ? speedUp : speedDown;

        return Lerp(prevExposure, targetExposure, ClampFloat(speed * gpGlobals->frameTime, 0.0f, 1.0f));
    }

    ViewSetup_t                   m_CurrentView;
    float                         m_ViewMatrix[16];
    float                         m_ProjMatrix[16];
    bool                          m_bPostProcessEnabled;
    CCsgoPostProcessRenderer*     m_pPostProcessor;
    CUtlVector<C_BaseEntity*>     m_VisibleEntities;
};

class CRenderComponent
{
public:
    void Draw(const ViewSetup_t& view)
    {
        if (!m_pMaterial)
            return;

        if (m_bDrawMesh)
        {
            m_pSceneObject->Draw(m_pMaterial, m_bWireframe);
        }

        if (m_bDrawShadow)
        {
            DrawShadow();
        }
    }

    void SetMaterial(IMaterial2* material)
    {
        m_pMaterial = material;
    }

    bool ShouldDraw() const
    {
        return m_bVisible && !m_bDormant;
    }

    void SetGlowProperties(const CGlowProperty& glow)
    {
        m_Glow = glow;
    }

private:
    void DrawShadow()
    {
        if (!m_pShadowMaterial)
            m_pShadowMaterial = FindMaterial("materials/tools/show_collision_geometry_wire_nodepth.vmat");
        m_pSceneObject->Draw(m_pShadowMaterial, true);
    }

    IMaterial2*        m_pMaterial;
    IMaterial2*        m_pShadowMaterial;
    ISceneObject*      m_pSceneObject;
    CGlowProperty      m_Glow;
    bool               m_bVisible;
    bool               m_bDormant;
    bool               m_bDrawMesh;
    bool               m_bDrawShadow;
    bool               m_bWireframe;
};

class CCsgoPostProcessRenderer
{
public:
    void Render()
    {
        if (!m_bEnabled)
            return;

        ApplyPostProcessLayer("SimplePostProcessingLayer");
    }

    void Apply(const PostProcessingConstantBuffer_t* constants)
    {
        m_Constants = *constants;
        m_bDirty = true;
    }

    float GetAverageLuminance() const { return m_flAverageLuminance; }
    float GetCurrentExposure() const { return m_flCurrentExposure; }
    void  SetEnabled(bool enabled) { m_bEnabled = enabled; }

private:
    void ApplyPostProcessLayer(const char* layerName)
    {
        IMaterial2* postMat = FindMaterial("postprocess_target");
        if (!postMat)
            return;

        postMat->SetFloat("g_flBloomStrength", m_Constants.m_flBloomStrength);
        postMat->SetFloat("g_flExposure", m_Constants.m_flExposure);
        postMat->SetFloat("g_flTonemapScale", m_Constants.m_flTonemapScale);

        DrawScreenEffectMaterial(postMat);
    }

    PostProcessingConstantBuffer_t m_Constants;
    bool       m_bEnabled;
    bool       m_bDirty;
    float      m_flAverageLuminance;
    float      m_flCurrentExposure;
    float      m_flTargetExposure;
    float      m_flAdaptationSpeed;
};

class CGlowProperty
{
public:
    Color m_fGlowColor;
    int   m_iGlowType;
    int   m_iGlowTeam;
    int   m_nGlowRange;
    int   m_nGlowRangeMin;
    Color m_glowColorOverride;
    float m_flGlowTime;
    float m_flGlowStartTime;
    bool  m_bGlowing;
    float m_flGlowProxySize;
};

void OverrideEntityMaterial(C_BaseEntity* entity, IMaterial2* material)
{
    if (!entity || !material)
        return;

    CRenderComponent* renderComp = entity->m_pRenderComponent;
    if (!renderComp)
        return;

    CGlowProperty* glow = entity->m_pGlowProperty;
    if (glow && glow->m_bGlowing)
    {
        renderComp->SetGlowProperties(*glow);
    }

    renderComp->SetMaterial(material);
}

void DrawScreenEffectMaterial(IMaterial2* material)
{
    if (!material)
        return;

    material->Bind();
    DrawFullScreenQuad();
}
```

## Entity Component System (ECS) и регистрация компонентов

Source 2 строит игровые объекты из набора компонентов, прикрепляемых к C_BaseEntity. Каждый компонент регистрируется через центральный аллокатор CEntityComponent::CAllocator. В client.dll найдены аллокаторы для:

- `CBodyComponent` — физическое тело (точка или скелет)
- `CBodyComponentSkeletonInstance` — тело со скелетом
- `CBodyComponentPoint` — тело-точка (без скелета)
- `CRenderComponent` — рендеринг
- `CHitboxComponent` — хитбоксы

Компоненты хранятся в entity как массив указателей, индексируемых по типу. Каждый компонент имеет свой Storage_t для внутренних данных. Процесс регистрации: при создании entity вызывается функция, которая через vtable находит класс компонента по имени и выделяет память.

```cpp
enum EComponentType : int32_t
{
    COMPONENT_RENDER = 0,      // CRenderComponent
    COMPONENT_HITBOX = 1,      // CHitboxComponent
    COMPONENT_CHOREO = 2,      // CChoreoComponent
    COMPONENT_SKIN = 3,        // not confirmed
    COMPONENT_SOUND = 4,
    COMPONENT_CAMERA = 5,
    COMPONENT_COUNT
};

struct CEntityComponentAllocator
{
    void* AllocateComponent(const char* componentName)
    {
        // Выделяет память под компонент и возвращает указатель
        // Регистрирует его в entity через offset-массив
    }
};
```

## Glow Property (CGlowProperty)

Система свечения реализована через компонент `CGlowProperty`, прикрепляемый к entitiy. Поддерживает сетевые колбэки при изменении: `OnGlowTypeChanged` и `OnGlowColorChanged`. Эти колбэки регистрируются через центральную систему событий с флагом `0x80000000`.

```cpp
class CGlowProperty
{
public:
    void SetGlowType(int type)
    {
        m_iGlowType = type;
        m_bGlowing = (type > 0);
        OnGlowTypeChanged();
    }

    void SetGlowColor(Color color)
    {
        m_fGlowColor = color;
        OnGlowColorChanged();
    }

    void SetGlowRange(int range, int rangeMin)
    {
        m_nGlowRange = range;
        m_nGlowRangeMin = rangeMin;
    }

    void SetGlowTime(float duration)
    {
        m_flGlowTime = duration;
        m_flGlowStartTime = gpGlobals->curtime;
    }

    bool IsGlowing() const
    {
        return m_bGlowing;
    }

    Color GetGlowColor() const
    {
        if (m_glowColorOverride.a > 0)
            return m_glowColorOverride;
        return m_fGlowColor;
    }

private:
    void OnGlowTypeChanged()
    {
        // Триггерит сетевой колбэк
        // Вызывает NetworkStateChanged для репликации
    }

    void OnGlowColorChanged()
    {
        // Триггерит сетевой колбэк
    }

    Color   m_fGlowColor;           // Базовый цвет свечения
    int     m_iGlowType;            // Тип свечения
    int     m_iGlowTeam;            // Тимовая принадлежность свечения
    int     m_nGlowRange;           // Дальность видимости свечения
    int     m_nGlowRangeMin;        // Минимальная дальность
    Color   m_glowColorOverride;    // Оверрайд цвета (приоритет над базовым)
    float   m_flGlowTime;           // Длительность свечения
    float   m_flGlowStartTime;      // Время начала свечения
    bool    m_bGlowing;             // Флаг активности свечения
    float   m_flGlowProxySize;      // Размер прокси свечения
};
```

## Система команд / Team System (C_CSGO_Team)

Идентификация команды игрока строится на двух уровнях. `m_iTeamNum` (int32) хранится в каждом `C_BaseEntity` и устанавливается при спавне. Для доступа к объекту команды используется `C_CSGO_Team` — наследник `C_Team`.

```cpp
enum TeamID_t : int32_t
{
    TEAM_UNASSIGNED = 0,
    TEAM_SPECTATOR  = 1,
    TEAM_TERRORIST  = 2,
    TEAM_CT         = 3
};

class C_Team : public C_BaseEntity
{
public:
    const char* GetTeamName() const
    {
        return m_szTeamname;
    }

    int GetTeamNumber() const
    {
        return m_iTeamNum;
    }

    int GetScore() const
    {
        return m_iScore;
    }

private:
    int         m_iTeamNum;
    int         m_iScore;
    char*       m_szTeamname;
    Color       m_clrTeam;
};

class C_CSGO_Team : public C_Team
{
private:
    // CS-specific team fields
};

bool IsEnemy(C_CSPlayerPawn* local, C_CSPlayerPawn* target)
{
    if (!local || !target)
        return false;

    int localTeam = local->m_iTeamNum;
    int targetTeam = target->m_iTeamNum;

    if (localTeam == TEAM_SPECTATOR || targetTeam == TEAM_SPECTATOR)
        return false;

    return localTeam != targetTeam;
}

bool IsAllied(C_CSPlayerPawn* local, C_CSPlayerPawn* target)
{
    if (!local || !target)
        return false;

    return local->m_iTeamNum == target->m_iTeamNum
        && local->m_iTeamNum > TEAM_SPECTATOR;
}
```

## Weapon VData и система разброса (Spread / Inaccuracy)

Оружие в CS2 использует двухуровневую структуру: экземпляр `C_CSWeaponBase` и данные `CCSWeaponBaseVData`. VData содержит статические параметры оружия (урон, разброс, скорострельность), экземпляр — динамическое состояние.

CCSWeaponBaseVData содержит развернутую систему разброса с разделением по состояниям игрока.

```cpp
struct CCSWeaponBaseVData
{
    float m_flDamage;                       // Базовый урон
    float m_flRange;                        // Максимальная дальность
    float m_flRangeModifier;                // Модификатор урона по дистанции
    float m_flPenetration;                  // Способность к пробитию
    float m_flArmorRatio;                   // Коэффициент брони

    int   m_nNumBullets;                    // Количество пуль за выстрел
    float m_flCycleTime;                    // Время между выстрелами (сек)
    float m_flCycleTimeWhenInBurstMode;     // Время в режиме очереди

    // Система неточности (разброс в зависимости от состояния)
    float m_flSpread;                       // Базовый спред оружия
    float m_flInaccuracyStand;              // Неточность стоя
    float m_flInaccuracyCrouch;             // Неточность сидя
    float m_flInaccuracyJump;               // Неточность в прыжке
    float m_flInaccuracyJumpInitial;        // Неточность в начале прыжка
    float m_flInaccuracyJumpApex;           // Неточность в верхней точке прыжка
    float m_flInaccuracyLand;               // Неточность при приземлении
    float m_flInaccuracyLadder;             // Неточность на лестнице
    float m_flInaccuracyFire;               // Дополнительная неточность от стрельбы
    float m_flInaccuracyMove;               // Неточность от движения
    float m_flInaccuracyReload;             // Неточность при перезарядке
    float m_flInaccuracyPitchShift;         // Смещение неточности по вертикали
    float m_flInaccuracyAltSoundThreshold;  // Порог звука альтернативной неточности

    float m_flRecoilX;                      // Отдача по вертикали
    float m_flRecoilY;                      // Отдача по горизонтали
    float m_flRecoilIndex;                  // Индекс паттерна отдачи

    int   m_iMaxClip1;                      // Максимальный размер магазина
    int   m_iMaxClip2;                      // Максимальный размер доп. магазина

    float GetInaccuracyForState(C_CSPlayerPawn* pawn, CPlayer_MovementServices* mv)
    {
        float inaccuracy = 0.0f;

        // Базовая неточность по состоянию движения
        if (mv->IsOnLadder())
            inaccuracy += m_flInaccuracyLadder;
        else if (mv->IsInAir())
            inaccuracy += mv->IsJumpInitial() ? m_flInaccuracyJumpInitial
                       : mv->IsJumpApex() ? m_flInaccuracyJumpApex
                       : m_flInaccuracyJump;
        else if (pawn->m_bIsScoped && mv->IsMoving())
            inaccuracy += m_flInaccuracyMove * 0.5f; // scoped move penalty
        else if (mv->IsMoving())
            inaccuracy += m_flInaccuracyMove;
        else if (mv->IsCrouching())
            inaccuracy += m_flInaccuracyCrouch;
        else
            inaccuracy += m_flInaccuracyStand;

        // Дополнительная при стрельбе
        inaccuracy += m_flInaccuracyFire * pawn->m_iShotsFired;
        // ... additional calc with recoil index

        return ClampFloat(inaccuracy, 0.0f, 1.0f);
    }
};
```

## Состояние оружия и стрельба (C_CSWeaponBase / C_BasePlayerWeapon)

Экземпляр оружия отслеживает текущее состояние для стрельбы.

```cpp
class C_BasePlayerWeapon : public C_BaseModelEntity
{
public:
    GameTick_t    m_nNextPrimaryAttackTick;      // Тик следующего выстрела
    float         m_flNextPrimaryAttackTickRatio; // Фракция тика
    GameTick_t    m_nNextSecondaryAttackTick;
    float         m_flNextSecondaryAttackTickRatio;

    int32_t       m_iClip1;                       // Патроны в магазине
    int32_t       m_iClip2;                       // Доп. магазин
    int32_t       m_pReserveAmmo[AMMO_COUNT];     // Резерв патронов

    CHandle<C_BasePlayerPawn> m_hOwnerEntity;     // Владелец

    bool CanFire(GameTick_t currentTick, float currentTickRatio)
    {
        if (m_iClip1 <= 0)
            return false;

        float currentTime = (float)currentTick + currentTickRatio;
        float nextAttackTime = (float)m_nNextPrimaryAttackTick + m_flNextPrimaryAttackTickRatio;

        return currentTime >= nextAttackTime;
    }

    void UpdateNextAttackTime(GameTick_t currentTick, float tickRatio, float cycleTime)
    {
        float currentTime = (float)currentTick + tickRatio;
        float nextTime = currentTime + cycleTime;

        m_nNextPrimaryAttackTick = (GameTick_t)nextTime;
        m_flNextPrimaryAttackTickRatio = nextTime - (float)m_nNextPrimaryAttackTick;
    }
};

class C_CSWeaponBase : public C_BasePlayerWeapon
{
public:
    CCSWeaponBaseVData* GetVData()
    {
        // Возвращает указатель на статические данные оружия
        return this->m_pVData;
    }

    int GetItemDefinitionIndex()
    {
        return this->m_nItemDefIndex;
    }

    // Поля
    int             m_nItemDefIndex;
    uint16_t        m_nWeaponId;
    CCSWeaponBaseVData* m_pVData;
    float           m_flRecoilIndex;              // Индекс отдачи (меняется с каждым выстрелом)
    int             m_nZoomLevel;                  // Уровень зума (для AWP/SG-1 и т.д.)
};
```

## Система ввода CPlayer_Input и CPlayer_WeaponServices

Управление оружием игрока и его инвентарь.

```cpp
class CPlayer_WeaponServices
{
public:
    CUtlVector<CHandle<C_BasePlayerWeapon>> m_hMyWeapons;  // Все оружия игрока
    CHandle<C_BasePlayerWeapon>             m_hActiveWeapon; // Текущее активное оружие
    CHandle<C_BasePlayerWeapon>             m_hLastWeapon;   // Предыдущее оружие
    uint16_t                                m_iAmmo[AMMO_COUNT]; // Патроны по типам

    C_CSWeaponBase* GetActiveWeapon(CEntityList* list)
    {
        return static_cast<C_CSWeaponBase*>(m_hActiveWeapon.Get(list));
    }

    int GetAmmoCount(int ammoType) const
    {
        if (ammoType < 0 || ammoType >= AMMO_COUNT)
            return 0;
        return m_iAmmo[ammoType];
    }
};
```

## Система Dormancy и Predicted-состояние

Source 2 использует концепцию `m_bDormant` для оптимизации сетевого трафика. Dormant-сущности не обновляются клиентом и не должны отображаться. Предикшн-система отслеживает ошибки предсказания через `m_vecPredictionError` и `m_flPredictionErrorTime`.

```cpp
class C_BaseEntity
{
public:
    bool IsDormant() const
    {
        return m_bDormant;
    }

    bool IsPredictionEligible() const
    {
        return m_bPredictionEligible;
    }

    bool IsVisible() const
    {
        return !m_bDormant;
    }

protected:
    bool    m_bDormant;                         // Сущность в спящем режиме (PVS)
    bool    m_bPredictionEligible;               // Флаг участия в предикшне
    float   m_flPredictionErrorTime;             // Время последней ошибки предикшна
    Vector  m_vecPredictionError;                // Вектор ошибки предикшна

    GameTick_t  m_nCreationTick;                 // Тик создания
    GameTick_t  m_nCreationTickServer;           // Серверный тик создания

    int32_t     m_nEntityId;                     // ID сущности в списке
};

// Флаг m_bDormant устанавливается, когда сущность выходит из PVS игрока
// Используется для скрытия невидимых объектов (оптимизация рендеринга)

bool ShouldSkipEntity(C_BaseEntity* entity)
{
    return !entity || entity->IsDormant();
}
```

## Material Override и рендер-компонент (CRenderComponent)

Для изменения внешнего вида сущностей (chams) используется подмена материала через CRenderComponent. Система материалов в Source 2 поддерживает два типа оверрайда: полная замена материала и wireframe-режим.

```cpp
class CRenderComponent
{
public:
    void SetMaterial(IMaterial2* material)
    {
        m_pMaterial = material;
        m_bDrawMesh = true;
    }

    void SetWireframeMode(bool enabled)
    {
        m_bWireframe = enabled;
        if (enabled && !m_pShadowMaterial)
            m_pShadowMaterial = FindMaterial("materials/tools/show_collision_geometry_wire_nodepth.vmat");
    }

    void SetGlow(const CGlowProperty& glow)
    {
        m_Glow = glow;
    }

    void SetDrawShadow(bool draw)
    {
        m_bDrawShadow = draw;
    }

    void Draw(const ViewSetup_t& view)
    {
        if (!m_pMaterial)
            return;

        if (m_bDrawMesh)
            m_pSceneObject->Draw(m_pMaterial, m_bWireframe);

        if (m_bDrawShadow)
            DrawShadow();
    }

    bool ShouldDraw() const
    {
        return m_bVisible && !m_bDormant;
    }

    IMaterial2* FindChamsMaterial(const char* materialName)
    {
        // Поиск материала по имени
        // Например: "materials/physics/wireframe_basic.vmat"
        //           "materials/physics/flat_basic.vmat"
        return FindMaterial(materialName);
    }

private:
    void DrawShadow()
    {
        if (!m_pShadowMaterial)
            m_pShadowMaterial = FindMaterial("materials/tools/show_collision_geometry_wire_nodepth.vmat");
        m_pSceneObject->Draw(m_pShadowMaterial, true);
    }

    IMaterial2*        m_pMaterial;
    IMaterial2*        m_pShadowMaterial;
    ISceneObject*      m_pSceneObject;
    CGlowProperty      m_Glow;
    bool               m_bVisible;
    bool               m_bDormant;
    bool               m_bDrawMesh;
    bool               m_bDrawShadow;
    bool               m_bWireframe;
};
```

Стандартные пути материалов для чеймсов:
- `materials/tools/show_collision_geometry_wire_nodepth.vmat` — wireframe (глута)
- `materials/physics/wireframe_basic.vmat` — базовый wireframe
- `materials/physics/wireframe_hidden.vmat` — скрытый wireframe
- `materials/physics/flat_basic.vmat` — плоский (flat) материал

## Система анимации (Animation State Machine)

Source 2 использует `CSkeletonInstance` — наследник `CGameSceneNode` — для управления скелетной анимацией. Анимация управляется через `m_nSequence` (текущая последовательность) и `m_flCycle` (прогресс анимации от 0.0 до 1.0).

```cpp
class CModelState
{
public:
    CTransform* GetBoneArray() const
    {
        return m_pBoneArray;
    }

    int GetBoneCount() const
    {
        return m_nBoneCount;
    }

    float GetCycle() const
    {
        return m_flCycle;
    }

    int GetSequence() const
    {
        return m_nSequence;
    }

private:
    CTransform*     m_pBoneArray;               // Массив трансформаций костей
    int             m_nBoneCount;                // Количество костей
    int16_t         m_nSequence;                 // Текущая анимационная последовательность
    float           m_flCycle;                   // Прогресс анимации (0..1)
    float           m_flCyclesPerSecond;         // Скорость анимации
    int16_t         m_nSequenceIndex;            // Индекс последовательности в таблице
};

class CSkeletonInstance : public CGameSceneNode
{
public:
    CModelState* GetModelState()
    {
        return m_pModelState;
    }

    int GetActiveHitboxSet() const
    {
        return m_nHitboxSet;
    }

    void SetActiveHitboxSet(int set)
    {
        m_nHitboxSet = set;
    }

    CTransform* GetBoneArrayForHitbox()
    {
        // Возвращает массив костей для текущего хитбокс-сета
        if (!m_pModelState)
            return nullptr;
        return m_pModelState->GetBoneArray();
    }

private:
    CModelState*    m_pModelState;               // Состояние модели
    int8_t          m_nHitboxSet;                // Активный набор хитбоксов
    CHitboxComponent* m_pHitboxComponent;        // Ссылка на хитбокс-компонент
};

// Иерархия наследования:
// C_BaseEntity
//   -> C_BaseModelEntity
//        -> C_BasePlayerPawn
//             -> C_CSPlayerPawn          (CS-specific pawn)
//
// CGameSceneNode
//   -> CSkeletonInstance                (анимированные объекты со скелетом)
//
// Компоненты C_BaseEntity:
//   m_pGameSceneNode  -> CGameSceneNode / CSkeletonInstance
//   m_pRenderComponent -> CRenderComponent
//   m_pHitboxComponent -> CHitboxComponent
//
// Сервисы C_BasePlayerPawn:
//   m_pWeaponServices  -> CPlayer_WeaponServices
//   m_pCameraServices  -> CPlayer_CameraServices
//   m_pMovementServices -> CPlayer_MovementServices
//   m_pWaterServices    -> CCSPlayer_WaterServices
```

## Известные поля CCSPlayerController

Контроллер — стабильный объект, существующий всё время подключения игрока.

```cpp
class CCSPlayerController : public CBasePlayerController
{
public:
    // Handle на пешку игрока
    CHandle<C_CSPlayerPawn>    m_hPawn;

    // Информация о подключении
    uint64_t           m_steamID;
    char               m_szPlayerName[128];
    int                m_iTeamNum;
    int                m_nMoney;
    int                m_nKills;
    int                m_nDeaths;
    int                m_nAssists;
    int                m_nPing;

    // FOV
    int                m_iDesiredFOV;
    float              m_flFOVRate;
    float              m_flFOVTime;

    // Состояние
    bool               m_bConnected;
    bool               m_bHasDefuser;
    bool               m_bHasHelmet;

    C_CSPlayerPawn* GetPawn(CEntityList* entityList)
    {
        if (m_hPawn == INVALID_HANDLE)
            return nullptr;

        int index = m_hPawn & ENTITY_INDEX_MASK;
        return static_cast<C_CSPlayerPawn*>(ResolveEntityIndex(entityList, index));
    }
};
```

## Известные поля C_CSPlayerPawn

Пешка — временный физический объект, пересоздаётся при каждом спавне.

```cpp
class C_CSPlayerPawn : public C_BasePlayerPawn
{
public:
    // Счётчики
    int32_t     m_iShotsFired;
    int32_t     m_zoomLevel;
    int32_t     m_ArmorValue;

    // Состояние
    bool        m_bIsScoped;
    bool        m_bHasDefuser;
    bool        m_bHasHelmet;
    bool        m_bGunGameImmunity;

    // Углы отдачи (aim punch)
    QAngle      m_aimPunchAngle;
    QAngle      m_aimPunchAngleVel;

    // Flash
    float       m_flFlashDuration;
    float       m_flFlashMaxDuration;
    float       m_flFlashBangTime;

    // FOV
    float       m_flFOV;
    float       m_flFOVTime;

    // Ускорение отдачи (акселерация)
    float       m_flRecoilAcceleration;

    // Ссылки на сервисы (через C_BasePlayerPawn)
    //   m_pWeaponServices -> CPlayer_WeaponServices
    //   m_pCameraServices -> CPlayer_CameraServices
    //   m_pMovementServices -> CPlayer_MovementServices
    //   m_pWaterServices -> CCSPlayer_WaterServices
};
```

## Категории оружия и идентификаторы

В игре определена система категорий оружия, которые используются для классификации и UI-группировки.

```cpp
enum WeaponCategory_t
{
    WEAPON_CATEGORY_KNIFE = 0,
    WEAPON_CATEGORY_PISTOL,
    WEAPON_CATEGORY_SMG,
    WEAPON_CATEGORY_RIFLE,
    WEAPON_CATEGORY_SHOTGUN,
    WEAPON_CATEGORY_SNIPER,
    WEAPON_CATEGORY_MACHINEGUN,
    WEAPON_CATEGORY_EQUIPMENT,
    WEAPON_CATEGORY_GRENADE,
    WEAPON_CATEGORY_UNKNOWN,
    WEAPON_CATEGORY_COUNT
};

const char* GetWeaponCategoryName(WeaponCategory_t cat)
{
    static const char* names[] = {
        "weapon_category_knife",
        "weapon_category_pistol",
        "weapon_category_smg",
        "weapon_category_rifle",
        "weapon_category_shotgun",
        "weapon_category_sniper",
        "weapon_category_machinegun",
        "weapon_category_equipment",
        "weapon_category_grenade",
        "weapon_category_unknown"
    };
    if (cat >= 0 && cat < WEAPON_CATEGORY_COUNT)
        return names[cat];
    return "weapon_category_unknown";
}

// Идентификаторы оружия (string names)
// weapon_glock       = Glock-18
// weapon_hkp2000     = P2000
// weapon_cz75a       = CZ75-Auto
// weapon_elite       = Dual Berettas
// weapon_deagle       = Desert Eagle
// weapon_fiveseven   = Five-SeveN
// weapon_p250        = P250
// weapon_revolver     = R8 Revolver
// weapon_tec9        = TEC-9
// weapon_usp_silencer = USP-S
// weapon_ak47         = AK-47
// weapon_m4a1         = M4A4
// weapon_m4a1_silencer = M4A1-S
// weapon_famas        = FAMAS
```

## Сетевая квантизация (Network Quantization)

Source 2 использует специализированные сетевые типы для оптимизации трафика. Квантизация позволяет передавать координаты и углы с пониженной точностью.

```cpp
// Сетевые квантизированные типы:
class CNetworkedQuantizedFloat
{
    // Float с квантизацией для сетевой передачи
};

class CNetworkOriginCellCoordQuantizedVector
{
    // Позиция с квантизацией по клеткам (cell-coord)
    // Используется для m_vecOrigin
};

class CNetworkVelocityVector
{
    // Вектор скорости с квантизацией
    // Используется для m_vecVelocity
};

class CNetworkViewOffsetVector
{
    // Вектор смещения вида с квантизацией
    // Используется для m_vecViewOffset
};

class CNetworkOriginQuantizedVector
{
    // Альтернативная квантизация для координат
};
```

## VTable Function Index (для хуков)

Для реализации хуков на виртуальные функции используется VTable-индекс. Типичная схема расположения функций в vtable для ключевых классов Source 2:

```cpp
// Типичные vtable-индексы для ISchemaSystem и IEngineCvar:
enum VTableIndex_ISchemaSystem
{
    VTABLE_FIND_TYPE_SCOPE = 9     // FindTypeScopeForModule
};

enum VTableIndex_CSchemaSystemTypeScope
{
    VTABLE_FIND_DECLARED_CLASS = 15, // FindDeclaredClass
    VTABLE_GET_NAME            = 16  // GetName
};

// Для hook'а функций рендеринга используются vtable-индексы
// CViewRender (для оверрайда отрисовки)
enum VTableIndex_CViewRender
{
    VTABLE_RENDER_VIEW = 1,        // RenderView
    VTABLE_GET_VIEW_MATRIX = 5     // GetViewMatrix
};
```

## VTable Map (подтверждённые vtables из client.dll)

Ниже приведены найденные в .rdata vtables ключевых классов. Адреса даны для идентификации — при обновлении игры смещения меняются, но набор и порядок функций остаются стабильными внутри одного мажорного обновления.

### CRenderComponent
**Адрес:** 0x1819376e8
**Размер:** 6 entries
```cpp
[0] destructor
[1] unknown
[2] unknown
[3] nullsub
[4] nullsub
[5] unknown
```

### CHitboxComponent
**Адрес:** 0x181937720
**Размер:** 9 entries
```cpp
[0] destructor
[1] unknown
[2] unknown
[3] nullsub
[4] nullsub
[5] unknown
[6] GetHitboxPosition / hitbox access
[7] hitbox bounds / overlap test
[8] unknown
```

### CBodyComponentSkeletonInstance
**Адрес:** 0x1819373a0
**Размер:** 8 entries
```cpp
[0] destructor
[1] GetSkeletonInstance
[2] unknown
[3] nullsub
[4] nullsub
[5] unknown
[6] unknown
[7] unknown
```

### CBodyComponentBaseModelEntity
**Адрес:** 0x181980ed8
**Размер:** 8 entries
```cpp
[0] destructor
[1] GetSkeletonInstance / scene node access
[2] unknown
[3] nullsub
[4] nullsub
[5] unknown
[6] unknown
[7] unknown
```

### C_PlayerVisibility
**Адрес:** 0x181946860
**Размер:** 50 entries (C_BaseEntity shared layout)

### C_PointCamera
**Адрес:** 0x181950ed8
**Размер:** 50 entries (C_BaseEntity shared layout)

### C_Team
**Адрес:** 0x18195af48
**Размер:** 50 entries (C_BaseEntity shared layout)

### IPredictionCopyable
**Адрес:** 0x181997590
**Размер:** 12 entries
```cpp
[0] GetDataOps / prediction copy operations
[1-10] GetValue by index (per-field serializers)
[11] GetValue (last)
```

### Общие паттерны vtable для C_BaseEntity-наследников
У всех классов, наследующих `C_BaseEntity`, совпадают первые ~9 vtable-индексов:
```
[0]  ScalarDeletingDestructor
[1]  null (purecall)  
[2]  null (purecall)
[3]  UpdateOnRemove / ShouldDraw / Think
[4]  unknown
[5]  unknown  
[6]  unknown
[7]  unknown
[8]  unknown
[9]  unknown
[10+] класс-специфичные методы
```

Для классов без скелета (C_PointCamera, C_Team и др.) vtable содержит 50 entries — стандартный размер для `C_BaseEntity`.

## Прототип функции OnGlowTypeChanged (сетевой колбэк)

Система CGlowProperty использует подписку на изменения через центральный event system.

```cpp
// Схема подписки на изменения GlowProperty:
void RegisterGlowCallbacks(CGlowProperty* glow)
{
    // Используется vtable-вызов для привязки колбэков
    // Параметры:
    //   - Имя события: "OnGlowTypeChanged" / "OnGlowColorChanged"
    //   - Имя класса: "CGlowProperty"
    //   - Тип данных
    //   - Флаг: 0x80000000 (сетевой колбэк)
    
    // Пример колбэка:
    glow->RegisterCallback("OnGlowTypeChanged",
                          "CGlowProperty",
                          CALLBACK_NETWORK);
    glow->RegisterCallback("OnGlowColorChanged",
                          "CGlowProperty",
                          CALLBACK_NETWORK);
}
```
